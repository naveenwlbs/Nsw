<?php
$digixon_image_size_w = 924;
$digixon_image_size_h = 477;
$digixon_class_name = digixon_get_post_category();
$digixon_class_name .= " digixon_multi_post_isotop_item all"; ?>

<article <?php post_class(); ?>>
	<?php if(has_post_thumbnail()) { ?>
	<div class="wd-post__thumbnail">
		<?php
		if( digixon_get_attachment() &&  digixon_get_attachment(7) != "" ){	?>
			<ul class="wd-gallery-images-holder clearfix wd-post__thumbnail--gallery">
				<?php
          $attachments = digixon_get_attachment(7);
          $i = 0;
          foreach( $attachments as $attachment ):
            $active = ( $i == 0 ? ' active' : '' );
            $images = aq_resize(wp_get_attachment_url( $attachment->ID ), $digixon_image_size_w, $digixon_image_size_h, true, true, true); ?>
            <li class="wd-gallery-image-holder <?php echo esc_attr($active); ?>"><img src="<?php echo esc_url($images) ?>" alt="<?php echo the_title_attribute(); ?>"/></li>
            <?php $i++; endforeach; ?>
			</ul>
      <?php }else { ?>
			<ul class="wd-gallery-images-holder clearfix wd-post__thumbnail--gallery">
				<?php
				$portfolio_image_gallery_val = get_post_meta(get_the_ID(), 'wd_portfolio-image-gallery', true);
				if ($portfolio_image_gallery_val != '') $portfolio_image_gallery_array = explode(',', $portfolio_image_gallery_val);

				if (isset($portfolio_image_gallery_array) && count($portfolio_image_gallery_array) != 0):
					foreach ($portfolio_image_gallery_array as $gimg_id):
						echo '<li class="wd-gallery-image-holder">'. wp_get_attachment_image( $gimg_id, 'digixon_blog-thumb', false ) .'</li>';
					endforeach;
				endif;
				?>
			</ul>
			<?php	} ?>
		</div>
	<?php	} ?>
	<div class="wd-post__content <?php if(!has_post_thumbnail()) echo 'm-b-0' ?>">
		<div class="entry-category"><?php  the_category(); ?></div>
		<h3 class="wd-post__title">
			<a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a>
		</h3>
		<ul class="wd-post__meta clearfix">
			<li class="entry-date"><?php echo get_the_date(); ?></li>
			<li class="entry-author"><?php echo esc_html__('By:','digixon');  the_author() ?></li>
			<li><?php comments_number( 'no comments', 'one comment', '% comments' ); ?></li>
		</ul>
		<div class="wd-post__body">
			<p><?php echo wp_trim_words(get_the_content(),60); ?></p>
		</div>
		<div class="wd-post__read-more">
			<a href="<?php esc_url(the_permalink()); ?>">
				<?php echo esc_html__('Read More', 'digixon'); ?>
				<img src="<?php echo get_template_directory_uri()."/images/more.svg" ?>" alt="<?php echo esc_attr__('icon','digixon') ?>">
			</a>
		</div>
	</div>
</article>
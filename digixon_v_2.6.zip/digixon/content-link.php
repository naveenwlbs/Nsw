
<article <?php post_class(); ?>>
		<div class="wd-post__body">
			<i class="fas fa-link"></i> <?php the_content();  ?>
		</div>
</article>

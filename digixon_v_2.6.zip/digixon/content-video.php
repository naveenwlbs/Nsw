
<article <?php post_class(); ?>>
	<div class="wd-post__thumbnail">
		<?php echo digixon_get_embedded_media(array('video', 'iframe')); ?>
	</div>

	<div class="wd-post__content">
		<div class="entry-category"><?php  the_category(); ?></div>
		<h3 class="wd-post__title">
			<a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a>
		</h3>
		<ul class="wd-post__meta clearfix">
			<li class="entry-date"><?php echo get_the_date(); ?></li>
			<li class="entry-author"><?php echo esc_html__('By:','digixon');  the_author() ?></li>
			<li><?php comments_number( 'no comments', 'one comment', '% comments' ); ?></li>
		</ul>
		<div class="wd-post__body">
			<p><?php echo wp_trim_words(get_the_content(),60); ?></p>
		</div>
		<div class="wd-post__read-more">
			<a href="<?php esc_url(the_permalink()); ?>">
				<?php echo esc_html__('Read More', 'digixon'); ?>
				<img src="<?php echo get_template_directory_uri()."/images/more.svg" ?>" alt="<?php echo esc_attr__('icon','digixon') ?>">
			</a>
		</div>
	</div>
</article>



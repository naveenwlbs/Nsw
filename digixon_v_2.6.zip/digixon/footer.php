<?php if (is_active_sidebar('footer') || is_active_sidebar('footer_columns_three') || is_active_sidebar('footer_columns_tow') || is_active_sidebar('footer_columns_four')) { ?>
  <section class="first-footer">
    <h3 class="hide"><?php echo esc_html__('Footer', 'digixon'); ?></h3>
    <div class="footer_bg_color">
      <div class="row">
      <section class="block">
        <?php
        if (digixon_get_option('wd_footer_columns','four_columns') == 'one_columns') {
          $column_one = 12;
          $column_tow = '';
          $column_three = '';
          $column_four = '';

        } elseif (digixon_get_option('wd_footer_columns','four_columns') == 'tow_a_columns') {
          $column_one = 6;
          $column_tow = 6;
          $column_three = '';
          $column_four = '';
        } elseif (digixon_get_option('wd_footer_columns','four_columns') == 'tow_b_columns') {
          $column_one = 4;
          $column_tow = 8;
          $column_three = '';
          $column_four = '';
        } elseif (digixon_get_option('wd_footer_columns','four_columns') == 'tow_c_columns') {
          $column_one = 8;
          $column_tow = 4;
          $column_three = '';
          $column_four = '';

        } elseif (digixon_get_option('wd_footer_columns','four_columns') == 'three_columns') {
          $column_one = 3;
          $column_tow = 3;
          $column_three = 6;
          $column_four = '';
        } else {
          $column_one = 3;
          $column_tow = 3;
          $column_three = 3;
          $column_four = 3;
        }
        ?>
        <div class="large-<?php echo esc_attr($column_one) ?> medium-6 columns">
          <?php dynamic_sidebar('footer') ?>
        </div>
        <?php if (digixon_get_option('wd_footer_columns','four_columns') == 'tow_a_columns' or digixon_get_option('wd_footer_columns','four_columns') == 'four_columns' or digixon_get_option('wd_footer_columns','four_columns') == 'three_columns' or digixon_get_option('wd_footer_columns','four_columns') == 'tow_b_columns' or digixon_get_option('wd_footer_columns','four_columns') == 'tow_c_columns') { ?>
          <div class="large-<?php echo esc_attr($column_tow) ?> medium-6 columns">
            <?php dynamic_sidebar('footer_columns_tow') ?>
          </div>
        <?php } ?>

        <?php if (digixon_get_option('wd_footer_columns','four_columns') == 'three_columns' or digixon_get_option('wd_footer_columns','four_columns') == 'four_columns') { ?>
          <div class="large-<?php echo esc_attr($column_three) ?> medium-6 columns">
            <?php dynamic_sidebar('footer_columns_three') ?>
          </div>
        <?php } ?>

        <?php if (digixon_get_option('wd_footer_columns','four_columns') == 'four_columns') { ?>
          <div class="large-<?php echo esc_attr($column_four) ?> medium-6 columns">
            <?php dynamic_sidebar('footer_columns_four') ?>
          </div>
        <?php } ?>
      </section>
    </div>
    </div>
  </section>
<?php } ?>

<footer class="second-footer">
  <div class="row">
    <div class="copyright medium-3 large-3 columns">
	    <?php
	    $poweredby = html_entity_decode(digixon_get_option('wd_poweredby'));
	    echo esc_html($poweredby);
	    ?>
    </div>
    <div class="powered medium-6 large-6 columns">
      <section class="block">
        <?php
        $digixion_copyright = html_entity_decode(digixon_get_option('wd_copyright', '&copy; 2020 Digixon All rights reserved. '));
        echo esc_html($digixion_copyright);
        ?>
      </section>
    </div>
    <div class="footer-social-media medium-3 large-3 columns">

	      <?php
	      $socialmediaicon_arry = explode(' ', digixon_get_option('social_icon'));
	      $socialmedia_arry = explode(' ', digixon_get_option('socialmedia_name'));
	      if (!empty($socialmedia_arry[0])) {
	      ?>
        <ul class="footer-social-media">
		      <?php
		      $i = 0;
		      foreach ($socialmedia_arry as $social_data) {
			      $i++;
			      ?>
            <li class="">
            <a href="<?php echo esc_url($social_data) ?>"><i class="fab fa-<?php echo esc_attr($socialmediaicon_arry[$i - 1]) ?>"></i></a>
            </li><?php
		      }
		      ?>
        </ul>
	      <?php
	      }
	      ?> 
    </div>
  </div>
</footer>
</div>

<?php
$digixon_menu_style = digixon_get_option('wd_menu_style');
if ($digixon_menu_style == "offcanvas") { ?>
  <a class="exit-off-canvas"></a>
<?php } ?>

<?php wp_footer(); ?>
</body>
</html>
<?php
/**
 *----------------- include ------------------------------------------
 */
include_once(get_template_directory() . '/inc/tools.php');
include_once(get_template_directory() . '/inc/plugins/plugins.php');
include_once(get_template_directory() . '/inc/panel.php');
include_once(get_template_directory() . '/inc/meta-box.php');
require_once( get_template_directory() . '/inc/classes/wdevia_base_class.php' );
require_once( get_template_directory() . '/inc/base.php' );
require_once( get_template_directory() . '/inc/fonts.php' );
/** Register all navigation menus */
require_once( get_template_directory() . '/inc/navigation.php' );

/** Add menu walkers for top-bar and off-canvas */
require_once( get_template_directory() . '/inc/class-top-bar-walker.php' );
require_once( get_template_directory() . '/inc/class-mobile-walker.php' );

require_once( get_template_directory() . '/inc/widget-areas.php' );
require_once( get_template_directory() . '/inc/woocommerce.php' );
require_once( get_template_directory() . '/inc/theme-support.php' );

include_once(get_template_directory() . '/inc/mega-menu.php');
require_once(get_template_directory() . '/inc/aq_resizer.php');

require_once( get_template_directory() . '/inc/enqueue-scripts.php' );
require_once( get_template_directory() . '/inc/image-presets.php' );


function digixon_init () {
  return digixon_base_class::instance();
}

digixon_init();

 //----------- Add SVG to media ---------------
function digixon_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'digixon_mime_types');


//------------ Tags size ---------------
function digixon_custom_tag_cloud_widget($args) {
    $args['largest'] = 15; //largest tag
    $args['smallest'] = 15; //smallest tag
    $args['unit'] = 'px'; //tag font unit
    return $args;
}
add_filter( 'widget_tag_cloud_args', 'digixon_custom_tag_cloud_widget' );


if (function_exists('add_theme_support')) {
  add_theme_support('post-thumbnails');
  add_theme_support('post-formats', array('gallery', 'link', 'quote', 'video', 'audio'));
  add_theme_support('automatic-feed-links');
  add_theme_support('custom-background');
  add_theme_support('title-tag');
  add_theme_support('html5', array('search-form'));
  add_theme_support('woocommerce');
  add_theme_support('wc-product-gallery-zoom');
  add_theme_support('wc-product-gallery-lightbox');
  add_theme_support('wc-product-gallery-slider');
  add_theme_support('editor-styles');
  add_editor_style('editor.css');
  add_theme_support('align-wide');
  // -- Disable custom font sizes
  add_theme_support('disable-custom-font-sizes');

// -- Editor Font Sizes
  add_theme_support('editor-font-sizes', array(
    array(
      'name' => __('small', 'digixon'),
      'shortName' => __('S', 'digixon'),
      'size' => 14,
      'slug' => 'small'
    ),
    array(
      'name' => __('regular', 'digixon'),
      'shortName' => __('M', 'digixon'),
      'size' => 16,
      'slug' => 'regular'
    ),
    array(
      'name' => __('large', 'digixon'),
      'shortName' => __('L', 'digixon'),
      'size' => 18,
      'slug' => 'large'
    ),
  ));

// -- Editor Color Palette
  add_theme_support( 'editor-color-palette', array(
    array(
      'name'  => __( 'Primary Color:', 'digixon' ),
      'slug'  => 'primary',
      'color'	=> '#162466',
    ),
    array(
      'name'  => __( 'Secondary Color:', 'digixon' ),
      'slug'  => 'secondary',
      'color' => 'rgb(255, 59, 51);',
    ),
  ) );

}
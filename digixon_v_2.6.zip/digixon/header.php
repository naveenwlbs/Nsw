<!doctype html>
<!--[if IE 9]>
<html class="lt-ie10" lang="en"> <![endif]-->
<html class="no-js" <?php language_attributes(); ?> >
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <?php if (!function_exists('has_site_icon')) {
    if (digixon_get_option('wd_favicon', '') != '') { ?>
      <link rel="shortcut icon" href="<?php echo esc_url(digixon_get_option('wd_favicon')); ?>"/>
    <?php }
  } ?>
  <?php wp_head() ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="page-loading">
  <div class="spinner">
    <div class="double-bounce1"></div>
    <div class="double-bounce2"></div>
  </div>
</div>

<?php
$digixon_menu_style = isset($_GET['menustyle']) ? $_GET['menustyle'] : digixon_get_option('wd_menu_style', 'creative'); ?>
<?php if (digixon_get_option('digixon_mobile_menu_layout') == 'offcanvas'): ?>
  <?php get_template_part('template-parts/mobile-off-canvas'); ?>
<?php endif; ?>

<div id="spaces-main" class="pt-perspective <?php if (digixon_get_option('wd_box_wrapper') == 'on') {  echo 'wd_wrapper'; } ?>">
<header class="l-header <?php echo esc_attr($digixon_menu_style); ?>-layout" data-sticky-container>
  <div
    class="top-bar-container <?php if (digixon_get_option('wd_menu_in_grid') == 'on') echo "contain-to-grid"; ?> <?php if (digixon_get_option('wd_menu_sticky') != 'off') echo "sticky slideUp"; ?> ">
    <div class="site-title-bar" <?php digixon_title_bar_responsive_toggle(); ?> data-hide-for="large">
      <div class="title-bar-left">
        <button aria-label="<?php esc_html__('Main Menu', 'digixon'); ?>" class="menu-icon" type="button"
                data-toggle="<?php digixon_mobile_menu_id(); ?>"></button>
        <span class="site-mobile-title title-bar-title logo"><?php digixon_get_logo_and_title(); ?></span>
      </div>
    </div>
    <nav class="site-navigation top-bar" data-alignment="left" role="navigation">
      <div class="top-bar-left">
        <div class="site-desktop-title top-bar-title">
          <div class="logo-wrapper <?php if (digixon_get_option('wd_show_title', '') == 'on') echo "title-displayed"; ?>" data-dropdown-menu>
            <div class="menu-text">
              <?php digixon_get_logo_and_title(); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="top-bar-right" >
        <?php if ($digixon_menu_style == "corporate") {
          digixon_top_bar_primary();
          if (digixon_get_option('digixon_mobile_menu_layout') !== 'offcanvas') {
            get_template_part('template-parts/mobile-top-bar');
          }
        }
        if ($digixon_menu_style == "creative") {
          digixon_top_bar_primary();
          if (digixon_get_option('digixon_mobile_menu_layout') !== 'offcanvas') {
            get_template_part('template-parts/mobile-top-bar');
          }
        }
        ?>
      </div>
    </nav>
  </div>
</header>
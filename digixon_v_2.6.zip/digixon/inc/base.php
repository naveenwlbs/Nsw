<?php
/**
 *
// initialize options
*/
if (!function_exists('digixon_initialize_options')) {
  function digixon_initialize_options()
  {


    if (!get_option("wd_options_array")) {
      $options_array = get_option("wd_options_array");
      $options_array = array(
        'wd_show_logo' => "",
        'wd_show_cart' => "",
        'wd_show_top_social_bare' => "",
        'wd_box_wrapper' => "",
        'wd_menu_in_grid' => "",
        'wd_menu_sticky' => "",
        'wd_show_title' => "on",
        'wd_footer_bg_image' => "",
        'footer_bg_color' => "",
        'footer_text_color' => "",
        'wd_copyright' => "",
        'wd_poweredby' => "",
        'copyright_text_color' => "",
        'wd_logo' => "",
        'wd_height_logo' => WD_DEFAULT_LOGO_HEIGHT,
        'wd_404_page' => "",
        'wd_home_page' => "",
        'wd_favicon' => "",
        'wrapper_bg_color' => "",
        'primary_color' => "",
        'secondary_color' => "",
        'accent_color' => "",
        'adress_bar_color' => "",
        'social_bar_color' => "",
        'copyright_bg' => "",
        'header_bg' => "",
        'container_bg' => "",
        'wd_footer_columns' => "",
        'navigation_text_color' => "",
        'navigation_bg_color_sticky' => "",
        'footer_text_color' => "",
        'wd_copyright' => "",
        'language_area_html' => "",
        'digixon_show_wpml_widget' => '',
        'twitter' => "",
        'facebook' => "",
        'flickr' => "",
        'vimeo' => "",
        'phone' => "",
        'adress' => "",
        'wd_body_font_familly' => WD_BODY_FONT_FAMILY,
        'wd_body_font_style' => "",
        'wd_font-weight-style' => "300",
        'wd_main_text_lettre_spacing' => '',
        'wd_main-text-font-subsets' => "",
        'wd_head_font_familly' => WD_HEAD_FONT_FAMILY,
        'wd_head_font_style' => "",
        'wd_heading-font-weight-style' => "",
        'wd_heading-text-font-subsets' => "",
        'wd_heading_text_lettre_spacing' => "",
        'wd_navigation_font_familly' => WD_NAV_FONT_FAMILY,
        'wd_navigation_font_style' => "",
        'wd_navigation-font-weight-style' => "",
        'wd_navigation-text-font-subsets' => "",
        'wd_navigation_text_lettre_spacing' => "",
        'wd_menu_style' => "",
        'wd_theme_custom_js' => "",
        'header_color' => WD_HEADER_COLOR
      );
      update_option("wd_options_array", $options_array);
    }
  }
}


/**
 *
 */
// get options value
if (!function_exists('digixon_get_option')) {
  function digixon_get_option($digixon_option_key, $digixon_option_default_value = null)
  {
    digixon_initialize_options();
    $options_array = get_option("wd_options_array");

    // for demo purpose
    if(function_exists("wd_custom_options")) {
      $options_array = wd_custom_options($options_array);
    }


    $digixon_meta_value = "";
    if (array_key_exists($digixon_option_key, $options_array)) :
      if (isset($options_array[$digixon_option_key]) && !empty($options_array[$digixon_option_key])) {
        $digixon_meta_value = esc_attr($options_array[$digixon_option_key]);
      }

      if ($digixon_meta_value == "") {
        $digixon_meta_value = $digixon_option_default_value;
      }
    endif;
    return $digixon_meta_value;
  }
}

/**
 *
 */
// get options value
if (!function_exists('digixon_save_option')) {
  function digixon_save_option($digixon_option_key, $digixon_option_value = null)
  {
    $options_array = get_option("wd_options_array");
    $options_array[$digixon_option_key] = $digixon_option_value;
    update_option("wd_options_array", $options_array);
  }
}

/**
 *
 */
if (!function_exists('digixon_get_categories')) {
  function digixon_get_categories($taxonomy = '')
  {
    $args = array(
      'type' => 'post',
      'hide_empty' => 0
    );

    $output = array();

    $args['taxonomy'] = $taxonomy;
    $categories = get_categories($args);

    if (!empty($categories) && is_array($categories)) {
      foreach ($categories as $category) {
        if (is_object($category)) {
          $output[$category->name] = $category->slug;
        }
      }
    }

    return $output;
  }
}

/**
 * @param $string
 * @return string
 */
function digixon_removeslashes($string)
{
  $string = implode("", explode("\\", $string));

  return stripslashes(trim($string));
}

/**
 *
 */
function digixon_get_logo_and_title() {

  $digixon_logo_path = get_template_directory_uri() . "/images/logogdigixon.png";
  $digixon_logo = digixon_get_option('wd_logo', $digixon_logo_path);

  if (digixon_get_option('wd_show_logo', '') == 'on' && digixon_get_option('wd_logo', $digixon_logo_path) != ''){ ?>
    <?php $image = digixon_get_option('wd_logo', $digixon_logo);
    ?>
    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home" title="<?php echo bloginfo('name') ?>"
       class="active"><img src="<?php echo esc_url($image); ?>"
                           alt="<?php echo esc_attr__('logo', 'digixon') ?>"/></a>
  <?php }

  if (digixon_get_option('wd_show_title', 'on') == 'on'){ ?>
    <a class="site-title" href="<?php echo esc_url(home_url('/')); ?>"><h1><?php echo bloginfo('name') ?></h1>
    </a>
  <?php }

}


/**
 * Get mobile menu ID
 */

if ( ! function_exists( 'digixon_mobile_menu_id' ) ) :
  function digixon_mobile_menu_id() {
      echo 'mobile-menu';
  }
endif;





/*-----------------add Body Classes------------------------------------------*/
function digixon_body_classes($classes)
{
  if (digixon_get_option('wd_box_wrapper') == 'on') {
    $classes[] = 'bg_body_color';
  }

  if (digixon_get_option('wd_page_transitions', 'off') != 'off') {
    $classes[] = 'wd_page_transitions';
  }
  return $classes;
}

add_filter('body_class', 'digixon_body_classes');

function digixon_post_classes($classes) {
  $digixion_post_format = get_post_format();
  switch ($digixion_post_format) {
    case 'audio';
    $classes[] = 'wd-post ' . $digixion_post_format;
    case 'gallery';
    $classes[] = 'wd-post wd-post--' . $digixion_post_format;
    case 'link';
    $classes[] = 'wd-post wd-post--' . $digixion_post_format;
    case 'quote';
    $classes[] = 'wd-post wd-post--' . $digixion_post_format;
    case 'video';
      $classes[] = 'wd-post wd-post--' . $digixion_post_format;
    case '';
      $classes[] = 'wd-post ' . $digixion_post_format;
  }
  return $classes;
}
add_filter('post_class', 'digixon_post_classes');

function digixon_theme_add_editor_styles()
{
  add_editor_style('custom-editor-style.css');
}

add_action('admin_init', 'digixon_theme_add_editor_styles');



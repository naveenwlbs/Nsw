<?php


class digixon_base_class {

  private static $instance;
  public $helpers;
  public $customizer;
  public $activation;
  public $integrations;
  public $widgets;
  public $template;
  public $page_settings;
  public $widgetized_pages;

  public static function instance () {
    if(!isset(self::$instance) && !(self::$instance instanceof digixon_base_class)) {
      self::$instance = new self;
    }

    return self::$instance;
  }

  public function __construct () {
    $this->default_parameters();
    $this->base();
    $this->setup();
  }

  // Integration getter helper
  public function get ($integration) {
    return $this->integrations->get($integration);
  }

  private function base () {
    $this->files = array('customizer/class-customizer.php');

    foreach($this->files as $file) {
      require_once(get_template_directory() . '/inc/' . $file);
    }
  }

  private function setup () {

    $this->customizer = new digixon_Customizer();

    add_action('after_setup_theme', array($this,
      'setup_theme'));
  }

  public function setup_theme () {
    load_theme_textdomain('digixon', get_template_directory() . '/languages');
    add_editor_style('css/editor-style.css');

    add_theme_support('custom-background', apply_filters('digixon_custom_background_args', array('default-color' => 'ffffff',
      'default-image' => '',)));

  }

  public function default_parameters() {
    // Colors
    define('WD_PRIMARY_COLOR', '#162466');
    define('WD_SECONDARY_COLOR', '#5164E5');
    define('WD_ACCENT_COLOR', '#FF3B33');
    define('WD_TEXT_COLOR', '#606789');
    define('WD_SECONDARY_TEXT_COLOR', '#82868A');
    define('WD_HEADER_COLOR', '#162466');
    define('WD_BODY_BACKGROUND', '#fff');


    // Topbar Colors
    define('WD_HEADER_BG', '#ffffff');
    define('WD_NAV_TEXT', '#162466');
    define('WD_NAV_STICKY_BG', '#162466');
    define('WD_NAV_STICKY_TEXT', '#ffffff');
    define('WD_NAV_HOVER_STICKY_TEXT', '#ffffff');
    define('WD_NAV_HOVER_TEXT', '#162466');


    // Footer Colors
    define('WD_FOOTER_BG', '#fff0');
    define('WD_FOOTER_TEXT', '#162466');
    define('WD_COPYRIGHT_BG', '#F0F4FB');
    define('WD_COPYRIGHT_TEXT', '#162466');


    define('WD_DEFAULT_LOGO_HEIGHT', '40');
    define('WD_BODY_FONT_FAMILY', "Poppins, Open Sans, sans-serif");
    define('WD_HEAD_FONT_FAMILY', "Poppins, Open Sans, sans-serif");
    define('WD_NAV_FONT_FAMILY', "Poppins, Open Sans, sans-serif");


  }

}
<?php
global $wp_query;
$digixon_thePageID = "";
if (is_object($wp_query) && is_object($wp_query->post) && isset($wp_query->post->ID)) {
  if (!is_search() and !is_404()) {
    $digixon_thePageID = $wp_query->post->ID;
  }
}


$digixon_style = get_post_meta($digixon_thePageID, 'wd_page_title_area_style', true);
$digixon_page_bg_img = get_post_meta($digixon_thePageID, 'wd_page_title_area_bg_img', true);
$digixon_page_bg_color = get_post_meta($digixon_thePageID, 'wd_page_title_area_bg_color', true);
$title_position = get_post_meta($digixon_thePageID, 'wd_page_title_position', true);
$text_color = get_post_meta($digixon_thePageID, 'wd_page_title_color', true);

wp_enqueue_style('custom-line', get_template_directory_uri() . '/style.css');
//********* inline style ***************/qs
$digixon_custom_css = "";

//-------------title page--------------
$digixon_custom_css .= "
      .titlebar {
        " . esc_html(digixon_check_if_empty('background-image', "$digixon_page_bg_img")) . "
        " . esc_html(digixon_check_if_empty('background-color', $digixon_page_bg_color)) . "
        background-repeat: no-repeat;
      }
      .titlebar #page-title{
      " . /* esc_html(digixon_check_if_empty('text-align', $title_position)) . */ "
      " . esc_html(digixon_check_if_empty('color', $text_color)) . "
      }
      #page-title,.breadcrumbs a{
        " . esc_html(digixon_check_if_empty('color', $text_color)) . "
      }
      
      
      ";


if ($digixon_page_bg_img == "") {

  $digixon_title_bg_image = "";
  if (digixon_get_option('digixon_title_bg_image') != "") {
    $digixon_title_bg_image = digixon_get_option('digixon_title_bg_image');
  }
  $digixon_404_bg_image = digixon_get_option('wd_404_page');
  if ($digixon_title_bg_image !== '') {
    $digixon_custom_css .= "
      .titlebar {
        " . esc_html(digixon_check_if_empty('background-image', "$digixon_title_bg_image")) . "
        " . esc_html(digixon_check_if_empty('text-align', get_post_meta($digixon_thePageID, 'wd_page_title_position', true))) . "
      }
    
      #page-title,.breadcrumbs a{
       " . esc_html(digixon_check_if_empty('color', get_post_meta($digixon_thePageID, 'wd_page_title_color', true))) . "
      }";
  }
  if ($digixon_404_bg_image != '') {
    $digixon_custom_css .= "
			.corp-titlebar{
				background:url($digixon_404_bg_image)  no-repeat center top;
				background-size: cover;
		 }";
  }
}

$digixon_custom_css .= "
	  .header-top.social_top_bar, .orange_bar {
			" . esc_html(digixon_check_if_empty('background', digixon_get_option('adress_bar_bgcolor'))) . "
		}
	  .header-top.social_top_bar, .orange_bar,
	  .l-header .header-top .contact-info,
	  .l-header .header-top i,
	  .l-header .header-top .social-icons.accent li i,
	  #lang_sel_list a.lang_sel_sel, #lang_sel_list > ul > li a {
			" . esc_html(digixon_check_if_empty('color', digixon_get_option('adress_bar_color'))) . "		
		}
		";

if (is_rtl()) {
  $digixon_custom_css .= "body, p, #lang_sel_list {
            font-family : 'Droid Arabic Kufi', serif;
          } ";

  $digixon_custom_css .= "h1, h2, h3, h4, h5, h6 {
              font-family : 'Droid Arabic Naskh', serif;
            } ";
} else {
  if ((digixon_get_option('wd_body_font_familly') != 'default') && (digixon_get_option('wd_body_font_familly') != false)) {
    $digixon_custom_css .= "body, body p {
		  " . esc_html(digixon_check_if_empty('font-size', digixon_get_option('wd_body_font_size'))) . "
		  " . esc_html(digixon_check_if_empty('font-family', digixon_get_option('wd_body_font_familly'))) . "
		  " . esc_html(digixon_check_if_empty('font-style', digixon_get_option('wd_body_font_style'))) . "
		  " . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('wd_body_font_weight'))) . "
    }";
    if (digixon_get_option('wd_main_text_lettre_spacing') != false && digixon_get_option('wd_main_text_lettre_spacing') != "") {
      $digixon_custom_css .= "body, body p {   	
		    " . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('wd_main_text_lettre_spacing'))) . ";
	  	}";
    }

  } else {
    $digixon_custom_css .= "body, body p {
    	font-family: 'Open Sans', sans-serif;
    	font-weight :" . esc_html(digixon_get_option('wd_font-weight-style')) . ";
    }";
    if (digixon_get_option('wd_main_text_lettre_spacing') != false && digixon_get_option('wd_main_text_lettre_spacing') != "") {
      $digixon_custom_css .= "body, body p {
	    	letter-spacing :" . esc_html(digixon_get_option('wd_main_text_lettre_spacing')) . ";
	  	}";
    }
  }
  if ((digixon_get_option('wd_head_font_familly') != 'default') && (digixon_get_option('wd_head_font_familly') != false)) {
    $digixon_custom_css .= "h1, h2, h3, h4, h5, h6, .menu-list a {
    	" . esc_html(digixon_check_if_empty('font-family',  digixon_get_option('wd_head_font_familly'))) . "
    	" . esc_html(digixon_check_if_empty('font-style',  digixon_get_option('wd_head_font_style'))) . "
    	" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('wd_heading-font-weight-style'))) . "
    }";
    if (digixon_get_option('wd_heading_text_lettre_spacing') != false && digixon_get_option('wd_heading_text_lettre_spacing') != "") {
      $digixon_custom_css .= "h1, h2, h3, h4, h5, h6, .menu-list a {
	    	letter-spacing :" . esc_html(digixon_get_option('wd_heading_text_lettre_spacing')) . ";
	  	}";
    }
  } else {
    $digixon_custom_css .= "h1, h2, h3, h4, h5, h6, .menu-list a {
      " . esc_html(digixon_check_if_empty('font-family', digixon_get_option('wd_head_font_familly'))) . "
    	" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('wd_heading-font-weight-style'))) . "
    }";
    if (digixon_get_option('wd_heading_text_lettre_spacing') != false && digixon_get_option('wd_heading_text_lettre_spacing') != "") {
      $digixon_custom_css .= "h1, h2, h3, h4, h5, h6, .menu-list a {
	    	letter-spacing :" . esc_html(digixon_get_option('wd_heading_text_lettre_spacing')) . ";
	  	}";
    }
  }

  if ((digixon_get_option('wd_navigation_font_familly') != 'default') && (digixon_get_option('wd_navigation-font-weight-style') != false)) {
    $digixon_custom_css .= ".top-bar .top-bar-right .menu li a {
    	    font-size :" . esc_html(digixon_get_option('wd_navigation_font_size')) . ";
			font-family : " . esc_html(digixon_get_option('wd_navigation_font_familly')) . ";
			font-style : " . esc_html(digixon_get_option('wd_navigation_font_style')) . ";
			font-weight : " . esc_html(digixon_get_option('wd_navigation-font-weight-style')) . ";
			text-transform : " . esc_html(digixon_get_option('wd_navigation_text_transform')) . ";

		}";
    if (digixon_get_option('wd_navigation_text_lettre_spacing') != false && digixon_get_option('wd_navigation_text_lettre_spacing') != "") {
      $digixon_custom_css .= ".top-bar-section ul li > a {
	    	letter-spacing :" . esc_html(digixon_get_option('wd_navigation_text_lettre_spacing')) . ";
	  	}";
    }
  } else {
    $digixon_custom_css .= ".corporate-layout .top-bar-section ul.menu > li > a {
			font-family: " . esc_html(digixon_get_option('wd_navigation_font_familly')) . ";
			font-weight : " . esc_html(digixon_get_option('wd_navigation-font-weight-style')) . ";
		}";
    if (digixon_get_option('wd_navigation_text_lettre_spacing') != false && digixon_get_option('wd_navigation_text_lettre_spacing') != "") {
      $digixon_custom_css .= ".top-bar-section ul li > a {
	    	letter-spacing :" . esc_html(digixon_get_option('wd_navigation_text_lettre_spacing')) . ";
	  	}";
    }
  }
}
$digixon_custom_css .= "header.l-header .top-bar-container .top-bar .top-bar-left .logo-wrapper .menu-text a img {
        max-height:".esc_html(digixon_get_option('height_logo','50'))."px;
}
header.l-header .top-bar-container.sticky .site-navigation.top-bar .top-bar-left .top-bar-title .logo-wrapper .menu-text {
padding: ".esc_html(digixon_get_option('logo_padding','0')).";
}
";
$digixon_custom_css .= "
    :root {
      --primary-color:   " . esc_html(digixon_get_option('primary_color',   '#162466')) . ";
      --secondary-color: " . esc_html(digixon_get_option('secondary_color', '#5164E5')) . ";
      --accent-color:    " . esc_html(digixon_get_option('accent_color',    '#FF3B33')) . ";
      
      --header-color:    " . esc_html(digixon_get_option('header_color')) . ";
      --body-background-color:    " . esc_html(digixon_get_option('body_bg_color',    '#fff')) . ";
      
      --topbar-background:           " . esc_html(digixon_get_option('header_bg',                          '#ffffff')) . ";
      --topbar-text:                 " . esc_html(digixon_get_option('navigation_text_color',              '#162466')) . ";
      --topbar-sticky-bg:            " . esc_html(digixon_get_option('navigation_bg_color_sticky',         '#fff')) . ";
      --topbar-sticky-text:          " . esc_html(digixon_get_option('navigation_text_color_sticky',       '#ffffff')) . ";
      --topbar-hover-stycky-text:    " . esc_html(digixon_get_option('navigation_h_text_color_sticky',     '#ffffff')) . ";
      --topbar-hover-text:           " . esc_html(digixon_get_option('navigation_h_text_color',            '#162466')) . ";
   
      --footer-background:            " . esc_html(digixon_get_option('footer_bg_color',         '#fff')) . ";
      --footer-background-image:            url(" . esc_html(digixon_get_option('wd_footer_bg_image',         '../images/footer-bg.png')) . ");
      --footer-text:                  " . esc_html(digixon_get_option('footer_text_color',       '#162466')) . ";
      --copyright-background:         " . esc_html(digixon_get_option('copyright_bg',     '#ffffff')) . ";
      --copyright-text:               " . esc_html(digixon_get_option('copyright_text_color',            '#162466')) . ";
    }
    
    ";

$social_bar_color = digixon_get_option('social_bar_color');
if ($social_bar_color) {
  $digixon_custom_css .= "
											.top-header {
    									background-color:" . $social_bar_color . " ;
												}
												";
}
$adress_bar_color = digixon_get_option('adress_bar_color');
if ($adress_bar_color) {
  $digixon_custom_css .= "
											.top-header .__top-header-right p {
    									color:" . $adress_bar_color . " ;
												}
												";
}


$digixon_custom_css .= "
		.wd-heading{
		" . esc_html(digixon_check_if_empty('margin-top', digixon_get_option('heading_space_top'))) . ";
		" . esc_html(digixon_check_if_empty('margin-bottom', digixon_get_option('heading_space_bottom'))) . ";
		}";

$digixon_custom_css .= "
		.wd-heading .title_a {
		" . esc_html(digixon_check_if_empty('font-family', digixon_get_option('heading_a_title_font_family'))) . "
		" . esc_html(digixon_check_if_empty('font-style', digixon_get_option('heading_a_title_font_style'))) . "
		" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('heading_a_title_font_weight'))) . "
		" . esc_html(digixon_check_if_empty('font-size', digixon_get_option('heading_a_title_font_size'))) . "
		" . esc_html(digixon_check_if_empty('color', digixon_get_option('heading_a_title_font_color'))) . "
		" . esc_html(digixon_check_if_empty('text-transform', digixon_get_option('heading_a_title_text_transform'))) . "
		" . esc_html(digixon_check_if_empty('line-height', digixon_get_option('heading_a_title_line_height'))) . "
		" . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('heading_a_title_letter_spacing'))) . "
		}
		.wd-heading .sub_title_a {
		" . esc_html(digixon_check_if_empty('font-family', digixon_get_option('heading_a_subtitle_font_family'))) . "
		" . esc_html(digixon_check_if_empty('font-style', digixon_get_option('heading_a_subtitle_font_style'))) . "
		" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('heading_a_subtitle_font_weight'))) . "
		" . esc_html(digixon_check_if_empty('font-size', digixon_get_option('heading_a_subtitle_font_size'))) . "
		" . esc_html(digixon_check_if_empty('color', digixon_get_option('heading_a_subtitle_font_color'))) . "
		" . esc_html(digixon_check_if_empty('text-transform', digixon_get_option('heading_a_subtitle_text_transform'))) . "
		" . esc_html(digixon_check_if_empty('line-height', digixon_get_option('heading_a_subtitle_line_height'))) . "
		" . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('heading_a_subtitle_letter_spacing'))) . "
		
		}

		";

$digixon_custom_css .= "
		.wd-heading .title_b {
		" . esc_html(digixon_check_if_empty('font-family', digixon_get_option('heading_b_title_font_family'))) . "
		" . esc_html(digixon_check_if_empty('font-style', digixon_get_option('heading_b_title_font_style'))) . "
		" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('heading_b_title_font_weight'))) . "
		" . esc_html(digixon_check_if_empty('font-size', digixon_get_option('heading_b_title_font_size'))) . "
		" . esc_html(digixon_check_if_empty('color', digixon_get_option('heading_b_title_font_color'))) . "
		" . esc_html(digixon_check_if_empty('text-transform', digixon_get_option('heading_b_title_text_transform'))) . "
		" . esc_html(digixon_check_if_empty('line-height', digixon_get_option('heading_b_title_line_height'))) . "
		" . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('heading_b_title_letter_spacing'))) . "
		}
		.wd-heading .sub_title_b {
		" . esc_html(digixon_check_if_empty('font-family', digixon_get_option('heading_b_subtitle_font_family'))) . "
		" . esc_html(digixon_check_if_empty('font-style', digixon_get_option('heading_b_subtitle_font_style'))) . "
		" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('heading_b_subtitle_font_weight'))) . "
		" . esc_html(digixon_check_if_empty('font-size', digixon_get_option('heading_b_subtitle_font_size'))) . "
		" . esc_html(digixon_check_if_empty('color', digixon_get_option('heading_b_subtitle_font_color'))) . "
		" . esc_html(digixon_check_if_empty('text-transform', digixon_get_option('heading_b_subtitle_text_transform'))) . "
		" . esc_html(digixon_check_if_empty('line-height', digixon_get_option('heading_b_subtitle_line_height'))) . "
		" . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('heading_b_subtitle_letter_spacing'))) . "
		}
		";
$digixon_custom_css .= "
		.wd-heading .title_c {
		" . esc_html(digixon_check_if_empty('font-family', digixon_get_option('heading_c_title_font_family'))) . "
		" . esc_html(digixon_check_if_empty('font-style', digixon_get_option('heading_c_title_font_style'))) . "
		" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('heading_c_title_font_weight'))) . "
		" . esc_html(digixon_check_if_empty('font-size', digixon_get_option('heading_c_title_font_size'))) . "
		" . esc_html(digixon_check_if_empty('color', digixon_get_option('heading_c_title_font_color'))) . "
		" . esc_html(digixon_check_if_empty('text-transform', digixon_get_option('heading_c_title_text_transform'))) . "
		" . esc_html(digixon_check_if_empty('line-height', digixon_get_option('heading_c_title_line_height'))) . "
		" . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('heading_c_title_letter_spacing'))) . "
		}
		.wd-heading .sub_title_c {
		" . esc_html(digixon_check_if_empty('font-family', digixon_get_option('heading_c_subtitle_font_family'))) . "
		" . esc_html(digixon_check_if_empty('font-style', digixon_get_option('heading_c_subtitle_font_style'))) . "
		" . esc_html(digixon_check_if_empty('font-weight', digixon_get_option('heading_c_subtitle_font_weight'))) . "
		" . esc_html(digixon_check_if_empty('font-size', digixon_get_option('heading_c_subtitle_font_size'))) . "
		" . esc_html(digixon_check_if_empty('color', digixon_get_option('heading_c_subtitle_font_color'))) . "
		" . esc_html(digixon_check_if_empty('text-transform', digixon_get_option('heading_c_subtitle_text_transform'))) . "
		" . esc_html(digixon_check_if_empty('line-height', digixon_get_option('heading_c_subtitle_line_height'))) . "
		" . esc_html(digixon_check_if_empty('letter-spacing', digixon_get_option('heading_c_subtitle_letter_spacing'))) . "
		}
		";

$digixon_custom_css .= "
		.wd-heading .hr_a {
		" . esc_html(digixon_check_if_empty('border-bottom-style', digixon_get_option('headings_a_separator_style'))) . "
		" . esc_html(digixon_check_if_empty('border-bottom-width', digixon_get_option('heading_a_separator_width'))) . "
		" . esc_html(digixon_check_if_empty('border-bottom-color', digixon_get_option('heading_a_separator_color'))) . "
		}
";
$digixon_custom_css .= "
		.wd-heading .hr_b {
		" . esc_html(digixon_check_if_empty('border-bottom-style', digixon_get_option('headings_b_separator_style'))) . "
		" . esc_html(digixon_check_if_empty('border-bottom-width', digixon_get_option('heading_b_separator_width'))) . "
		" . esc_html(digixon_check_if_empty('border-bottom-color', digixon_get_option('heading_b_separator_color'))) . "
		}
";
$digixon_custom_css .= "
		.wd-heading .hr_c {
		" . esc_html(digixon_check_if_empty('border-bottom-style', digixon_get_option('headings_c_separator_style'))) . "
		" . esc_html(digixon_check_if_empty('border-bottom-width', digixon_get_option('heading_c_separator_width'))) . "
		" . esc_html(digixon_check_if_empty('border-bottom-color', digixon_get_option('heading_c_separator_color'))) . "
		}
";
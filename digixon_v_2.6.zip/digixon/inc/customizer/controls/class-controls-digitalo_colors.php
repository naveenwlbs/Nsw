<?php

class digixon_Customizer_Controls_Colors extends digixon_Customizer_Controls
{

  public $controls = array();

  public function __construct()
  {
    $this->section = 'digixon_colors';
    //  $this->priority = new digixon_Customizer_Priority(0, 1);

    parent::__construct();

    add_action('customize_register', array($this, 'add_controls'), 30);
    add_action('customize_register', array($this, 'set_controls'), 35);
  }

  public function add_controls($wp_customize)
  {
    $this->controls = array(
      'wd_options_array[primary_color]' => array(
        'label' => __('Primary', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_PRIMARY_COLOR,
        'settings' => 'wd_options_array[primary_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_PRIMARY_COLOR, "digixon")
      ),
      'wd_options_array[secondary_color]' => array(
        'label' => __('Secondary', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_SECONDARY_COLOR,
        'settings' => 'wd_options_array[secondary_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_SECONDARY_COLOR, "digixon")
      ),
      'wd_options_array[accent_color]' => array(
        'label' => __('Accent', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_ACCENT_COLOR,
        'settings' => 'wd_options_array[accent_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_ACCENT_COLOR, "digixon")
      ),
      'wd_options_array[text_color]' => array(
        'label' => __('Text Color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_TEXT_COLOR,
        'settings' => 'wd_options_array[text_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_TEXT_COLOR, "digixon")
      ),
      'wd_options_array[secondary_text_color]' => array(
        'label' => __('Secondary Text Color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_SECONDARY_TEXT_COLOR,
        'settings' => 'wd_options_array[secondary_text_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_SECONDARY_TEXT_COLOR, "digixon")
      ),
      'wd_options_array[header_color]' => array(
        'label' => __('Header Text Color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_HEADER_COLOR,
        'settings' => 'wd_options_array[header_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_HEADER_COLOR, "digixon")
      ),
      'wd_options_array[body_bg_color]' => array(
        'label' => __('Body Background Color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_BODY_BACKGROUND,
        'settings' => 'wd_options_array[body_bg_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_BODY_BACKGROUND, "digixon")
      ),
      'wd_options_array[header_bg]' => array(
        'label' => __('Header background', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_HEADER_BG,
        'settings' => 'wd_options_array[header_bg]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_HEADER_BG, "digixon")
      ),
      'wd_options_array[navigation_text_color]' => array(
        'label' => __('Navigation Text Color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_NAV_TEXT,
        'settings' => 'wd_options_array[navigation_text_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_TEXT, "digixon")
      ),
      'wd_options_array[navigation_bg_color_sticky]' => array(
        'label' => __('Navigation (sticky) background color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_NAV_STICKY_BG,
        'settings' => 'wd_options_array[navigation_bg_color_sticky]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_STICKY_BG, "digixon")
      ),
      'wd_options_array[navigation_text_color_sticky]' => array(
        'label' => __('Navigation (sticky) text color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_NAV_STICKY_TEXT,
        'settings' => 'wd_options_array[navigation_text_color_sticky]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_STICKY_TEXT, "digixon")
      ),
      'wd_options_array[navigation_h_text_color_sticky]' => array(
        'label' => __('Navigation (Hover sticky) text color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_NAV_HOVER_STICKY_TEXT,
        'settings' => 'wd_options_array[navigation_h_text_color_sticky]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_HOVER_STICKY_TEXT, "digixon")
      ),
      'wd_options_array[navigation_h_text_color]' => array(
        'label' => __('Navigation (Hover) text color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_NAV_HOVER_TEXT,
        'settings' => 'wd_options_array[navigation_h_text_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_HOVER_TEXT, "digixon")
      ),
      'wd_options_array[footer_bg_color]' => array(
        'label' => __('Footer background color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_FOOTER_BG,
        'settings' => 'wd_options_array[footer_bg_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_FOOTER_BG, "digixon")
      ),
      'wd_options_array[footer_text_color]' => array(
        'label' => __('Footer text color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_FOOTER_TEXT,
        'settings' => 'wd_options_array[footer_text_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_FOOTER_TEXT, "digixon")
      ),
      'wd_options_array[copyright_bg]' => array(
        'label' => __('Copyright background color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_COPYRIGHT_BG,
        'settings' => 'wd_options_array[copyright_bg]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_COPYRIGHT_BG, "digixon")
      ),
      'wd_options_array[copyright_text_color]' => array(
        'label' => __('Copyright bar text color', 'digixon'),
        'type' => 'WP_Customize_Color_Control',
        'default' => WD_COPYRIGHT_TEXT,
        'settings' => 'wd_options_array[copyright_text_color]',
        'description' => esc_html__("Pick a unlimited main color for the theme default: " . WD_COPYRIGHT_TEXT, "digixon")
      ),
    );

    return $this->controls;
  }

}

new digixon_Customizer_Controls_Colors();

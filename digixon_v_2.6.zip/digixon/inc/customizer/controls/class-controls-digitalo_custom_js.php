<?php

class digixon_Customizer_Controls_Custom_CSS_JS extends digixon_Customizer_Controls
{

  public $controls = array();

  public function __construct()
  {
    $this->section = 'digixon_custom_js';
    $this->priority = new digixon_Customizer_Priority(49, 1);

    parent::__construct();

    add_action('customize_register', array($this, 'add_controls'), 30);
    add_action('customize_register', array($this, 'set_controls'), 35);
  }

  public function add_controls($wp_customize)
  {
    $this->controls = array(
      'wd_options_array[digixon_theme_custom_js]' => array(
        'label' => __('Custom JavaScript', 'digixon'),
        'type' => 'textarea',
        'default' => digixon_get_option('digixon_theme_custom_js'),
        'description' => 'Custom JavaScript',
        'input_attrs' => array(
          'placeholder' => esc_html__('Put your JavaScript here', 'digixon')
        )
      ),
    );

    return $this->controls;
  }

}

new digixon_Customizer_Controls_Custom_CSS_JS();

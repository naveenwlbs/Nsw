<?php

class digixon_Customizer_Controls_Footer extends digixon_Customizer_Controls
{

  public $controls = array();

  public function __construct()
  {
    $this->section = 'digixon_footer';
    $this->priority = new digixon_Customizer_Priority(49, 1);

    parent::__construct();

    add_action('customize_register', array($this, 'add_controls'), 30);
    add_action('customize_register', array($this, 'set_controls'), 35);
  }

  public function add_controls($wp_customize)
  {
    $this->controls = array(
      'wd_options_array[wd_footer_columns]' => array(
        'label' => __('Footer columns', 'digixon'),
        'type' => 'radio',
        'default' => digixon_get_option('wd_footer_columns'),
        'choices' => array(
          'one_columns' => __('1 Column', 'digixon'),
          'tow_a_columns' => __('2 columns (1/2 + 1/2)', 'digixon'),
          'tow_b_columns' => __('2 columns (1/3 + 2/3)', 'digixon'),
          'tow_c_columns' => __('2 columns (2/3 + 1/3)', 'digixon'),
          'three_columns' => __('3 columns', 'digixon'),
          'four_columns' => __('4 columns', 'digixon'),
        ),
        'sanitize_callback' => 'esc_attr',
        'description' => __('Footer columns', 'digixon')
      ),
      'wd_options_array[wd_footer_bg_image]' => array(
        'label' => __('Footer background image', 'digixon'),
        'type' => 'WP_Customize_Image_Control',
        'default' => digixon_get_option('wd_footer_bg_image'),
        'settings' => 'wd_options_array[wd_footer_bg_image]'
      ),
      'wd_options_array[digixon_copyright]' => array(
        'label' => __('Footer Copyright Text', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('digixon_copyright'),
        'description' => 'Footer copyright text',
        'input_attrs' => array(
          'placeholder' => esc_html__('Footer copyright text', 'digixon')
        )
      ),
      'wd_options_array[wd_poweredby]' => array(
        'label' => __('Powered by text', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('wd_poweredby'),
        'input_attrs' => array(
          'placeholder' => esc_html__('Powered by', 'digixon')
        )
      )
    );

    return $this->controls;
  }

}

new digixon_Customizer_Controls_Footer();

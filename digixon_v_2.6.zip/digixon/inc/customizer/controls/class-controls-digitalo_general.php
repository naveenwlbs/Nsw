<?php

class digixon_Customizer_Controls_General extends digixon_Customizer_Controls
{

  public $controls = array();

  public function __construct()
  {
    $this->section = 'digixon_general';
    //   $this->priority = new digixon_Customizer_Priority(0, 1);

    parent::__construct();

    add_action('customize_register', array($this,
      'add_controls'), 30);
    add_action('customize_register', array($this,
      'set_controls'), 35);
  }

  public function add_controls($wp_customize)
  {
    $this->controls = array(
      'wd_options_array[wd_box_wrapper]' => array(
        'label' => __('Boxed Layout', 'digixon'),
        'type' => 'radio',
        'default' => digixon_get_option('wd_box_wrapper'),
        'settings' => 'wd_options_array[wd_box_wrapper]',
        'choices' => array(
          'on' => 'Yes',
          'of' => 'No',
        ),
      ),
      'wd_options_array[wd_call_to_action]' => array(
        'label' => __('Call to Action Button', 'digixon'),
        'type' => 'textarea',
        'default' => digixon_get_option('wd_call_to_action'),
        'settings' => 'wd_options_array[wd_call_to_action]'
      ),
      'wd_options_array[wd_home_page]' => array(
        'label' => __('Background image', 'digixon'),
        'type' => 'WP_Customize_Image_Control',
        'default' => digixon_get_option('wd_home_page'),
        'settings' => 'wd_options_array[wd_home_page]'
      ),
      'wd_options_array[digixon_title_bg_image]' => array(
        'label' => __('Default Title Bar background image', 'digixon'),
        'type' => 'WP_Customize_Image_Control',
        'default' => digixon_get_option('digixon_title_bg_image'),
        'settings' => 'wd_options_array[digixon_title_bg_image]'
      ),
      'wd_options_array[shred_map_key]' => array(
        'label' => __('Google Key Map', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('shred_map_key'),
        'settings' => 'wd_options_array[shred_map_key]',
      ),
    );

    return $this->controls;
  }

}

new digixon_Customizer_Controls_General();

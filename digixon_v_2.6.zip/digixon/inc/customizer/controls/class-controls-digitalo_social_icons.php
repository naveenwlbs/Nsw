<?php

class digixon_Customizer_Controls_Social_Icons extends digixon_Customizer_Controls
{

  public $controls = array();

  public function __construct()
  {
    $this->section = 'digixon_social_icons';
    //   $this->priority = new digixon_Customizer_Priority(0, 1);

    parent::__construct();

    add_action('customize_register', array($this, 'add_controls'), 30);
    add_action('customize_register', array($this, 'set_controls'), 35);
  }

  public function add_controls($wp_customize)
  {
    $this->controls = array(
      'wd_options_array[digixon_facebook]' => array(
        'label' => __('Facebook', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('digixon_facebook'),
        'description' => 'Facebook',
        'input_attrs' => array(
          'placeholder' => esc_html__('Your Facebook Page Link', 'digixon')
        )
      ),
      'wd_options_array[digixon_twitter]' => array(
        'label' => __('Twitter', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('digixon_twitter'),
        'description' => 'Twitter',
        'input_attrs' => array(
          'placeholder' => esc_html__('Your Twitter Page Link', 'digixon')
        )
      ),
      'wd_options_array[digixon_google_plus]' => array(
        'label' => __('Google+', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('digixon_google_plus'),
        'description' => 'Google+',
        'input_attrs' => array(
          'placeholder' => esc_html__('Your Google+ Page Link', 'digixon')
        )
      ),
      'wd_options_array[digixon_phone]' => array(
        'label' => __('Phone', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('digixon_phone'),
        'description' => 'Phone',
        'input_attrs' => array(
          'placeholder' => esc_html__('Your Phone number', 'digixon')
        )
      ),
      'wd_options_array[digixon_address]' => array(
        'label' => __('Address', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('digixon_address'),
        'description' => 'Address',
        'input_attrs' => array(
          'placeholder' => esc_html__('Your first Address', 'digixon')
        )
      )
    );

    return $this->controls;
  }

}

new digixon_Customizer_Controls_Social_Icons();

<?php

class digixon_Customizer_Controls_top_header extends digixon_Customizer_Controls
{

  public $controls = array();

  public function __construct()
  {
    $this->section = 'digixon_top_header';
    //   $this->priority = new digixon_Customizer_Priority(0, 1);

    parent::__construct();

    add_action('customize_register', array($this, 'add_controls'), 30);
    add_action('customize_register', array($this, 'set_controls'), 35);
  }

  public function add_controls($wp_customize)
  {
    $this->controls = array(

      'wd_options_array[wd_menu_style]' => array(
        'label' => __('Menu style', 'digixon'),
        'type' => 'select',
        'default' => digixon_get_option('wd_menu_style'),
        'settings' => 'wd_options_array[wd_menu_style]',
        'choices' => array(
          'corporate' => 'corporate',
          'creative' => 'creative',
        ),
      ),
      'wd_options_array[digixon_mobile_menu_layout]' => array(
        'label' => __('Menu Mobile layout', 'digixon'),
        'type' => 'select',
        'default' => digixon_get_option('digixon_mobile_menu_layout'),
        'settings' => 'wd_options_array[digixon_mobile_menu_layout]',
        'choices' => array(
          'default' => 'default',
          'offcanvas' => 'offcanvas',
        ),
      ),
      'wd_options_array[wd_show_title]' => array(
        'label' => __('Show Website Title', 'digixon'),
        'type' => 'radio',
        'default' => digixon_get_option('wd_show_title'),
        'settings' => 'wd_options_array[wd_show_title]',
        'choices' => array(
          'on' => 'Yes',
          '' => 'No',
        ),
      ),
      'wd_options_array[wd_show_logo]' => array(
        'label' => __('Show Website Logo', 'digixon'),
        'type' => 'radio',
        'default' => digixon_get_option('wd_show_logo'),
        'settings' => 'wd_options_array[wd_show_logo]',
        'choices' => array(
          'on' => 'Yes',
          '' => 'No',
        ),
      ),
      'wd_options_array[wd_menu_in_grid]' => array(
        'label' => __('Limit header width to grid layout', 'digixon'),
        'type' => 'radio',
        'default' => digixon_get_option('wd_menu_in_grid'),
        'settings' => 'wd_options_array[wd_menu_in_grid]',
        'choices' => array(
          'on' => 'Yes',
          '' => 'No',
        ),
      ),
      'wd_options_array[wd_menu_sticky]' => array(
        'label' => __('Stick the menu to Top', 'digixon'),
        'type' => 'radio',
        'default' => digixon_get_option('wd_menu_sticky'),
        'settings' => 'wd_options_array[wd_menu_sticky]',
        'choices' => array(
          'on' => 'Yes',
          '' => 'No',
        ),
      ),
      'wd_options_array[wd_logo]' => array(
        'label' => __('Logo Link', 'digixon'),
        'type' => 'WP_Customize_Image_Control',
        'default' => digixon_get_option('wd_logo'),
        'settings' => 'wd_options_array[wd_logo]',
      ),
      'wd_options_array[height_logo]' => array(
        'label' => __('Logo Height', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('height_logo'),
        'settings' => 'wd_options_array[height_logo]',
      ),
      'wd_options_array[logo_padding]' => array(
        'label' => __('Logo Padding', 'digixon'),
        'type' => 'text',
        'default' => digixon_get_option('logo_padding'),
        'settings' => 'wd_options_array[logo_padding]',
      ),

    );

    return $this->controls;
  }


}

new digixon_Customizer_Controls_top_header();

<?php
/**
 * Enqueue all styles and scripts
 *
 * Learn more about enqueue_script: {@link https://codex.wordpress.org/Function_Reference/wp_enqueue_script}
 * Learn more about enqueue_style: {@link https://codex.wordpress.org/Function_Reference/wp_enqueue_style }
 *
 * @package digixon
 * @since digixon 1.0.0
 */

function digixon_load_js_css_file(){

  /*----------google -fonts ------------------*/
  $digixon_font_body_name = digixon_get_option('wd_body_font_familly', "default");
  $digixon_font_weight_style = digixon_get_option('wd_body_font_weight_list');
  $digixon_main_text_font_subsets = digixon_get_option('wd_main-text-font-subsets');

  $font_header_name = digixon_get_option('wd_head_font_familly', "Martel");
  $digixon_heading_font_weight_style = digixon_get_option('wd_heading-font-weight-style-list');
  $digixon_heading_text_font_subsets = digixon_get_option('wd_heading-text-font-subsets');

  $digixon_navigation_font_familly = digixon_get_option('wd_navigation_font_familly', "default");
  $digixon_navigation_font_weight_style = digixon_get_option('wd_navigation-font-weight-style-list');
  $digixon_navigation_text_font_subsets = digixon_get_option('wd_navigation-text-font-subsets');


  $digixon_protocol = is_ssl() ? 'https' : 'http';
  if (is_rtl()) {
      wp_enqueue_style('digixon-body-google-fonts', digixon_fonts_url('Droid Arabic Kufi', '400,700', 'latin,latin-ext'), array(), '1.0.0');
  } elseif ($digixon_font_body_name != "default" && $digixon_font_weight_style != "") {
    wp_enqueue_style('digixon_body-google-fonts', digixon_fonts_url($digixon_font_body_name, $digixon_font_weight_style, $digixon_main_text_font_subsets), array(), '1.0.0');
  } else {
      wp_enqueue_style('digixon-body-google-fonts', digixon_fonts_url('Poppins', '300,500,400,600,700', 'latin,latin-ext'), array(), '1.0.0');
  }


  if ($font_header_name != "default" && $digixon_heading_font_weight_style != "") {
    wp_enqueue_style('digixon-header-google-fonts', digixon_fonts_url($font_header_name, $digixon_heading_font_weight_style, $digixon_main_text_font_subsets), array(), '1.0.0');
  }

  if ($digixon_navigation_font_familly != "default" && $digixon_navigation_font_weight_style != "") {
    wp_enqueue_style('digixon-navigation-google-fonts', digixon_fonts_url($digixon_navigation_font_familly, $digixon_navigation_font_weight_style, $digixon_navigation_text_font_subsets), array(), '1.0.0');
  }
    wp_enqueue_style('all',       get_template_directory_uri() . "/css/vendor/all.min.css");
  wp_enqueue_style('animation-custom',      get_template_directory_uri() . "/css/vendor/animate-custom.css");
  wp_enqueue_style('foundation',            get_template_directory_uri() . "/css/vendor/foundation.min.css");
  wp_enqueue_style('digixon-app',  get_template_directory_uri() . "/css/app.css");
  wp_enqueue_style('digixon-style', get_template_directory_uri() . '/style.css');
  wp_enqueue_style('slick',              get_template_directory_uri() . "/css/vendor/slick.min.css");
  wp_enqueue_style('slick-theme',        get_template_directory_uri() . "/css/vendor/slick-theme.min.css");
  wp_enqueue_style('lightbox',              get_template_directory_uri() . "/css/vendor/lightbox.min.css");



  if (is_singular() && get_option('thread_comments'))
    wp_enqueue_script('comment-reply');


  $digixon_map_key = digixon_get_option('digixon_map_key');
if($digixon_map_key != "") {
    wp_enqueue_script('digixon-googlemapskey', $digixon_protocol."://maps.googleapis.com/maps/api/js?key=" . $digixon_map_key . "", array('jquery'), '4.4.2', false);
}

  wp_enqueue_script('digixon-wd-script', get_template_directory_uri() . "/js/wd-script.min.js", array('jquery', 'hoverIntent'),'1.0.0',true);

  include_once(get_template_directory() . '/inc/custom-style.php');

  wp_add_inline_style('digixon-app', $digixon_custom_css);
  //*********/inline style***************/

}

add_action('wp_enqueue_scripts', 'digixon_load_js_css_file');

<?php


function digixon_fonts_url($digixon_font_body_name, $digixon_font_weight_style, $digixon_main_text_font_subsets)
{
  $digixon_font_url = '';

  /*
  Translators: If there are characters in your language that are not supported
  by chosen font(s), translate this to 'off'. Do not translate into your own language.
   */
  if ('off' !== _x('on', 'Google font: on or off', 'digixon')) {
    $digixon_font_url = add_query_arg('family', urlencode($digixon_font_body_name . ':' . $digixon_font_weight_style . '&subset=' . $digixon_main_text_font_subsets), "//fonts.googleapis.com/css");
  }
  return $digixon_font_url;
}
<?php
/**
 *--------------- Image presets-----------
 */

add_image_size('digixon_sidebar-thumb', 160, 140, true);
add_image_size('digixon_blog-thumb', 1200, 500, true);
add_image_size('digixon_blog-related', 900, 190, true);
add_image_size('digixon_blog-sh-thumb', 1000, 500, true);
add_image_size('digixon__testimonial', 172, 172, true);
add_image_size('digixon_thumbnail_shop', 522, 652, true);
add_image_size('digixon_team_style1', 314, 314, true);
add_image_size('digixon_team_style2', 295, 322, true);
add_image_size('digixon_portfolio', 840, 500, true);
add_image_size('digixon_c-portfolio', 596, 832, true);
add_image_size('digixon_pricingtable', 67, 70, true);

//-------------- single portfolio preset -----

add_image_size('digixon_portfolio-thumb', 1000, 400, true);
add_image_size('digixon_single-gt-portfolio', 900, 350, true);
add_image_size('digixon_single-gl-portfolio', 900, 350, true);
add_image_size('digixon_single-st-portfolio', 1500, 500, true);
add_image_size('digixon_single-sl-portfolio', 1000, 700, true);
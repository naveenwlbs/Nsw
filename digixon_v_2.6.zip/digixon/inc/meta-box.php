<?php 
// Instantiate the class
if ( class_exists('digixon_myCustomFields') ) {
	$digixon_myCustomFields_var = new digixon_myCustomFields();
}




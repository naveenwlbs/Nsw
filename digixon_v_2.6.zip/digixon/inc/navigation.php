<?php

// This theme uses wp_nav_menu() in two locations.
register_nav_menus(array(
  'primary' => esc_html__('Primary Navigation', 'digixon'),
  'one-page' => esc_html__('One page Navigation', 'digixon'),
  'right-menu' => esc_html__('Right', 'digixon'),
  'footer-menu' => esc_html__('Footer', 'digixon'),
));


/**
 * Desktop navigation - right top bar
 *
 * @link http://codex.wordpress.org/Function_Reference/wp_nav_menu
 */
if (!function_exists('digixon_top_bar_primary')) {
  function digixon_top_bar_primary()
  {
    if ((get_post_meta(get_the_ID(), 'wd_one_page', true)) && get_post_meta(get_the_ID(), 'wd_one_page', true) == "yes") {
      $primarymenu = "one-page";
    } else {
      $primarymenu = "primary";
    }
    wp_nav_menu(
      array(
        'container' => false,
        'menu_class' => 'desktop-menu menu',
        'theme_location' => $primarymenu,
        'depth' => 4,
        'fallback_cb' => 'digixon_main_menu_fallback',
        'walker' => new digixon_top_bar_walker(),
      )

    );
    ?>
    <div class="header-search">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 129 129" style="width: 24px; margin-right: 20px;"
           class="wd-search-icon">
        <path
          d="M51.6 96.7c11 0 21-3.9 28.8-10.5l35 35c.8.8 1.8 1.2 2.9 1.2s2.1-.4 2.9-1.2c1.6-1.6 1.6-4.2 0-5.8l-35-35c6.5-7.8 10.5-17.9 10.5-28.8 0-24.9-20.2-45.1-45.1-45.1-24.8 0-45.1 20.3-45.1 45.1 0 24.9 20.3 45.1 45.1 45.1zm0-82c20.4 0 36.9 16.6 36.9 36.9C88.5 72 72 88.5 51.6 88.5S14.7 71.9 14.7 51.6c0-20.3 16.6-36.9 36.9-36.9z"></path>
      </svg>
      <?php
      echo '<form role="search" method="get" class="searchform" action="' . esc_url(home_url( '/' )) . '" >
              <div><label class="screen-reader-text">' . esc_html__('Search for:','digixon') . '</label>
                <div class="form-group">
                  <input type="text" class="form-control" value="' . get_search_query() . '" name="s" id="search-desktop" />
                  <button type="submit" id="desktop-searchsubmit" value="'. esc_attr__('Search','digixon') .'" ></button>
                </div>
              </div>
            </form>'
      ?>
    </div>
    <?php
    if (function_exists('WC') && class_exists('xoo_wsc_Public')) {
      ?>
      <div class="show-cart-btn">
        <?php
        $product_cart_count = WC()->cart->cart_contents_count;
        ?>
        <svg viewBox="0 -31 512 512" xmlns="http://www.w3.org/2000/svg" style="width: 25px;">
          <path
            d="M164.96 300.004h.024c.02 0 .04-.004.059-.004H437a15.003 15.003 0 0 0 14.422-10.879l60-210a15.003 15.003 0 0 0-2.445-13.152A15.006 15.006 0 0 0 497 60H130.367l-10.722-48.254A15.003 15.003 0 0 0 105 0H15C6.715 0 0 6.715 0 15s6.715 15 15 15h77.969c1.898 8.55 51.312 230.918 54.156 243.71C131.184 280.64 120 296.536 120 315c0 24.812 20.188 45 45 45h272c8.285 0 15-6.715 15-15s-6.715-15-15-15H165c-8.27 0-15-6.73-15-15 0-8.258 6.707-14.977 14.96-14.996zM477.114 90l-51.43 180H177.032l-40-180zm0 0M150 405c0 24.813 20.188 45 45 45s45-20.188 45-45-20.188-45-45-45-45 20.188-45 45zm45-15c8.27 0 15 6.73 15 15s-6.73 15-15 15-15-6.73-15-15 6.73-15 15-15zm0 0M362 405c0 24.813 20.188 45 45 45s45-20.188 45-45-20.188-45-45-45-45 20.188-45 45zm45-15c8.27 0 15 6.73 15 15s-6.73 15-15 15-15-6.73-15-15 6.73-15 15-15zm0 0">
          </path>
        </svg>
        <span class="min-cart-count">  <?php echo esc_html($product_cart_count); ?> </span>
        <div class="hidden-cart" style="display: none;">
          <?php the_widget('WC_Widget_Cart'); ?>
        </div>
      </div>
      <?php
    }
    if (digixon_get_option('wd_call_to_action') != "") { ?>
      <div class="header-cta show-for-large-up large-screen">
        <?php
       $digixon_call_to_action = digixon_get_option('wd_call_to_action');
        echo html_entity_decode(esc_html($digixon_call_to_action)) ;
        ?>
      </div>
    <?php }
  }
}

/**
 * Mobile navigation - topbar (default) or offcanvas
 */
if (!function_exists('digixon_mobile_nav')) {
  function digixon_mobile_nav()
  {
    wp_nav_menu(
      array(
        'container' => false,                         // Remove nav container
        'menu' => __('mobile-nav', 'digixon'),
        'menu_class' => 'vertical menu',
        'theme_location' => 'primary',
        'items_wrap' => '<ul id="%1$s" class="%2$s" data-accordion-menu data-submenu-toggle="true">%3$s</ul>',
        'fallback_cb' => false,
        'walker' => new digixon_Mobile_Walker(),
      )
    );
    if (digixon_get_option('wd_call_to_action') != "") { ?>
      <div class="header-cta show-for-medium-down">
        <?php $digixon_call_to_action = digixon_get_option('wd_call_to_action');
        echo html_entity_decode(esc_html($digixon_call_to_action)) ; ?>
      </div>
    <?php }
    ?>
    <div class="header-search">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 129 129" style="width: 24px; margin-right: 20px;"
           class="wd-search-icon">
        <path
          d="M51.6 96.7c11 0 21-3.9 28.8-10.5l35 35c.8.8 1.8 1.2 2.9 1.2s2.1-.4 2.9-1.2c1.6-1.6 1.6-4.2 0-5.8l-35-35c6.5-7.8 10.5-17.9 10.5-28.8 0-24.9-20.2-45.1-45.1-45.1-24.8 0-45.1 20.3-45.1 45.1 0 24.9 20.3 45.1 45.1 45.1zm0-82c20.4 0 36.9 16.6 36.9 36.9C88.5 72 72 88.5 51.6 88.5S14.7 71.9 14.7 51.6c0-20.3 16.6-36.9 36.9-36.9z"></path>
      </svg>
      <?php
      echo '<form role="search" method="get" class="searchform" action="' . esc_url(home_url( '/' )) . '" >
              <div><label class="screen-reader-text">' . esc_html__('Search for:','digixon') . '</label>
                <div class="form-group">
                  <input type="text" class="form-control" value="' . get_search_query() . '" name="s" id="search-mobile" />
                  <button type="submit" id="mobile-searchsubmit" value="'. esc_attr__('Search','digixon') .'" ></button>
                </div>
              </div>
            </form>'
      ?>

    </div>
    <?php
    if (function_exists('WC')) {
      ?>
      <div class="show-cart-btn">
        <?php
        $product_cart_count = WC()->cart->cart_contents_count;
        ?>
        <svg viewBox="0 -31 512 512" xmlns="http://www.w3.org/2000/svg" style="width: 25px;">
          <path
            d="M164.96 300.004h.024c.02 0 .04-.004.059-.004H437a15.003 15.003 0 0 0 14.422-10.879l60-210a15.003 15.003 0 0 0-2.445-13.152A15.006 15.006 0 0 0 497 60H130.367l-10.722-48.254A15.003 15.003 0 0 0 105 0H15C6.715 0 0 6.715 0 15s6.715 15 15 15h77.969c1.898 8.55 51.312 230.918 54.156 243.71C131.184 280.64 120 296.536 120 315c0 24.812 20.188 45 45 45h272c8.285 0 15-6.715 15-15s-6.715-15-15-15H165c-8.27 0-15-6.73-15-15 0-8.258 6.707-14.977 14.96-14.996zM477.114 90l-51.43 180H177.032l-40-180zm0 0M150 405c0 24.813 20.188 45 45 45s45-20.188 45-45-20.188-45-45-45-45 20.188-45 45zm45-15c8.27 0 15 6.73 15 15s-6.73 15-15 15-15-6.73-15-15 6.73-15 15-15zm0 0M362 405c0 24.813 20.188 45 45 45s45-20.188 45-45-20.188-45-45-45-45 20.188-45 45zm45-15c8.27 0 15 6.73 15 15s-6.73 15-15 15-15-6.73-15-15 6.73-15 15-15zm0 0">
          </path>
        </svg>
        <span class="min-cart-count">  <?php echo esc_html($product_cart_count); ?> </span>
        <div class="hidden-cart" style="display: none;">
          <?php the_widget('WC_Widget_Cart'); ?>
        </div>
      </div>
      <?php
    }

  }
}


/**
 * Get title bar responsive toggle attribute
 */

if (!function_exists('digixon_title_bar_responsive_toggle')) {
  function digixon_title_bar_responsive_toggle()
  {

    echo 'data-responsive-toggle="mobile-menu"';

  }
}


/**
 * Menu Fallback
 */

function digixon_main_menu_fallback()
{
  echo '<div class="empty-menu">';
  echo esc_html__('Please assign a menu to the primary menu location under ', 'digixon'); ?>
  <a
    href="<?php echo get_admin_url(get_current_blog_id(), 'nav-menus.php') ?>"><?php echo esc_html__('Menus Settings', 'digixon') ?></a>
  </div> <?php
}
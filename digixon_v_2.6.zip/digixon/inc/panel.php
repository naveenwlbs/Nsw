<?php

include_once(get_template_directory() . '/inc/panel/fonts.php');

global $digixon_fontArray;


/*///////////////////////////////// Register Panel Scripts and Styles /////////////////////////////////////////*/
function digixon_admin_register() {

  wp_register_script('wd-admin-main', get_template_directory_uri() . '/inc/js/script.js', array(
    'jquery',
    'jquery-ui-core',
    'jquery-ui-widget',
    'jquery-ui-mouse',
    'jquery-ui-tabs',
    'jquery-ui-droppable',
    'jquery-ui-sortable'
  ), false, false);

  wp_register_style('wd-style', get_template_directory_uri() . '/inc/css/style.css', array(), '20120208', 'all');

  wp_enqueue_media();


  $digixon_font_body_name = digixon_get_option('wd_body_font_familly');
  $digixon_font_weight_style = digixon_get_option('wd_body_font_weight');
  $digixon_main_text_font_subsets = digixon_get_option('wd_main-text-font-subsets');

  $digixon_font_header_name = digixon_get_option('wd_head_font_familly');
  $digixon_heading_font_weight_style = digixon_get_option('wd_heading-font-weight-style');
  $digixon_heading_text_font_subsets = digixon_get_option('wd_heading-text-font-subsets');

  $digixon_navigation_font_familly = digixon_get_option('wd_navigation_font_familly');
  $digixon_navigation_font_weight_style = digixon_get_option('wd_navigation-font-weight-style');
  $digixon_navigation_text_font_subsets = digixon_get_option('wd_navigation-text-font-subsets');
  $protocol = is_ssl() ? 'https' : 'http';

  if ($digixon_font_body_name != "" && $digixon_font_body_name != "default") {
    wp_register_style('wd-google-fonts-body', digixon_fonts_url( esc_html($digixon_font_body_name) , $digixon_font_weight_style , $digixon_main_text_font_subsets ), false, NULL, 'all');
  }
  if ($digixon_font_header_name != "" && $digixon_font_header_name != "default") {
    wp_register_style('wd-google-fonts-heading', digixon_fonts_url( esc_html($digixon_font_header_name) , $digixon_heading_font_weight_style , $digixon_heading_text_font_subsets ), false, NULL, 'all');
  }
  if ($digixon_navigation_font_familly != "" && $digixon_navigation_font_familly != "default") {
    wp_register_style('wd-google-fonts-navigation', digixon_fonts_url( esc_html($digixon_navigation_font_familly) , $digixon_navigation_font_weight_style , $digixon_navigation_text_font_subsets ), false, NULL, 'all');
  }


  if (isset($_GET['page']) && $_GET['page'] == 'option panel') {


  }
  wp_enqueue_script('wd-admin-main');
  wp_enqueue_script('wd-admin-import');
  wp_enqueue_style('wd-style');
  wp_enqueue_style('wd-google-fonts');
  wp_enqueue_style('wd-google-fonts-body');
  wp_enqueue_style('wd-google-fonts-heading');
  wp_enqueue_style('wd-google-fonts-navigation');
  wp_enqueue_style('font-awesome', get_template_directory_uri() . "/inc/css/font-awesome.min.css");

}

add_action('admin_enqueue_scripts', 'digixon_admin_register');


if (!function_exists('digixon_load_color_picker')) {
  add_action('load-widgets.php', 'digixon_load_color_picker');
  function digixon_load_color_picker()
  {
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
  }
}


/*///////////////////////////////// Theme Options /////////////////////////////////////////*/
if (!function_exists('digixon_panel_option')) {
  add_action('admin_menu', 'digixon_panel_option');
  function digixon_panel_option()
  {


    add_theme_page('Digixon Theme Options', 'Digixon Theme Options', 'edit_theme_options', 'digixon-theme-option', 'digixon_theme_option');
    if (class_exists('WebdeviaMainPlugin')) {
      add_theme_page('Import Demo Content', 'Import Demo Content', 'edit_theme_options', 'digixon-demo-content', 'digixon_import_demo');
    }

  }
}


if (!function_exists('digixon_theme_option')) {
  function digixon_theme_option()
  {

    wp_enqueue_media();


    wp_enqueue_script('wp-color-picker');
    wp_enqueue_style('wp-color-picker');


    wp_enqueue_script('colorpick', get_template_directory_uri() . "/inc/js/bootstrap-colorpicker.min.js", array('jquery'));
    wp_enqueue_style('colorpick', get_template_directory_uri() . "/inc/css/bootstrap-colorpicker.min.css");
    wp_enqueue_style('fontawesome', get_template_directory_uri() . "/css/font-awesome.min.css");


    wp_enqueue_script('consilting-js-panel', get_template_directory_uri() . "/inc/js/panel_script.js", array('jquery',
        'jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-mouse', 'jquery-ui-tabs', 'jquery-ui-droppable',
        'jquery-ui-sortable'));
    wp_enqueue_script('consilting-js-import', get_template_directory_uri() . "/inc/js/import_js.js", array('jquery'));
    ?>

    <?php


    if (!empty($_POST)) {

      if (isset($_POST['wd_show_logo']))
        digixon_save_option('wd_show_logo', sanitize_text_field($_POST['wd_show_logo']));
      else
        digixon_save_option('wd_show_logo', '');

      if (isset($_POST['wd_show_top_social_bare']))
        digixon_save_option('wd_show_top_social_bare', sanitize_text_field($_POST['wd_show_top_social_bare']));
      else
        digixon_save_option('wd_show_top_social_bare');

      if (isset($_POST['wd_box_wrapper']))
        digixon_save_option('wd_box_wrapper', sanitize_text_field($_POST['wd_box_wrapper']));
      else
        digixon_save_option('wd_box_wrapper', 'of');


      if (isset($_POST['wd_menu_in_grid'])) {
        digixon_save_option('wd_menu_in_grid', sanitize_text_field($_POST['wd_menu_in_grid']));
      } else {
        digixon_save_option('wd_menu_in_grid', 'off');
      }

      if (isset($_POST['wd_menu_sticky'])) {
        digixon_save_option('wd_menu_sticky', sanitize_text_field($_POST['wd_menu_sticky']));
      } else {
        digixon_save_option('wd_menu_sticky', '');
      }

      if (isset($_POST['wd_page_transitions'])) {
        digixon_save_option('wd_page_transitions', sanitize_text_field($_POST['wd_page_transitions']));
      } else {
        digixon_save_option('wd_page_transitions', 'off');
      }


      if (isset($_POST['wd_show_title'])) {
        digixon_save_option('wd_show_title', sanitize_text_field($_POST['wd_show_title']));
      } else {
        digixon_save_option('wd_show_title', 'of');
      }

      digixon_save_option('wd_footer_bg_image', sanitize_text_field($_POST['settings']['_wd_footer_bg_image']));
      digixon_save_option('footer_bg_color', sanitize_text_field($_POST['footer_bg_color']));
      digixon_save_option('footer_text_color', sanitize_text_field($_POST['footer_text_color']));
      digixon_save_option('wd_copyright', htmlentities(stripslashes($_POST['wd_copyright'])));
      digixon_save_option('wd_poweredby', htmlentities(stripslashes($_POST['wd_poweredby'])));
      digixon_save_option('copyright_text_color', sanitize_text_field($_POST['copyright_text_color']));
      digixon_save_option('wd_logo', sanitize_text_field($_POST['settings']['_wd_logo']));
      digixon_save_option('height_logo', sanitize_text_field($_POST['height_logo']));
      digixon_save_option('logo_padding', sanitize_text_field($_POST['logo_padding']));
      digixon_save_option('digixon_title_bg_image', esc_attr($_POST['settings']['_digixon_title_bg_image']));
      digixon_save_option('wd_404_page', sanitize_text_field($_POST['settings']['_wd_bg_404_page']));
      digixon_save_option('wd_shop_product_per_page', sanitize_text_field($_POST['wd_shop_product_per_page']));
      digixon_save_option('wd_home_page', sanitize_text_field($_POST['settings']['_wd_bg_home_page']));


      if (!function_exists('has_site_icon')) {
        digixon_save_option('wd_favicon', sanitize_text_field($_POST['settings']['_wd_favicon']));
      }

      digixon_save_option('wd_call_to_action', htmlentities(stripslashes($_POST['wd_call_to_action'])));

      digixon_save_option('primary_color', sanitize_text_field($_POST['primary_color']));
      digixon_save_option('secondary_color', sanitize_text_field($_POST['secondary_color']));
      digixon_save_option('accent_color', sanitize_text_field($_POST['accent_color']));
      digixon_save_option('text_color', sanitize_text_field($_POST['text_color']));
      digixon_save_option('secondary_text_color', sanitize_text_field($_POST['secondary_text_color']));
      digixon_save_option('header_color', sanitize_text_field($_POST['header_color']));
      digixon_save_option('body_bg_color', sanitize_text_field($_POST['body_bg_color']));

      digixon_save_option('copyright_bg', sanitize_text_field($_POST['copyright_bg']));
      digixon_save_option('header_bg', sanitize_text_field($_POST['header_bg']));
      digixon_save_option('wd_footer_columns', sanitize_text_field($_POST['wd_footer_columns']));
      digixon_save_option('navigation_text_color', sanitize_text_field($_POST['navigation_text_color']));
      digixon_save_option('navigation_bg_color_sticky', sanitize_text_field($_POST['navigation_bg_color_sticky']));
      digixon_save_option('navigation_text_color_sticky', sanitize_text_field($_POST['navigation_text_color_sticky']));
      digixon_save_option('navigation_h_text_color_sticky', sanitize_text_field($_POST['navigation_h_text_color_sticky']));
      digixon_save_option('navigation_h_text_color', sanitize_text_field($_POST['navigation_h_text_color']));
      digixon_save_option('footer_text_color', sanitize_text_field($_POST['footer_text_color']));


      digixon_save_option('digixon_map_key', sanitize_text_field($_POST['digixon_map_key']));


      digixon_save_option('wd_body_font_familly', sanitize_text_field($_POST['wd_body_font_familly']));
      digixon_save_option('wd_body_font_style', sanitize_text_field($_POST['wd_body_font_style']));
      digixon_save_option('wd_body_font_weight', sanitize_text_field($_POST['wd_body_font_weight']));
      $wd_body_font_weight_list_content = '';
      if (isset($_POST['wd_body_font_weight_list'])) {
        if (is_array($_POST['wd_body_font_weight_list']) && count($_POST['wd_body_font_weight_list']) > 0) {
          foreach ($_POST['wd_body_font_weight_list'] as $lists)
            $wd_body_font_weight_list_content .= $lists . ',';
          $wd_body_font_weight_list_content = trim($wd_body_font_weight_list_content, ',');
        } elseif (!is_array($_POST['wd_body_font_weight_list'])) {
          $wd_body_font_weight_list_content = $_POST['wd_body_font_weight_list'];
        }
      }
      digixon_save_option('wd_body_font_weight_list', sanitize_text_field($wd_body_font_weight_list_content));
      digixon_save_option('wd_body_font_size', sanitize_text_field($_POST['wd_body_font_size']));
      digixon_save_option('wd_main-text-font-subsets', sanitize_text_field($_POST['wd_main-text-font-subsets']));
      digixon_save_option('wd_main_text_lettre_spacing', sanitize_text_field($_POST['wd_main_text_lettre_spacing']));

      digixon_save_option('wd_head_font_familly', sanitize_text_field($_POST['wd_head_font_familly']));
      digixon_save_option('wd_head_font_style', sanitize_text_field($_POST['wd_head_font_style']));
      digixon_save_option('wd_heading-font-weight-style', sanitize_text_field($_POST['wd_heading-font-weight-style']));
      $wd_heading_font_weight_list_content = '';
      if (isset($_POST['wd_heading-font-weight-style-list'])) {
        if (is_array($_POST['wd_heading-font-weight-style-list']) && count($_POST['wd_heading-font-weight-style-list']) > 0) {
          foreach ($_POST['wd_heading-font-weight-style-list'] as $lists)
            $wd_heading_font_weight_list_content .= $lists . ',';
          $wd_heading_font_weight_list_content = trim($wd_heading_font_weight_list_content, ',');
        } elseif (!is_array($_POST['wd_heading-font-weight-style-list'])) {
          $wd_heading_font_weight_list_content = $_POST['wd_heading-font-weight-style-list'];
        }
      }
      digixon_save_option('wd_heading-font-weight-style-list', sanitize_text_field($wd_heading_font_weight_list_content));
      digixon_save_option('wd_heading-text-font-subsets', sanitize_text_field($_POST['wd_heading-text-font-subsets']));
      digixon_save_option('wd_heading_text_lettre_spacing', sanitize_text_field($_POST['wd_heading_text_lettre_spacing']));

      digixon_save_option('wd_navigation_font_familly', sanitize_text_field($_POST['wd_navigation_font_familly']));
      digixon_save_option('wd_navigation_font_style', sanitize_text_field($_POST['wd_navigation_font_style']));
      digixon_save_option('wd_navigation_font_size', sanitize_text_field($_POST['wd_navigation_font_size']));
      digixon_save_option('wd_navigation_text_transform', sanitize_text_field($_POST['wd_navigation_text_transform']));
      digixon_save_option('wd_navigation-font-weight-style', sanitize_text_field($_POST['wd_navigation-font-weight-style']));
      $wd_navigation_font_weight_list_content = '';
      if (isset($_POST['wd_navigation-font-weight-style-list'])) {
        if (is_array($_POST['wd_navigation-font-weight-style-list']) && count($_POST['wd_navigation-font-weight-style-list']) > 0) {
          foreach ($_POST['wd_navigation-font-weight-style-list'] as $lists)
            $wd_navigation_font_weight_list_content .= $lists . ',';
          $wd_navigation_font_weight_list_content = trim($wd_navigation_font_weight_list_content, ',');
        } elseif (!is_array($_POST['wd_navigation-font-weight-style-list'])) {
          $wd_navigation_font_weight_list_content = $_POST['wd_navigation-font-weight-style-list'];
        }
      }
      digixon_save_option('wd_navigation-font-weight-style-list', sanitize_text_field($wd_navigation_font_weight_list_content));
      digixon_save_option('wd_navigation-text-font-subsets', sanitize_text_field($_POST['wd_navigation-text-font-subsets']));
      digixon_save_option('wd_navigation_text_lettre_spacing', sanitize_text_field($_POST['wd_navigation_text_lettre_spacing']));


      digixon_save_option('wd_menu_style', sanitize_text_field($_POST['wd_menu_style']));
      digixon_save_option('digixon_mobile_menu_layout', sanitize_text_field($_POST['digixon_mobile_menu_layout']));

      $socialmedia_name = '';
      if (isset($_POST['socialmedia_name'])) {
        $social_datas = $_REQUEST['socialmedia_name'];
        foreach ($social_datas as $socialdatanam) {
          $socialmedia_name .= $socialdatanam . ' ';
        }
      }
      digixon_save_option('socialmedia_name', sanitize_text_field($socialmedia_name));

      $socialmedia_icon = '';
      if (isset($_POST['social_icon'])) {
        $social_datasicon = $_REQUEST['social_icon'];
        foreach ($social_datasicon as $socialdataicon) {
          $socialmedia_icon .= $socialdataicon . ' ';
        }
      }
      digixon_save_option('social_icon', sanitize_text_field($socialmedia_icon));


      /*
			 * heading shortcode settings
			 */
      digixon_save_option('heading_style', sanitize_text_field($_POST['heading_style']));

      digixon_save_option('heading_top_d_space', sanitize_text_field($_POST['heading_top_d_space']));
      digixon_save_option('heading_top_t_space', sanitize_text_field($_POST['heading_top_t_space']));
      digixon_save_option('heading_top_m_space', sanitize_text_field($_POST['heading_top_m_space']));
      digixon_save_option('heading_bottom_d_space', sanitize_text_field($_POST['heading_bottom_d_space']));
      digixon_save_option('heading_bottom_t_space', sanitize_text_field($_POST['heading_bottom_t_space']));
      digixon_save_option('heading_bottom_m_space', sanitize_text_field($_POST['heading_bottom_m_space']));


      digixon_save_option('heading_a_layout', sanitize_text_field($_POST['heading_a_layout']));
      digixon_save_option('heading_a_alignment', sanitize_text_field($_POST['heading_a_alignment']));
      digixon_save_option('headings_a_separator', sanitize_text_field($_POST['headings_a_separator']));
      digixon_save_option('headings_a_separator_position', sanitize_text_field($_POST['headings_a_separator_position']));
      digixon_save_option('headings_a_separator_style', sanitize_text_field($_POST['headings_a_separator_style']));
      digixon_save_option('heading_a_separator_color', sanitize_text_field($_POST['heading_a_separator_color']));
      digixon_save_option('heading_a_separator_width', sanitize_text_field($_POST['heading_a_separator_width']));

      digixon_save_option('heading_a_title_font_family', sanitize_text_field($_POST['heading_a_title_font_family']));
      digixon_save_option('heading_a_title_font_style', sanitize_text_field($_POST['heading_a_title_font_style']));
      digixon_save_option('heading_a_title_font_weight', sanitize_text_field($_POST['heading_a_title_font_weight']));
      digixon_save_option('heading_a_title_font_size', sanitize_text_field($_POST['heading_a_title_font_size']));
      digixon_save_option('heading_a_title_font_color', sanitize_text_field($_POST['heading_a_title_font_color']));
      digixon_save_option('heading_a_title_text_transform', sanitize_text_field($_POST['heading_a_title_text_transform']));
      digixon_save_option('heading_a_title_line_height', sanitize_text_field($_POST['heading_a_title_line_height']));
      digixon_save_option('heading_a_title_letter_spacing', sanitize_text_field($_POST['heading_a_title_letter_spacing']));

      digixon_save_option('heading_a_subtitle_font_family', sanitize_text_field($_POST['heading_a_subtitle_font_family']));
      digixon_save_option('heading_a_subtitle_font_style', sanitize_text_field($_POST['heading_a_subtitle_font_style']));
      digixon_save_option('heading_a_subtitle_font_weight', sanitize_text_field($_POST['heading_a_subtitle_font_weight']));
      digixon_save_option('heading_a_subtitle_font_size', sanitize_text_field($_POST['heading_a_subtitle_font_size']));
      digixon_save_option('heading_a_subtitle_font_color', sanitize_text_field($_POST['heading_a_subtitle_font_color']));
      digixon_save_option('heading_a_subtitle_text_transform', sanitize_text_field($_POST['heading_a_subtitle_text_transform']));
      digixon_save_option('heading_a_subtitle_line_height', sanitize_text_field($_POST['heading_a_subtitle_line_height']));
      digixon_save_option('heading_a_subtitle_letter_spacing', sanitize_text_field($_POST['heading_a_subtitle_letter_spacing']));


      digixon_save_option('heading_b_layout', sanitize_text_field($_POST['heading_b_layout']));
      digixon_save_option('heading_b_alignment', sanitize_text_field($_POST['heading_b_alignment']));
      digixon_save_option('headings_b_separator', sanitize_text_field($_POST['headings_b_separator']));
      digixon_save_option('headings_b_separator_position', sanitize_text_field($_POST['headings_b_separator_position']));
      digixon_save_option('headings_b_separator_style', sanitize_text_field($_POST['headings_b_separator_style']));
      digixon_save_option('heading_b_separator_color', sanitize_text_field($_POST['heading_b_separator_color']));
      digixon_save_option('heading_b_separator_width', sanitize_text_field($_POST['heading_b_separator_width']));

      digixon_save_option('heading_b_title_font_family', sanitize_text_field($_POST['heading_b_title_font_family']));
      digixon_save_option('heading_b_title_font_style', sanitize_text_field($_POST['heading_b_title_font_style']));
      digixon_save_option('heading_b_title_font_weight', sanitize_text_field($_POST['heading_b_title_font_weight']));
      digixon_save_option('heading_b_title_font_size', sanitize_text_field($_POST['heading_b_title_font_size']));
      digixon_save_option('heading_b_title_font_color', sanitize_text_field($_POST['heading_b_title_font_color']));
      digixon_save_option('heading_b_title_text_transform', sanitize_text_field($_POST['heading_b_title_text_transform']));
      digixon_save_option('heading_b_title_line_height', sanitize_text_field($_POST['heading_b_title_line_height']));
      digixon_save_option('heading_b_title_letter_spacing', sanitize_text_field($_POST['heading_b_title_letter_spacing']));

      digixon_save_option('heading_b_subtitle_font_family', sanitize_text_field($_POST['heading_b_subtitle_font_family']));
      digixon_save_option('heading_b_subtitle_font_style', sanitize_text_field($_POST['heading_b_subtitle_font_style']));
      digixon_save_option('heading_b_subtitle_font_weight', sanitize_text_field($_POST['heading_b_subtitle_font_weight']));
      digixon_save_option('heading_b_subtitle_font_size', sanitize_text_field($_POST['heading_b_subtitle_font_size']));
      digixon_save_option('heading_b_subtitle_font_color', sanitize_text_field($_POST['heading_b_subtitle_font_color']));
      digixon_save_option('heading_b_subtitle_text_transform', sanitize_text_field($_POST['heading_b_subtitle_text_transform']));
      digixon_save_option('heading_b_subtitle_line_height', sanitize_text_field($_POST['heading_b_subtitle_line_height']));
      digixon_save_option('heading_b_subtitle_letter_spacing', sanitize_text_field($_POST['heading_b_subtitle_letter_spacing']));


      digixon_save_option('heading_c_layout', sanitize_text_field($_POST['heading_c_layout']));
      digixon_save_option('heading_c_alignment', sanitize_text_field($_POST['heading_c_alignment']));
      digixon_save_option('headings_c_separator', sanitize_text_field($_POST['headings_c_separator']));
      digixon_save_option('headings_c_separator_position', sanitize_text_field($_POST['headings_c_separator_position']));
      digixon_save_option('headings_c_separator_style', sanitize_text_field($_POST['headings_c_separator_style']));
      digixon_save_option('heading_c_separator_color', sanitize_text_field($_POST['heading_c_separator_color']));
      digixon_save_option('heading_c_separator_width', sanitize_text_field($_POST['heading_c_separator_width']));

      digixon_save_option('heading_c_title_font_family', sanitize_text_field($_POST['heading_c_title_font_family']));
      digixon_save_option('heading_c_title_font_style', sanitize_text_field($_POST['heading_c_title_font_style']));
      digixon_save_option('heading_c_title_font_weight', sanitize_text_field($_POST['heading_c_title_font_weight']));
      digixon_save_option('heading_c_title_font_size', sanitize_text_field($_POST['heading_c_title_font_size']));
      digixon_save_option('heading_c_title_font_color', sanitize_text_field($_POST['heading_c_title_font_color']));
      digixon_save_option('heading_c_title_text_transform', sanitize_text_field($_POST['heading_c_title_text_transform']));
      digixon_save_option('heading_c_title_line_height', sanitize_text_field($_POST['heading_c_title_line_height']));
      digixon_save_option('heading_c_title_letter_spacing', sanitize_text_field($_POST['heading_c_title_letter_spacing']));

      digixon_save_option('heading_c_subtitle_font_family', sanitize_text_field($_POST['heading_c_subtitle_font_family']));
      digixon_save_option('heading_c_subtitle_font_style', sanitize_text_field($_POST['heading_c_subtitle_font_style']));
      digixon_save_option('heading_c_subtitle_font_weight', sanitize_text_field($_POST['heading_c_subtitle_font_weight']));
      digixon_save_option('heading_c_subtitle_font_size', sanitize_text_field($_POST['heading_c_subtitle_font_size']));
      digixon_save_option('heading_c_subtitle_font_color', sanitize_text_field($_POST['heading_c_subtitle_font_color']));
      digixon_save_option('heading_c_subtitle_text_transform', sanitize_text_field($_POST['heading_c_subtitle_text_transform']));
      digixon_save_option('heading_c_subtitle_line_height', sanitize_text_field($_POST['heading_c_subtitle_line_height']));
      digixon_save_option('heading_c_subtitle_letter_spacing', sanitize_text_field($_POST['heading_c_subtitle_letter_spacing']));

    } ?>


    <?php if (!empty($_POST)): ?>
    <div id="message" class="updated fade">
      <p> <?php echo esc_html__('Configuration updated!!', 'digixon'); ?> </p>
    </div>
  <?php endif; ?>


    <div class="panel-logo">
      <h2><?php
        echo wp_get_theme()->get('Name') . esc_html__(' Theme Options', 'digixon');
        echo " <span> " . wp_get_theme()->get('Version') . "</span>" ?>
      </h2>
    </div>
    <div class="wd-cpanel" >
      <form id="wd-Panel" method="POST" action="">
        <div id="tabs" class="ui-tabs-vertical ui-helper-clearfix">
          <ul>
            <li><a href="#tabs-0"><?php echo esc_html__('General Settings', 'digixon'); ?></a></li>
            <li><a href="#tabs-colors"><?php echo esc_html__('Colors Settings', 'digixon'); ?></a></li>
            <li><a href="#tabs-2"><?php echo esc_html__('Fonts Settings', 'digixon'); ?></a></li>
            <li><a href="#tabs-3"><?php echo esc_html__('Special Pages Settings', 'digixon'); ?></a></li>
            <li><a href="#tabs-4"><?php echo esc_html__('Footer settings', 'digixon'); ?></a></li>
            <li><a href="#tabs-5"><?php echo esc_html__('ShortCode settings', 'digixon'); ?></a></li>
          </ul>
          <div id="tabs-0">
            <table class="form-table">
              <tbody>
              <tr>
                <td><strong><?php echo esc_html__('Boxed Layout:', 'digixon'); ?></strong></td>
                <td><input type="checkbox" <?php if (digixon_get_option('wd_box_wrapper', 'of') != 'of')
                    print 'checked'; ?> name="wd_box_wrapper" value="on" id="wd_box_wrapper"
                           class="cmn-toggle cmn-toggle-round"/>
                  <label for="wd_box_wrapper"></label></td>
              </tr>
              <tr>
                <td><strong><?php echo esc_html__('Menu style:', 'digixon'); ?></strong></td>
                <td>
                  <?php $digixon_menu_style = digixon_get_option('wd_menu_style'); ?>
                  <select name="wd_menu_style">
                    <option value="corporate" <?php if ($digixon_menu_style == "corporate")
                      echo "selected"; ?>><?php echo esc_html__('Corporate', 'digixon'); ?></option>
                    <option value="creative" <?php if ($digixon_menu_style == "creative")
                      echo "selected"; ?>><?php echo esc_html__('Creative', 'digixon'); ?></option>
                  </select>
                </td>
              </tr>
              <tr>
                <td><strong><?php echo esc_html__('Menu Mobile layout:', 'digixon'); ?></strong></td>
                <td>
                  <?php $digixon_mobile_menu_layout = digixon_get_option('digixon_mobile_menu_layout'); ?>
                  <select name="digixon_mobile_menu_layout">
                    <option value="default" <?php if ($digixon_mobile_menu_layout == "default")
                      echo "selected"; ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                    <option value="offcanvas" <?php if ($digixon_mobile_menu_layout == "offcanvas")
                      echo "selected"; ?>><?php echo esc_html__('Offcanvas', 'digixon'); ?></option>
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Limit header width to grid layout', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="checkbox" <?php if (digixon_get_option('wd_menu_in_grid') == 'on')
                    print 'checked'; ?> name="wd_menu_in_grid" value="on" id="wd_menu_in_grid"
                         class="cmn-toggle cmn-toggle-round"/>
                  <label for="wd_menu_in_grid"></label>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Stick the menu to Top', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="checkbox" <?php if (digixon_get_option('wd_menu_sticky') == 'on')
                    print 'checked'; ?> name="wd_menu_sticky" value="on" id="wd_menu_sticky"
                         class="cmn-toggle cmn-toggle-round"/>
                  <label for="wd_menu_sticky"></label>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__(' Page Loading Animation', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="checkbox" <?php if (digixon_get_option('wd_page_transitions' ,'on') == 'on')
                    print 'checked'; ?> name="wd_page_transitions" value="on" id="wd_page_transitions"
                         class="cmn-toggle cmn-toggle-round"/>
                  <label for="wd_page_transitions"></label>
                </td>
              </tr>
              <tr
                class="social_link">
                <td>
                  <strong><?php echo esc_html__('Call to Action Button', 'digixon'); ?></strong>
                </td>
                <td>
                  <textarea type="text" rows="10" cols="70" name="wd_call_to_action"
                            placeholder="<?php echo esc_attr__('Call to action button', 'digixon') ?>">
                    <?php
                    $digixon_call_to_action = html_entity_decode(digixon_get_option('wd_call_to_action'));
                    echo esc_html($digixon_call_to_action) ; ?>
                  </textarea>
                </td>
              </tr>
              <tr>
                <td><strong><?php echo esc_html__('Body Background image:', 'digixon'); ?></strong></td>
                <td>
                  <input type="text" name="settings[_wd_bg_home_page]" id="wd_home_page_filed"
                         value="<?php echo esc_attr(digixon_get_option('wd_home_page')) ?>"
                         class="digixon_home_input bg_input_field" data-bgimage="digixon_home"/>
                  <input class="button" name="bg_home_page" id="wd_bg_home_page"
                         value="<?php echo esc_attr('Upload', 'digixon'); ?>"/>
                  <input type="button" value="<?php echo esc_attr('Delete', 'digixon'); ?>"
                         class="button bg_delete_button" data-bgimage="digixon_home"/>
                </td>
                <td class="image-preview">
                  <?php $digixon_title_bg_image = digixon_get_option('wd_home_page'); ?>
                  <img src="<?php print esc_url($digixon_title_bg_image); ?>"
                       class="digixon_home_image"/>
                </td>
              </tr>




              <tr>
                <td colspan="2"><br>
                  <h3><?php echo esc_html__('Logo Settings :', 'digixon'); ?></h3>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Show the Logo', 'digixon'); ?></strong></td>
                <td>
                  <label>
                    <input type="checkbox" <?php if (digixon_get_option('wd_show_logo') == 'on')
                      print 'checked'; ?> name="wd_show_logo" value="on" id="wd_show_logo"
                           class="chekbox_logo cmn-toggle cmn-toggle-round"/>
                    <label for="wd_show_logo"></label></td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Show Website Title', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="checkbox" <?php if (digixon_get_option('wd_show_title') == 'on')
                    print 'checked'; ?> name="wd_show_title" value="on" id="wd_show_title"
                         class="cmn-toggle cmn-toggle-round"/>
                  <label for="wd_show_title"></label>
                </td>
              </tr>
              <tr
                class="path_logo <?php if (digixon_get_option('wd_show_logo', 'off') != "on") :  echo 'hidden'; endif ?>" >
                <td><strong><?php echo esc_html__('Logo link', 'digixon'); ?></strong></td>
                <td>
                  <?php $digixon_logo = digixon_get_option('wd_logo'); ?>
                  <input type="text" name="settings[_wd_logo]" id="wd_logo_filed"
                         value="<?php echo esc_url($digixon_logo) ?>" class="digixon_logo_input bg_input_field"
                         data-bgimage="digixon_logo"/>
                  <input class="button" name="_unique_name_button" id="wd_upload_btn"
                         value="<?php echo esc_attr('Upload', 'digixon'); ?>"/>
                  <input type="button" value="<?php echo esc_attr('Delete', 'digixon'); ?>"
                         class="button bg_delete_button" data-bgimage="digixon_logo"/></br>
                </td>
                <td class="image-preview">
                  <?php $digixon_logo = digixon_get_option('wd_logo'); ?>
                  <img src="<?php print esc_url($digixon_logo); ?>" class="digixon_logo_image"/>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Logo Height', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="text" name="height_logo" value="<?php echo esc_attr(digixon_get_option('height_logo'))  ?>" placeholder="<?php echo WD_DEFAULT_LOGO_HEIGHT ?>"><strong> px<strong>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Logo Padding', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="text" name="logo_padding" value="<?php echo esc_attr(digixon_get_option('logo_padding')) ?>">
                  <p class="description">Ex 10px 10px 10px 10px</p>
                </td>
              </tr>
              <tr class="">
                <td><strong><?php echo esc_html__('Google Key Map', 'digixon'); ?></strong></td>
                <td>
                  <input type="text" class="log_input" name="digixon_map_key"
                         value="<?php echo esc_attr(digixon_get_option("digixon_map_key", "")) ?>"/>
                </td>
              </tr>



              <tr><td colspan="2"><br><h3><?php echo esc_html__('Page Tile Settings :', 'digixon'); ?></h3></td></tr>

              <tr>
                <td><strong><?php echo esc_html__('Default Title Bar background image', 'digixon'); ?></strong></td>
                <td>
                  <input type="text" name="settings[_digixon_title_bg_image]" id="digixon_title_bg_filed"
                         value="<?php echo esc_attr(digixon_get_option('digixon_title_bg_image')) ?>"
                         class="digixon_title_input bg_input_field" data-bgimage="digixon_title"/>
                  <input class="button" name="_unique_title_bg_button" id="digixon_title_bg_btn"
                         value="<?php echo esc_attr('Upload', 'digixon'); ?>"/>
                  <input type="button" value="<?php echo esc_attr('Delete', 'digixon'); ?>"
                         class="button bg_delete_button " data-bgimage="digixon_title"/></br>
                </td>
                <td class="image-preview">
                  <?php $digixon_title_bg_image = digixon_get_option('digixon_title_bg_image'); ?>
                  <img src="<?php print esc_url($digixon_title_bg_image); ?>" class="digixon_title_image"/>
                </td>
              </tr>



              <!--favicon-->
              <?php if (!function_exists('has_site_icon')) { ?>
                <tr>
                  <td><strong><?php echo esc_html__('Favicon link', 'digixon'); ?></strong></td>
                  <td>
                    <input type="text" name="settings[_wd_favicon]" id="wd_favicon_filed"
                           class="digixon_favicon_input bg_input_field" data-bgimage="digixon_favicon"/>
                    <input class="button" name="_unique_name_favicon" id="wd_upload_favicon"
                           value="<?php echo esc_attr('Upload', 'digixon'); ?>"/>
                    <input type="button" value="<?php echo esc_attr('Delete', 'digixon'); ?>"
                           class="button bg_delete_button" data-bgimage="digixon_favicon"/></br>
                  </td>
                  <td class="image-preview"> <?php $digixon_favicon = digixon_get_option('wd_favicon'); ?>
                    <img src="<?php print esc_url($digixon_favicon); ?>"  class="digixon_favicon_image"/>
                  </td>
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>
          <div id="tabs-colors">
            <table class="form-table">
              <tbody>
              <tr>
                <td>
                  <h3>
                    <?php echo esc_html__('Colors:', 'digixon'); ?>
                  </h3>
                  <ul class="assets_colors">
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Primary:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_PRIMARY_COLOR , "digixon") ?></p>
                      <?php $primary_color = digixon_get_option('primary_color'); ?>
                      <input name="primary_color" type="text" value="<?php print esc_attr($primary_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_PRIMARY_COLOR ?>"
                             data-picker="primary_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Secondary:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_SECONDARY_COLOR , "digixon") ?></p>
                      <?php $secondary_color = digixon_get_option('secondary_color'); ?>
                      <input name="secondary_color" type="text" value="<?php print esc_attr($secondary_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_SECONDARY_COLOR ?>"
                             data-picker="secondary_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Accent:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_ACCENT_COLOR , "digixon") ?></p>
                      <?php $accent_color = digixon_get_option('accent_color'); ?>
                      <input name="accent_color" type="text" value="<?php print esc_attr($accent_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_ACCENT_COLOR ?>"
                             data-picker="accent_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Text Color:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_TEXT_COLOR , "digixon") ?></p>
                      <?php $text_color = digixon_get_option('text_color'); ?>
                      <input name="text_color" type="text" value="<?php print esc_attr($text_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_TEXT_COLOR ?>"
                             data-picker="text_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Secondary Text Color:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_SECONDARY_TEXT_COLOR , "digixon") ?></p>
                      <?php $secondary_text_color = digixon_get_option('secondary_text_color'); ?>
                      <input name="secondary_text_color" type="text"
                             value="<?php print esc_attr($secondary_text_color); ?>" class="wd-color-picker"
                             data-default-color="<?php echo WD_SECONDARY_TEXT_COLOR ?>"
                             data-picker="secondary_text_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Head Text Color:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("H1, H2 H3, H4 ... " . WD_HEADER_COLOR , "digixon") ?></p>
                      <?php $header_color = digixon_get_option('header_color'); ?>
                      <input name="header_color" type="text" value="<?php print esc_attr($header_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_HEADER_COLOR ?>"
                             data-picker="header_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Body Background Color:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_BODY_BACKGROUND , "digixon") ?></p>
                      <?php $body_bg_color = digixon_get_option('body_bg_color'); ?>
                      <input name="body_bg_color" type="text" value="<?php print esc_attr($body_bg_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_BODY_BACKGROUND ?>"
                             data-picker="header_color_show">
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>
                  <h3><?php echo esc_html__('TopBar Colors :', 'digixon'); ?></h3>
                  <ul class="assets_colors">
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Header background:', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_HEADER_BG , "digixon") ?></p>
                      <?php $header_bg = digixon_get_option('header_bg'); ?>
                      <input name="header_bg" type="text" value="<?php print esc_attr($header_bg); ?>"
                             class="wd-color-picker"
                             data-default-color="<?php echo WD_HEADER_BG ?>" data-picker="header_bg_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Navigation Text Color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_TEXT , "digixon") ?></p>
                      <?php $navigation_text_color = digixon_get_option('navigation_text_color'); ?>
                      <input name="navigation_text_color" type="text"
                             value="<?php print esc_attr($navigation_text_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_NAV_TEXT ?>"
                             data-picker="navigation_text_color_show">
                    </li>
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Navigation (sticky) background color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_STICKY_BG , "digixon") ?></p>
                      <?php $navigation_bg_color_sticky = digixon_get_option('navigation_bg_color_sticky'); ?>
                      <input name="navigation_bg_color_sticky" type="text"
                             value="<?php print esc_attr($navigation_bg_color_sticky); ?>" class="wd-color-picker"
                             data-default-color="<?php echo WD_NAV_STICKY_BG ?>"
                             data-picker="navigation_bg_color_sticky_show">
                    </li>
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Navigation (sticky) text color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_STICKY_TEXT , "digixon") ?></p>
                      <?php $navigation_text_color_sticky = digixon_get_option('navigation_text_color_sticky'); ?>
                      <input name="navigation_text_color_sticky" type="text"
                             value="<?php print esc_attr($navigation_text_color_sticky); ?>" class="wd-color-picker"
                             data-default-color="<?php echo WD_NAV_STICKY_TEXT ?>"
                             data-picker="navigation_text_color_sticky_show">
                    </li>
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Navigation (Hover sticky) text color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_HOVER_STICKY_TEXT , "digixon") ?></p>
                      <?php $navigation_h_text_color_sticky = digixon_get_option('navigation_h_text_color_sticky'); ?>
                      <input name="navigation_h_text_color_sticky" type="text"
                             value="<?php print esc_attr($navigation_h_text_color_sticky); ?>" class="wd-color-picker"
                             data-default-color="<?php echo WD_NAV_HOVER_STICKY_TEXT ?>"
                             data-picker="navigation_h_text_color_sticky_show">
                    </li>
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Navigation (Hover) text color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_NAV_HOVER_TEXT , "digixon") ?></p>
                      <?php $navigation_h_text_color = digixon_get_option('navigation_h_text_color'); ?>
                      <input name="navigation_h_text_color" type="text"
                             value="<?php print esc_attr($navigation_h_text_color); ?>" class="wd-color-picker"
                             data-default-color="<?php echo WD_NAV_HOVER_TEXT ?>"
                             data-picker="navigation_h_text_color_show">
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>
                  <h3><?php echo esc_html__('Footer Colors :', 'digixon'); ?></h3>
                  <ul class="assets_colors">
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Footer background color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_FOOTER_BG , "digixon") ?></p>
                      <?php $footer_bg_color = digixon_get_option('footer_bg_color'); ?>
                      <input name="footer_bg_color" type="text" value="<?php print esc_attr($footer_bg_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_FOOTER_BG ?>"
                             data-picker="footer_bg_color_show">
                    </li>
                    <li>
                      <label for="heading_style"><?php echo esc_html__('Footer text color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_FOOTER_TEXT , "digixon") ?></p>
                      <?php $footer_text_color = digixon_get_option('footer_text_color'); ?>
                      <input name="footer_text_color" type="text" value="<?php print esc_attr($footer_text_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_FOOTER_TEXT ?>"
                             data-picker="footer_text_color_show">
                    </li>
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Copyright background color :', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_COPYRIGHT_BG , "digixon") ?></p>
                      <?php $copyright_bg = digixon_get_option('copyright_bg'); ?>
                      <input name="copyright_bg" type="text" value="<?php print esc_attr($copyright_bg); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_COPYRIGHT_BG ?>"
                             data-picker="copyright_bg_show">
                    </li>
                    <li>
                      <label
                        for="heading_style"><?php echo esc_html__('Copyright bar text color', 'digixon'); ?></label>
                      <p><?php echo esc_html__("Pick a unlimited main color for the theme default: " . WD_COPYRIGHT_TEXT , "digixon") ?></p>
                      <?php $copyright_text_color = digixon_get_option('copyright_text_color'); ?>
                      <input name="copyright_text_color" type="text"
                             value="<?php print esc_attr($copyright_text_color); ?>"
                             class="wd-color-picker" data-default-color="<?php echo WD_COPYRIGHT_TEXT ?>"
                             data-picker="copyright_text_color_show">
                    </li>
                  </ul>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
          <div id="tabs-2">
            <table class="form-table">
              <tbody>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Main Typography', 'digixon'); ?></strong>
                </td>
                <td>
                  <?php $digixon_body_font_familly = digixon_get_option('wd_body_font_familly');
                  $digixon_fontArray = digixon_google_fonts_array();
                  $selected_font = 'default';
                  $selected_font_variants = $digixon_fontArray[0]['variants'];
                  $selected_font_subsets = $digixon_fontArray[0]['subsets'];
                  $selected_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                  $selected_style = $digixon_fontArray[0]['variants'][0]['style'];
                  $selected_weight = $digixon_fontArray[0]['variants'][0]['weight'][0];
                  ?>
                  <table>
                    <tbody>
                    <tr>
                      <td>
                        <label for="wd_body_font_familly"><?php echo esc_html__('Font family', 'digixon'); ?> :<br>
                        </label>
                      </td>
                      <td>
                        <select name="wd_body_font_familly" id="wd_body_font_familly" class="font_familly main_fonts"
                                data-classes="main_fonts">
                          <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php foreach ($digixon_fontArray as $pititablo) {
                            $font_name = $pititablo['name'];
                            ?>
                            <option
                              value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('wd_body_font_familly') == $font_name) {
                              echo "selected='selected'";
                              $selected_font = $font_name;
                              $selected_font_variants = $pititablo['variants'];
                              $selected_font_variants_weights = $pititablo['variants'][0]['weight'];
                              $selected_font_subsets = $pititablo['subsets'];
                            } ?> ><?php echo esc_attr($font_name); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_body_font_style"><?php echo esc_html__('Font style', 'digixon'); ?> :</label>
                      </td>
                      <td>
                        <select name="wd_body_font_style" id="wd_body_font_style" class="font_style main_fonts"
                                data-classes="main_fonts">
                          <?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants as $pititablo) {
                              $font_style = $pititablo['style'];
                              ?>
                              <option
                                value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('wd_body_font_style') == $font_style) {
                                echo "selected='selected'";
                                $selected_font_variants_weights = $pititablo['weight'];
                              } ?> ><?php echo esc_attr($font_style); ?></option>
                            <?php }
                          } else { ?>
                            <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_body_font_weight"><?php echo esc_html__('Font weight', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_body_font_weight" id="wd_body_font_weight" class="font_weight main_fonts"
                                data-classes="main_fonts">
                          <?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants_weights as $pititablo) {
                              $font_weight = $pititablo;
                              ?>
                              <option
                                value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('wd_body_font_weight') == $font_weight)
                                echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                            <?php }
                          } else {
                            for ($i = 100; $i < 1000; $i += 100) { ?>
                              <option
                                value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('wd_body_font_weight') == $i)
                                echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                            <?php }
                          } ?>

                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_body_font_weight_list"><?php echo esc_html__('Font weights to load', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_body_font_weight_list[]" class="font_weight_list main_fonts"
                                data-classes="main_fonts" multiple >
                          <?php
                          $font_weight_list = explode(',', digixon_get_option('wd_body_font_weight_list'));
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants as $style) {
                              $style_flag = ($style['style'] == 'italic') ? 'i' : '';
                              $style_name = ($style['style'] == 'italic') ? ' Italic' : '';
                              $weighters = $style['weight'];
                              for ($i = 0; $i < count($weighters); $i++) {
                                $weights_touse = $weighters[$i] . $style_flag;
                                $position = array_search($weights_touse, $font_weight_list);
                                ?>
                                <option value="<?php echo esc_attr($weights_touse); ?>" <?php if ($position !== false)
                                  echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($weighters[$i]) . ' ' . $style_name); ?></option>
                                <?php
                              }
                              ?>
                            <?php }
                          } else {
                            for ($i = 100; $i < 1000; $i += 100) { ?>
                              <option
                                value="<?php echo esc_attr($i); ?>"><?php echo digixon_font_weight_name($i); ?></option>
                            <?php }
                          } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_body_font_size"><?php echo esc_html__('Font size', 'digixon'); ?> :</label>
                      </td>
                      <td>
                        <input type="text" class="wd_txt_big fonts_size main_fonts" name="wd_body_font_size"
                               placeholder="<?php echo esc_attr__('example 12px', 'digixon'); ?>"
                               value="<?php if (digixon_get_option('wd_body_font_size')) {
                                 echo esc_attr(digixon_get_option('wd_body_font_size'));
                               } ?>" data-classes="main_fonts">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_main_text_lettre_spacing"><?php echo esc_html__('Lettre Spacing', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <?php
                        $digixon_main_text_lettre_spacing = digixon_get_option('wd_main_text_lettre_spacing');
                        $digixon_main_text_lettre_spacing = (!empty($digixon_main_text_lettre_spacing)) ? digixon_get_option('wd_main_text_lettre_spacing') : ''; ?>
                        <input type="text" class="wd_txt_big letter_spacing" name="wd_main_text_lettre_spacing"
                               placeholder="<?php echo esc_attr__('example 1px', 'digixon') ?>"
                               value="<?php echo esc_attr($digixon_main_text_lettre_spacing); ?>"
                               data-classes="main_fonts">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_main-text-font-subsets"><?php echo esc_html__('Font subsets', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select id="wd_main-text-font-subsets" name="wd_main-text-font-subsets"
                                class="font_subsets main_fonts" data-classes="main_fonts"><?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_subsets as $pititablo) {
                              $font_subset = $pititablo;
                              ?>
                              <option
                                value="<?php echo esc_attr($font_subset); ?>" <?php if (digixon_get_option('wd_main-text-font-subsets') == $font_subset)
                                echo "selected='selected'"; ?> ><?php echo esc_attr($font_subset); ?></option>
                            <?php }
                          } else { ?>
                            <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label><?php echo esc_html__('Preview:', 'digixon'); ?> :</label>
                      </td>
                      <td> <?php $font_family = (digixon_get_option('wd_body_font_familly') != "default") ? digixon_get_option('wd_body_font_familly') : 'Open Sans'; ?>
                        <p
                          class="preview_result  main_fonts" <?php echo 'style="font-family: ' . $font_family . '; font-weight: ' . digixon_get_option('wd_body_font_weight') . '; font-style: ' . digixon_get_option('wd_body_font_style') . '; letter-spacing: ' . digixon_get_option('wd_main_text_lettre_spacing') . ';';
                        if (digixon_get_option('wd_body_font_size')) {
                          echo ';font-size: ' . digixon_get_option('wd_body_font_size') . ';';
                        }
                        echo '"'; ?>><?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br>
                          <?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?>
                          <br><?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?></p>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Head Typography', 'digixon'); ?></strong>
                </td>
                <td>
                  <?php
                  $selected_font = 'default';
                  $selected_font_variants = $digixon_fontArray[0]['variants'];
                  $selected_font_subsets = $digixon_fontArray[0]['subsets'];
                  $selected_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                  $selected_style = $digixon_fontArray[0]['variants'][0]['style'];
                  $selected_weight = $digixon_fontArray[0]['variants'][0]['weight'][0];
                  ?>
                  <table>
                    <tbody>
                    <tr>
                      <td>
                        <label for="wd_head_font_familly"><?php echo esc_html__('Font family', 'digixon'); ?>:</label>
                      </td>
                      <td>
                        <select name="wd_head_font_familly" id="wd_head_font_familly" class="font_familly heading_fonts"
                                data-classes="heading_fonts">
                          <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php foreach ($digixon_fontArray as $pititablo) {
                            $font_name = $pititablo['name'];
                            ?>
                            <option
                              value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('wd_head_font_familly') == $font_name) {
                              echo "selected='selected'";
                              $selected_font = $font_name;
                              $selected_font_variants = $pititablo['variants'];
                              $selected_font_variants_weights = $pititablo['variants'][0]['weight'];
                              $selected_font_subsets = $pititablo['subsets'];
                            } ?> ><?php echo esc_attr($font_name); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_head_font_style"><?php echo esc_html__('Font style', 'digixon'); ?> :</label>
                      </td>
                      <td>
                        <select name="wd_head_font_style" id="wd_head_font_style" class="font_style heading_fonts"
                                data-classes="heading_fonts">
                          <?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants as $pititablo) {
                              $font_style = $pititablo['style'];
                              ?>
                              <option
                                value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('wd_head_font_style') == $font_style) {
                                echo "selected='selected'";
                                $selected_font_variants_weights = $pititablo['weight'];
                              } ?> ><?php echo esc_attr($font_style); ?></option>
                            <?php }
                          } else { ?>
                            <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_heading-font-weight-style"><?php echo esc_html__('Font weight', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_heading-font-weight-style" id="wd_heading-font-weight-style"
                                class="font_weight heading_fonts" data-classes="heading_fonts">
                          <?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants_weights as $pititablo) {
                              $font_weight = $pititablo;
                              ?>
                              <option
                                value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('wd_heading-font-weight-style') == $font_weight)
                                echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                            <?php }
                          } else {
                            for ($i = 100; $i < 1000; $i += 100) { ?>
                              <option
                                value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('wd_heading-font-weight-style') == $i)
                                echo "selected='selected'"; ?>><?php echo esc_attr(digixon_font_weight_name($i)); ?></option>
                            <?php }
                          } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_heading-font-weight-style-list"><?php echo esc_html__('Font weights to load', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_heading-font-weight-style-list[]" class="font_weight_list main_fonts"
                                data-classes="main_fonts" multiple >
                          <?php
                          $font_weight_list = explode(',', digixon_get_option('wd_heading-font-weight-style-list'));
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants as $style) {
                              $style_flag = ($style['style'] == 'italic') ? 'i' : '';
                              $style_name = ($style['style'] == 'italic') ? ' Italic' : '';
                              $weighters = $style['weight'];
                              for ($i = 0; $i < count($weighters); $i++) {
                                $weights_touse = $weighters[$i] . $style_flag;
                                $position = array_search($weights_touse, $font_weight_list);
                                ?>
                                <option value="<?php echo esc_attr($weights_touse); ?>" <?php if ($position !== false)
                                  echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($weighters[$i]) . ' ' . $style_name); ?></option>
                                <?php
                              }
                              ?>
                            <?php }
                          } else {
                            for ($i = 100; $i < 1000; $i += 100) { ?>
                              <option
                                value="<?php echo esc_attr($i); ?>"><?php echo esc_attr(digixon_font_weight_name($i)); ?></option>
                            <?php }
                          } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_heading_text_lettre_spacing"><?php echo esc_html__('Lettre Spacing', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <?php
                        $digixon_heading_text_lettre_spacing = digixon_get_option('wd_heading_text_lettre_spacing');
                        $digixon_heading_text_lettre_spacing = (!empty($digixon_heading_text_lettre_spacing)) ? digixon_get_option('wd_heading_text_lettre_spacing') : ''; ?>
                        <input type="text" class="wd_txt_big letter_spacing" name="wd_heading_text_lettre_spacing"
                               placeholder="<?php echo esc_attr__('example 1px', 'digixon'); ?>"
                               value="<?php echo esc_attr($digixon_heading_text_lettre_spacing); ?>"
                               data-classes="heading_fonts">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_heading-text-font-subsets"><?php echo esc_html__('Font subsets', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select id="wd_heading-text-font-subsets" name="wd_heading-text-font-subsets"
                                class="font_subsets heading_fonts" data-classes="heading_fonts"><?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_subsets as $pititablo) {
                              $font_subset = $pititablo;
                              ?>
                              <option
                                value="<?php echo esc_attr($font_subset); ?>" <?php if (digixon_get_option('wd_heading-text-font-subsets') == $font_subset)
                                echo "selected='selected'"; ?> ><?php echo esc_attr($font_subset); ?></option>
                            <?php }
                          } else { ?>
                            <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label><?php echo esc_html__('Preview:', 'digixon'); ?> :</label>
                      </td>
                      <td><?php $font_family = (digixon_get_option('wd_body_font_familly') != "default") ? digixon_get_option('wd_body_font_familly') : 'Open Sans'; ?>
                        <p class="preview_result heading_fonts"
                           <?php echo 'style="font-family: ' . $font_family . '; font-weight: ' . digixon_get_option('wd_heading-font-weight-style') . '; font-style: ' . digixon_get_option('wd_head_font_style') . '; letter-spacing: ' . digixon_get_option('wd_heading_text_lettre_spacing') . ';';
                           ?>;"><?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br>
                        <?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br>
                        <?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br></p>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Navigation Typography', 'digixon'); ?></strong>
                </td>
                <td>
                  <?php
                  $selected_font = 'default';
                  $selected_font_variants = $digixon_fontArray[0]['variants'];
                  $selected_font_subsets = $digixon_fontArray[0]['subsets'];
                  $selected_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                  $selected_style = $digixon_fontArray[0]['variants'][0]['style'];
                  $selected_weight = $digixon_fontArray[0]['variants'][0]['weight'][0];
                  ?>
                  <table>
                    <tbody>
                    <tr>
                      <td>
                        <label for="wd_navigation_font_familly"><?php echo esc_html__('Font family', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_navigation_font_familly" id="wd_navigation_font_familly"
                                class="font_familly navigation_fonts" data-classes="navigation_fonts">
                          <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php foreach ($digixon_fontArray as $pititablo) {
                            $font_name = $pititablo['name'];
                            ?>
                            <option
                              value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('wd_navigation_font_familly') == $font_name) {
                              echo "selected='selected'";
                              $selected_font = $font_name;
                              $selected_font_variants = $pititablo['variants'];
                              $selected_font_variants_weights = $pititablo['variants'][0]['weight'];
                              $selected_font_subsets = $pititablo['subsets'];
                            } ?> ><?php echo esc_attr($font_name); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_navigation_font_style"><?php echo esc_html__('Font style', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_navigation_font_style" id="wd_head_font_style"
                                class="font_style navigation_fonts" data-classes="navigation_fonts">
                          <?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants as $pititablo) {
                              $font_style = $pititablo['style'];
                              ?>
                              <option
                                value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('wd_navigation_font_style') == $font_style) {
                                echo "selected='selected'";
                                $selected_font_variants_weights = $pititablo['weight'];
                              } ?> ><?php echo esc_attr($font_style); ?></option>
                            <?php }
                          } else { ?>
                            <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_navigation-font-weight-style"><?php echo esc_html__('Font weight', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_navigation-font-weight-style" id="wd_navigation-font-weight-style"
                                class="font_weight navigation_fonts" data-classes="navigation_fonts">
                          <?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants_weights as $pititablo) {
                              $font_weight = $pititablo;
                              ?>
                              <option
                                value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('wd_navigation-font-weight-style') == $font_weight)
                                echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                            <?php }
                          } else {
                            for ($i = 100; $i < 1000; $i += 100) { ?>
                              <option
                                value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('wd_navigation-font-weight-style') == $i)
                                echo "selected='selected'"; ?>><?php echo esc_attr(digixon_font_weight_name($i)); ?></option>
                            <?php }
                          } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_navigation-font-weight-style-list"><?php echo esc_html__('Font weights to load', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_navigation-font-weight-style-list[]" class="font_weight_list main_fonts"
                                data-classes="main_fonts" multiple >
                          <?php
                          $font_weight_list = explode(',', digixon_get_option('wd_navigation-font-weight-style-list'));
                          if ($selected_font != 'default') {
                            foreach ($selected_font_variants as $style) {
                              $style_flag = ($style['style'] == 'italic') ? 'i' : '';
                              $style_name = ($style['style'] == 'italic') ? ' Italic' : '';
                              $weighters = $style['weight'];
                              for ($i = 0; $i < count($weighters); $i++) {
                                $weights_touse = $weighters[$i] . $style_flag;
                                $position = array_search($weights_touse, $font_weight_list);
                                ?>
                                <option value="<?php echo esc_attr($weights_touse); ?>" <?php if ($position !== false)
                                  echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($weighters[$i]) . ' ' . $style_name); ?></option>
                                <?php
                              }
                              ?>
                            <?php }
                          } else {
                            for ($i = 100; $i < 1000; $i += 100) { ?>
                              <option
                                value="<?php echo esc_attr($i); ?>"><?php echo esc_attr(digixon_font_weight_name($i)); ?></option>
                            <?php }
                          } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="wd_navigation_font_size"><?php echo esc_html__('Font size', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <input type="text" class="wd_txt_big fonts_size navigation_fonts" name="wd_navigation_font_size"
                               placeholder="<?php echo esc_attr__('example 12px', 'digixon'); ?>"
                               value="<?php if (digixon_get_option('wd_navigation_font_size')) {
                                 echo esc_attr(digixon_get_option('wd_navigation_font_size'));
                               } ?>" data-classes="navigation_fonts">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_navigation_text_transform"><?php echo esc_html__('Text Transform', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select name="wd_navigation_text_transform">
                          <option
                            value="uppercase" <?php if (digixon_get_option('wd_navigation_text_transform') == "uppercase") {
                            echo "selected='selected'";
                          } ?>>Uppercase
                          </option>
                          <option
                            value="lowercase" <?php if (digixon_get_option('wd_navigation_text_transform') == "lowercase") {
                            echo "selected='selected'";
                          } ?>>Lowercase
                          </option>
                          <option
                            value="capitalize" <?php if (digixon_get_option('wd_navigation_text_transform') == "capitalize") {
                            echo "selected='selected'";
                          } ?>>Capitalize
                          </option>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_navigation_text_lettre_spacing"><?php echo esc_html__('Lettre Spacing', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <?php
                        $digixon_navigation_text_lettre_spacing = digixon_get_option('wd_navigation_text_lettre_spacing');
                        $digixon_navigation_text_lettre_spacing = (!empty($digixon_navigation_text_lettre_spacing)) ? digixon_get_option('wd_navigation_text_lettre_spacing') : ''; ?>
                        <input type="text" class="wd_txt_big letter_spacing" name="wd_navigation_text_lettre_spacing"
                               placeholder="<?php echo esc_attr__('example 1px', 'digixon'); ?>"
                               value="<?php echo esc_attr($digixon_navigation_text_lettre_spacing); ?>"
                               data-classes="navigation_fonts">
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label
                          for="wd_navigation-text-font-subsets"><?php echo esc_html__('Font subsets', 'digixon'); ?>
                          :</label>
                      </td>
                      <td>
                        <select id="wd_navigation-text-font-subsets" name="wd_navigation-text-font-subsets"
                                class="font_subsets navigation_fonts" data-classes="navigation_fonts"><?php
                          if ($selected_font != 'default') {
                            foreach ($selected_font_subsets as $pititablo) {
                              $font_subset = $pititablo;
                              ?>
                              <option
                                value="<?php echo esc_attr($font_subset); ?>" <?php if (digixon_get_option('wd_navigation-text-font-subsets') == $font_subset)
                                echo "selected='selected'"; ?> ><?php echo esc_attr($font_subset); ?></option>
                            <?php }
                          } else { ?>
                            <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                          <?php } ?>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label><?php echo esc_html__('Preview:', 'digixon'); ?> :</label>
                      </td>
                      <td><?php $font_family = (digixon_get_option('wd_body_font_familly') != "default") ? digixon_get_option('wd_body_font_familly') : 'Open Sans'; ?>
                        <p class="preview_result navigation_fonts"
                           <?php echo 'style="font-family: ' . $font_family . '; font-weight: ' . digixon_get_option('wd_navigation-font-weight-style') . '; font-style: ' . digixon_get_option('wd_navigation_font_style') . '; letter-spacing: ' . digixon_get_option('wd_navigation_text_lettre_spacing') . ';';
                           if (null !== digixon_get_option('wd_navigation_font_size') && digixon_get_option('wd_navigation_font_size') != '') {
                             echo ';font-size: ' . digixon_get_option('wd_navigation_font_size') . ';';
                           } else {
                             echo 'font-size:12px';
                           } ?>;"><?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br>
                        <?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br>
                        <?php echo esc_html__('Sphinx of black quartz, judge my vow', 'digixon'); ?><br></p>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </td>
              </tr>

              </tbody>
            </table>
          </div>
          <div id="tabs-3">
            <table class="form-table">
              <tbody>
              <tr>
                <td colspan="3"><h2><?php echo esc_html__('404 Page settings', 'digixon'); ?></h2></td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Background image', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="text" name="settings[_wd_bg_404_page]" id="wd_404_page_filed" value="<?php echo esc_attr(digixon_get_option('wd_bg_404_page')) ?>" class="digixon_404_input bg_input_field" data-bgimage="digixon_404"/>
                  <input class="button" name="bg_404_page" id="wd_bg_404_page" value="Upload"/>
                  <input type="button" value="<?php echo esc_attr('Delete', 'digixon'); ?>" class="button bg_delete_button" data-bgimage="digixon_404"/></br>
                </td>
                <td class="image-preview">
                  <?php $digixon_title_bg_image = digixon_get_option('wd_bg_404_page'); ?>
                  <img src="<?php print esc_url($digixon_title_bg_image); ?>"  class="digixon_404_image"/>
                </td>
              </tr>

              <tr>
                <td colspan="3"><h2><?php echo esc_html__('Shop Page settings', 'digixon'); ?></h2></td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Products displayed per page', 'digixon'); ?></strong>
                </td>
                <td>
                  <input type="text" name="wd_shop_product_per_page" value="<?php echo esc_attr(digixon_get_option('wd_shop_product_per_page'))  ?>" placeholder="<?php echo esc_attr__('9','digixon') ?>"><strong><strong>
                </td>
              </tr>

              </tbody>
            </table>
          </div>
          <div id="tabs-4">
            <table class="form-table">
              <tbody>
              <tr>
                <td><strong><?php echo esc_html__('Footer columns', 'digixon'); ?></strong></td>
                <td class="admiral_footer_columns">
                  <?php $logo_position = digixon_get_option('wd_footer_columns', 'three_columns') ?>
                  <input id="digixon_footer1" type="radio" name="wd_footer_columns"
                         value="one_columns" <?php if ($logo_position == 'one_columns') {
                    echo 'checked';
                  } ?> />
                  <label for="digixon_footer1" class="admiral_footer1 <?php if ($logo_position == 'one_columns') {
                    echo 'label_selected ';
                  } ?>"></label>
                  <input id="digixon_footer2" type="radio" name="wd_footer_columns"
                         value="tow_a_columns" <?php if ($logo_position == 'tow_a_columns') {
                    echo 'checked';
                  } ?> />
                  <label for="digixon_footer2" class="admiral_footer2 <?php if ($logo_position == 'tow_a_columns') {
                    echo 'label_selected ';
                  } ?>"></label>
                  <input id="digixon_footer3" type="radio" name="wd_footer_columns"
                         value="tow_b_columns" <?php if ($logo_position == 'tow_b_columns') {
                    echo 'checked';
                  } ?> />
                  <label for="digixon_footer3" class="admiral_footer3 <?php if ($logo_position == 'tow_b_columns') {
                    echo 'label_selected ';
                  } ?>"></label>
                  <input id="digixon_footer4" type="radio" name="wd_footer_columns"
                         value="tow_c_columns" <?php if ($logo_position == 'tow_c_columns') {
                    echo 'checked';
                  } ?> />
                  <label for="digixon_footer4" class="admiral_footer4 <?php if ($logo_position == 'tow_c_columns') {
                    echo 'label_selected ';
                  } ?>"></label>
                  <input id="digixon_footer5" type="radio" name="wd_footer_columns"
                         value="three_columns" <?php if ($logo_position == 'three_columns') {
                    echo 'checked';
                  } ?> />
                  <label for="digixon_footer5" class="admiral_footer5 <?php if ($logo_position == 'three_columns') {
                    echo 'label_selected ';
                  } ?>"></label>
                  <input id="digixon_footer6" type="radio" name="wd_footer_columns"
                         value="four_columns" <?php if ($logo_position == 'four_columns') {
                    echo 'checked';
                  } ?> />
                  <label for="digixon_footer6" class="admiral_footer6 <?php if ($logo_position == 'four_columns') {
                    echo 'label_selected ';
                  } ?>"></label>
                </td>

              </tr>
              <tr>
                <td><strong><?php echo esc_html__('Footer background image', 'digixon'); ?></strong></td>
                <td>
                  <input type="text" name="settings[_wd_footer_bg_image]" id="wd_footer_bg_filed"
                         value="<?php echo esc_attr(digixon_get_option('wd_footer_bg_image')); ?>"
                         class="digixon_footer_input bg_input_field" data-bgimage="digixon_footer"/>
                  <input class="button" name="_unique_footer_bg_button" id="wd_footer_bg_btn" value="Upload"/>
                  <input type="button" value="Delete" class="button bg_delete_button"
                         data-bgimage="digixon_footer"/></br>
                </td>
                <td class="image-preview">
                  <?php $digixon_footer_bg_image = digixon_get_option('wd_footer_bg_image');
                  ?>
                  <img src="<?php print esc_url($digixon_footer_bg_image); ?>"
                       class="digixon_footer_image"/> <?php // endif;
                  ?></td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Footer Copyright text', 'digixon'); ?></strong>
                </td>
                <td>
                  <?php
                  $copyright = digixon_get_option('wd_copyright');
                  $copyright = (!empty($copyright)) ? digixon_get_option('wd_copyright') : ''; ?>
                  <textarea type="text" class="log_input" class="wd_txt_big" name="wd_copyright"
                            placeholder="<?php echo esc_attr__('Footer Copyright text', 'digixon') ?>"><?php echo html_entity_decode(esc_html($copyright)); ?></textarea>
                </td>
              </tr>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Powered by text', 'digixon'); ?></strong>
                </td>
                <td>
                  <?php
                  $poweredby = html_entity_decode(digixon_get_option('wd_poweredby'));
                  $poweredby = (!empty($poweredby)) ? digixon_get_option('wd_poweredby') : ''; ?>
                  <textarea type="text" class="log_input" class="wd_txt_big" name="wd_poweredby"
                            placeholder="<?php echo esc_attr__('Powered by', 'digixon') ?>"> <?php echo esc_html($poweredby); ?></textarea>
                </td>
              </tr>

              <tr
                class="">
                <td>
                  <strong><?php echo esc_html__('Social Media', 'digixon'); ?></strong>
                </td>
                <td>
                  <div class="socialmedia_wrapper">
                    <?php
                    $socialmedia_arry = explode(' ', digixon_get_option('socialmedia_name'));
                    $socialmediaicon_arry = explode(' ', digixon_get_option('social_icon'));
                    if (!empty($socialmedia_arry[0])) {
                      ?>
                      <p class="social_label"><?php echo esc_html__('Media Icon', 'digixon'); ?></p>
                      <p class="social_label"><?php echo esc_html__('Media Link', 'digixon'); ?></p>
                      <?php
                      $i = 1;
                      foreach ($socialmedia_arry as $social_data) {
                        $i++;
                        ?>
                        <div class="social_media">
                          <select name="social_icon[icon<?php echo esc_attr($i) ?>]">
                            <option value="-1"
                                    disabled><?php echo esc_html__('Select social media icon', 'digixon'); ?></option>
                            <option value="facebook-f" <?php selected($socialmediaicon_arry[$i - 2], 'facebook-f') ?> >
                              &#xf09a; Facebook
                            </option>
                            <option value="flickr" <?php selected($socialmediaicon_arry[$i - 2], 'flickr') ?> >&#xf16e;
                              Flickr
                            </option>
                            <option
                              value="google-plus-g" <?php selected($socialmediaicon_arry[$i - 2], 'google-plus-g') ?> >
                              &#xf0d5; Google-plus
                            </option>
                            <option value="instagram" <?php selected($socialmediaicon_arry[$i - 2], 'instagram') ?>>
                              &#xf16d; Instagram
                            </option>
                            <option value="linkedin-in" <?php selected($socialmediaicon_arry[$i - 2], 'linkedin-in') ?>>
                              &#xf0e1; Linkedin
                            </option>
                            <option value="twitter" <?php selected($socialmediaicon_arry[$i - 2], 'twitter') ?>>&#xf099;
                              Twitter
                            </option>
                            <option value="vimeo-v" <?php selected($socialmediaicon_arry[$i - 2], 'vimeo-v') ?>>&#xf27d;
                              Vimeo
                            </option>
                            <option value="whatsapp" <?php selected($socialmediaicon_arry[$i - 2], 'whatsapp') ?>>
                              &#xf232; Whatsapp
                            </option>
                            <option value="youtube" <?php selected($socialmediaicon_arry[$i - 2], 'youtube') ?>>&#xf167;
                              Youtube
                            </option>
                          </select>
                          <input type="text" name="socialmedia_name[media<?php echo esc_attr($i) ?>]"
                                 data-number="<?php echo esc_attr($i) ?>"
                                 placeholder="<?php echo esc_attr__('Your social media link', 'digixon'); ?>"
                                 value="<?php echo esc_attr($social_data) ?>"/>
                          <a href="javascript:void(0);" class="remove_button" title="<?php echo esc_attr__('Remove field','digixon') ?>">
                            <button type="button"
                                    class="button bg_delete_button"> <?php echo esc_html__('delete', 'digixon') ?></button>
                          </a>
                        </div>
                        <?php
                      }
                    }
                    ?>
                    <div>
                      <a href="javascript:void(0);" class="add_button" title="<?php echo esc_attr__('Add field','digixon') ?>">
                        <button type="button"
                                class="button"><?php echo esc_html__('Add Social Media', 'digixon'); ?></button>
                      </a>
                    </div>
                  </div>
                </td>
              </tr>

              </tbody>
            </table>
          </div>
          <div id="tabs-5">
            <table class="form-table">
              <tbody>
              <tr>
                <td>
                  <strong><?php echo esc_html__('Heading Settings', 'digixon'); ?></strong>
                </td>

                <td class="digixon_footer_columns">
                  <div class="heading-space">
                    <div class="space">
                      <h2><?php echo esc_html__('Heading Top Space :', 'digixon'); ?></h2>
                      <div>
                        <span>
                          <label
                            for="heading_top_d_space"><?php echo esc_html__('Desktop Space :', 'digixon'); ?></label>
                          <input name="heading_top_d_space" type="text" placeholder="<?php echo esc_attr__('100','digixon') ?>"
                                 value="<?php echo digixon_get_option('heading_top_d_space') ?>">
                        </span>
                        <span>
                          <label
                            for="heading_top_t_space"><?php echo esc_html__('Tablet Space :', 'digixon'); ?></label>
                          <input name="heading_top_t_space" type="text" placeholder="<?php echo esc_attr__('70','digixon') ?>"
                                 value="<?php echo digixon_get_option('heading_top_t_space') ?>">
                        </span>
                        <span>
                          <label
                            for="heading_top_m_space"><?php echo esc_html__('Mobile Space :', 'digixon'); ?></label>
                          <input name="heading_top_m_space" type="text" placeholder="<?php echo esc_attr__('50','digixon') ?>"
                                 value="<?php echo digixon_get_option('heading_top_m_space') ?>">
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="heading_parameter">
                    <h2><?php echo esc_html__('Heading Parameter', 'digixon'); ?></h2>
                    <label for="heading_style"><?php echo esc_html__('Heading Styles :', 'digixon'); ?></label>
                    <select name="heading_style" class="heading_style">
                      <option
                        value="heading_style_1" <?php digixon_get_option('heading_style_1') ? print 'selected' : '' ?>><?php echo esc_html__('Styles 1', 'digixon'); ?></option>
                      <option
                        value="heading_style_2" <?php digixon_get_option('heading_style_2') ? print 'selected' : '' ?>><?php echo esc_html__('Styles 2', 'digixon'); ?></option>
                      <option
                        value="heading_style_3" <?php digixon_get_option('heading_style_3') ? print 'selected' : '' ?>><?php echo esc_html__('Styles 3', 'digixon'); ?></option>
                    </select>
                    <div class="tabset-1">
                      <div id="heading_style_1" class="tabset ">
                        <!-- Tab 1 -->
                        <input type="radio" name="tabset" id="tab1" aria-controls="heading_general_style_1"
                               checked="checked">
                        <label for="tab1"><?php echo esc_html__('General', 'digixon'); ?></label>
                        <!-- Tab 2 -->
                        <input type="radio" name="tabset" id="tab2" aria-controls="heading_title_style_1">
                        <label for="tab2"><?php echo esc_html__('Title Typography', 'digixon'); ?></label>
                        <!-- Tab 3 -->
                        <input type="radio" name="tabset" id="tab3" aria-controls="heading_subtitle_style_1">
                        <label for="tab3"><?php echo esc_html__('SubTitle Typography', 'digixon'); ?></label>

                        <div class="tab-panels">
                          <ul id="heading_general_style_1" class="tab-panel">
                            <h2><?php echo esc_html__('General', 'digixon'); ?></h2>
                            <li>
                              <label
                                for="heading_a_layout"><?php echo esc_html__('Heading Layout :', 'digixon'); ?></label>
                              <select name="heading_a_layout">
                                <option
                                  value="s-under-t" <?php if (digixon_get_option('heading_a_layout') == 's-under-t') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('SubTitle under the title', 'digixon'); ?></option>
                                <option
                                  value="t-under-s" <?php if (digixon_get_option('heading_a_layout') == 't-under-s') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Title under the SubTitle', 'digixon'); ?></option>
                                <option
                                  value="s-behind-t" <?php if (digixon_get_option('heading_a_layout') == 's-behind-t') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('SubTitle behind the title', 'digixon'); ?></option>
                                <option value="t-only" <?php if (digixon_get_option('heading_a_layout') == 't-only') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Title only', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_alignment"><?php echo esc_html__('Heading alignment :', 'digixon'); ?></label>
                              <select name="heading_a_alignment">
                                <option
                                  value="center" <?php if (digixon_get_option('heading_a_alignment') == 'center') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Center', 'digixon'); ?></option>
                                <option value="left" <?php if (digixon_get_option('heading_a_alignment') == 'left') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Left', 'digixon'); ?></option>
                                <option value="right" <?php if (digixon_get_option('heading_a_alignment') == 'right') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Right', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="headings_a_separator"><?php echo esc_html__('Separator Type :', 'digixon'); ?></label>
                              <select name="headings_a_separator" class="separator_type">
                                <option value="none" <?php if (digixon_get_option('headings_a_separator') == 'none') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('No Separator', 'digixon'); ?></option>
                                <option
                                  value="border" <?php if (digixon_get_option('headings_a_separator') == 'border') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Border', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="headings_a_separator_position"
                                     class="display_none"><?php echo esc_html__('Separator Position :', 'digixon'); ?></label>
                              <select name="headings_a_separator_position" class="display_none">
                                <option
                                  value="center" <?php if (digixon_get_option('headings_a_separator_position') == 'center') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Center', 'digixon'); ?></option>
                                <option
                                  value="top" <?php if (digixon_get_option('headings_a_separator_position') == 'top') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Top', 'digixon'); ?></option>
                                <option
                                  value="bottom" <?php if (digixon_get_option('headings_a_separator_position') == 'bottom') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Bottom', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="headings_a_separator_style"
                                     class="display_none"><?php echo esc_html__('Separator Style :', 'digixon'); ?></label>
                              <select name="headings_a_separator_style" class="display_none">
                                <option
                                  value="solid" <?php if (digixon_get_option('headings_a_separator_style') == 'solid') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Solid', 'digixon'); ?></option>
                                <option
                                  value="dashed" <?php if (digixon_get_option('headings_a_separator_style') == 'dashed') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Dashed', 'digixon'); ?></option>
                                <option
                                  value="dotted" <?php if (digixon_get_option('headings_a_separator_style') == 'dotted') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Dotted', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="heading_a_separator_color"
                                     class="display_none"><?php echo esc_html__('Separator Color :', 'digixon'); ?></label>
                              <span class="display_none">
                              <input name="heading_a_separator_color" type="text"
                                     value="<?php echo digixon_get_option('heading_a_separator_color') ?>"
                                     class="wd-color-picker " data-default-color="#fff"
                                     data-picker="heading_a_separator_color_show">
                              </span>
                            </li>
                            <li>
                              <label for="heading_a_separator_width"
                                     class="display_none"><?php echo esc_html__('Separator Width:', 'digixon'); ?></label>
                              <input name="heading_a_separator_width" class="display_none" type="text"
                                     value="<?php echo digixon_get_option('heading_a_separator_width') ?>">
                            </li>
                          </ul>
                          <ul id="heading_title_style_1" class="tab-panel">
                            <h2><?php echo esc_html__('Title Typography', 'digixon'); ?></h2>
                            <li>
                              <?php
                              $digixon_fontArray = digixon_google_fonts_array();
                              $haeding_selected_title_font = 'default';
                              $haeding_selected_title_font_variants = $digixon_fontArray[0]['variants'];
                              $haeding_selected_title_font_subsets = $digixon_fontArray[0]['subsets'];
                              $haeding_selected_title_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                              ?>
                              <label
                                for="heading_a_title_font_family"><?php echo esc_html__('Title Font Family :', 'digixon'); ?></label>
                              <select name="heading_a_title_font_family">
                                <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php foreach ($digixon_fontArray as $pititablo) {
                                  $font_name = $pititablo['name'];
                                  ?>
                                  <option
                                    value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('heading_a_title_font_family') == $font_name) {
                                    echo "selected='selected'";
                                    $haeding_selected_title_font = $font_name;
                                    $haeding_selected_title_font_variants = $pititablo['variants'];
                                    $haeding_selected_title_font_variants_weights = $pititablo['variants'][0]['weight'];
                                    $haeding_selected_title_font_subsets = $pititablo['subsets'];
                                  } ?> ><?php echo esc_attr($font_name); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_title_font_style"><?php echo esc_html__('Title Font style :', 'digixon'); ?></label>
                              <select name="heading_a_title_font_style">
                                <?php
                                if ($haeding_selected_title_font != 'default') {
                                  foreach ($haeding_selected_title_font_variants as $pititablo) {
                                    $font_style = $pititablo['style'];
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('heading_a_title_font_style') == $font_style) {
                                      echo "selected='selected'";
                                      $haeding_selected_title_font_variants_weights = $pititablo['weight'];
                                    } ?> ><?php echo esc_attr($font_style); ?></option>
                                  <?php }
                                } else { ?>
                                  <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_title_font_weight"><?php echo esc_html__('Title Font Weight :', 'digixon'); ?></label>
                              <select name="heading_a_title_font_weight">
                                <?php
                                if ($haeding_selected_title_font != 'default') {
                                  foreach ($haeding_selected_title_font_variants_weights as $pititablo) {
                                    $font_weight = $pititablo;
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('heading_a_title_font_weight') == $font_weight)
                                      echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                                  <?php }
                                } else {
                                  for ($i = 100; $i < 1000; $i += 100) { ?>
                                    <option
                                      value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('heading_a_title_font_weight') == $i)
                                      echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                                  <?php }
                                } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_title_font_size"><?php echo esc_html__('Title Font size :', 'digixon'); ?></label>
                              <input type="text" name="heading_a_title_font_size"
                                     value="<?php echo digixon_get_option('heading_a_title_font_size'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_a_title_font_color"><?php echo esc_html__('Title Color :', 'digixon'); ?></label>
                              <input name="heading_a_title_font_color" type="text"
                                     value="<?php echo digixon_get_option('heading_a_title_font_color') ?>"
                                     class="wd-color-picker" data-default-color="#fff"
                                     data-picker="heading_a_title_font_color_show">
                            </li>
                            <li>
                              <label
                                for="heading_a_title_text_transform"><?php echo esc_html__('Title Text Transform :', 'digixon'); ?></label>
                              <select name="heading_a_title_text_transform">
                                <option
                                  value="" <?php if (digixon_get_option('heading_a_title_text_transform') == 'Default') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <option
                                  value="lowercase" <?php if (digixon_get_option('heading_a_title_text_transform') == 'lowercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Lowercase', 'digixon'); ?></option>
                                <option
                                  value="uppercase" <?php if (digixon_get_option('heading_a_title_text_transform') == 'uppercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Uppercase', 'digixon'); ?></option>
                                <option
                                  value="capitalize" <?php if (digixon_get_option('heading_a_title_text_transform') == 'capitalize') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Capitalize', 'digixon'); ?></option>
                                <option
                                  value="inherit" <?php if (digixon_get_option('heading_a_title_text_transform') == 'inherit') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Inherit', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_title_line_height"><?php echo esc_html__('Title Line Height :', 'digixon'); ?></label>
                              <input type="text" name="heading_a_title_line_height"
                                     value="<?php echo digixon_get_option('heading_a_title_line_height'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_a_title_letter_spacing"><?php echo esc_html__('Title Letter Spacing :', 'digixon'); ?></label>
                              <input type="text" name="heading_a_title_letter_spacing"
                                     value="<?php echo digixon_get_option('heading_a_title_letter_spacing'); ?>">
                            </li>
                          </ul>
                          <ul id="heading_subtitle_style_1" class="tab-panel">
                            <h2><?php echo esc_html__('SubTitle Typography', 'digixon'); ?></h2>
                            <li>
                              <?php
                              $digixon_fontArray = digixon_google_fonts_array();
                              $haeding_selected_subtitle_font = 'default';
                              $haeding_selected_subtitle_font_variants = $digixon_fontArray[0]['variants'];
                              $haeding_selected_subtitle_font_subsets = $digixon_fontArray[0]['subsets'];
                              $haeding_selected_subtitle_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                              ?>
                              <label
                                for="heading_a_subtitle_font_family"><?php echo esc_html__('Title Font Family :', 'digixon'); ?></label>
                              <select name="heading_a_subtitle_font_family">
                                <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php foreach ($digixon_fontArray as $pititablo) {
                                  $font_name = $pititablo['name'];
                                  ?>
                                  <option
                                    value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('heading_a_subtitle_font_family') == $font_name) {
                                    echo "selected='selected'";
                                    $haeding_selected_subtitle_font = $font_name;
                                    $haeding_selected_subtitle_font_variants = $pititablo['variants'];
                                    $haeding_selected_subtitle_font_variants_weights = $pititablo['variants'][0]['weight'];
                                    $haeding_selected_subtitle_font_subsets = $pititablo['subsets'];
                                  } ?> ><?php echo esc_attr($font_name); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_subtitle_font_style"><?php echo esc_html__('Title Font style :', 'digixon'); ?></label>
                              <select name="heading_a_subtitle_font_style">
                                <?php
                                if ($haeding_selected_subtitle_font != 'default') {
                                  foreach ($haeding_selected_subtitle_font_variants as $pititablo) {
                                    $font_style = $pititablo['style'];
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('heading_a_subtitle_font_style') == $font_style) {
                                      echo "selected='selected'";
                                      $haeding_selected_subtitle_font_variants_weights = $pititablo['weight'];
                                    } ?> ><?php echo esc_attr($font_style); ?></option>
                                  <?php }
                                } else { ?>
                                  <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_subtitle_font_weight"><?php echo esc_html__('Title Font Weight :', 'digixon'); ?></label>
                              <select name="heading_a_subtitle_font_weight">
                                <?php
                                if ($haeding_selected_subtitle_font != 'default') {
                                  foreach ($haeding_selected_subtitle_font_variants_weights as $pititablo) {
                                    $font_weight = $pititablo;
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('heading_a_subtitle_font_weight') == $font_weight)
                                      echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                                  <?php }
                                } else {
                                  for ($i = 100; $i < 1000; $i += 100) { ?>
                                    <option
                                      value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('heading_a_subtitle_font_weight') == $i)
                                      echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                                  <?php }
                                } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_subtitle_font_size"><?php echo esc_html__('Title Font size :', 'digixon'); ?></label>
                              <input type="text" name="heading_a_subtitle_font_size"
                                     value="<?php echo digixon_get_option('heading_a_subtitle_font_size'); ?>">
                            </li>
                            <li>
                              <?php $heading_a_subtitle_font_color = digixon_get_option('heading_a_subtitle_font_color'); ?>
                              <label
                                for="heading_a_subtitle_font_color"><?php echo esc_html__('Title Color :', 'digixon'); ?></label>
                              <input name="heading_a_subtitle_font_color" type="text" value="<?php echo digixon_get_option('heading_a_subtitle_font_color') ?>"
                                     class="wd-color-picker"
                                     data-default-color="#333" data-picker="heading_a_subtitle_font_color">

                            </li>
                            <li>
                              <label
                                for="heading_a_subtitle_text_transform"><?php echo esc_html__('Title Text Transform :', 'digixon'); ?></label>
                              <select name="heading_a_subtitle_text_transform">
                                <option
                                  value="" <?php if (digixon_get_option('heading_a_subtitle_text_transform') == 'Default') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <option
                                  value="lowercase" <?php if (digixon_get_option('heading_a_subtitle_text_transform') == 'lowercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Lowercase', 'digixon'); ?></option>
                                <option
                                  value="uppercase" <?php if (digixon_get_option('heading_a_subtitle_text_transform') == 'uppercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Uppercase', 'digixon'); ?></option>
                                <option
                                  value="capitalize" <?php if (digixon_get_option('heading_a_subtitle_text_transform') == 'capitalize') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Capitalize', 'digixon'); ?></option>
                                <option
                                  value="inherit" <?php if (digixon_get_option('heading_a_subtitle_text_transform') == 'inherit') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Inherit', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_a_subtitle_line_height"><?php echo esc_html__('Title Line Height :', 'digixon'); ?></label>
                              <input type="text" name="heading_a_subtitle_line_height"
                                     value="<?php echo digixon_get_option('heading_a_subtitle_line_height'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_a_subtitle_letter_spacing"><?php echo esc_html__('Title Letter Spacing :', 'digixon'); ?></label>
                              <input type="text" name="heading_a_subtitle_letter_spacing"
                                     value="<?php echo digixon_get_option('heading_a_subtitle_letter_spacing'); ?>">
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="tabset-2" >
                      <div id="heading_style_2" class="tabset ">
                        <!-- Tab 1 -->
                        <input type="radio" name="tabset-2" id="tab4" aria-controls="heading_general_style_2" checked>
                        <label for="tab4"><?php echo esc_html__('General', 'digixon'); ?></label>
                        <!-- Tab 2 -->
                        <input type="radio" name="tabset-2" id="tab5" aria-controls="heading_title_style_2">
                        <label for="tab5"><?php echo esc_html__('Title Typography', 'digixon'); ?></label>
                        <!-- Tab 3 -->
                        <input type="radio" name="tabset-2" id="tab6" aria-controls="heading_subtitle_style_2">
                        <label for="tab6"><?php echo esc_html__('SubTitle Typography', 'digixon'); ?></label>

                        <div class="tab-panels">
                          <ul id="heading_general_style_2" class="tab-panel">
                            <h2><?php echo esc_html__('General', 'digixon'); ?></h2>
                            <li>
                              <label
                                for="heading_b_layout"><?php echo esc_html__('Heading Layout :', 'digixon'); ?></label>
                              <select name="heading_b_layout">
                                <option
                                  value="s-under-t" <?php if (digixon_get_option('heading_b_layout') == 's-under-t') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('SubTitle under the title', 'digixon'); ?></option>
                                <option
                                  value="t-under-s" <?php if (digixon_get_option('heading_b_layout') == 't-under-s') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Title under the SubTitle', 'digixon'); ?></option>
                                <option
                                  value="s-behind-t" <?php if (digixon_get_option('heading_b_layout') == 's-behind-t') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('SubTitle behind the title', 'digixon'); ?></option>
                                <option value="t-only" <?php if (digixon_get_option('heading_b_layout') == 't-only') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Title only', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_alignment"><?php echo esc_html__('Heading alignment :', 'digixon'); ?></label>
                              <select name="heading_b_alignment">
                                <option
                                  value="center" <?php if (digixon_get_option('heading_b_alignment') == 'center') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Center', 'digixon'); ?></option>
                                <option value="left" <?php if (digixon_get_option('heading_b_alignment') == 'left') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Left', 'digixon'); ?></option>
                                <option value="right" <?php if (digixon_get_option('heading_b_alignment') == 'right') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Right', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="headings_b_separator"><?php echo esc_html__('Separator Type :', 'digixon'); ?></label>
                              <select name="headings_b_separator" class="separator_type">
                                <option value="none" <?php if (digixon_get_option('headings_b_separator') == 'none') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('No Separator', 'digixon'); ?></option>
                                <option
                                  value="border" <?php if (digixon_get_option('headings_b_separator') == 'border') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Border', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="headings_b_separator_position"
                                     class="display_none"><?php echo esc_html__('Separator Position :', 'digixon'); ?></label>
                              <select name="headings_b_separator_position" class="display_none">
                                <option
                                  value="center" <?php if (digixon_get_option('headings_b_separator_position') == 'center') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Center', 'digixon'); ?></option>
                                <option
                                  value="top" <?php if (digixon_get_option('headings_b_separator_position') == 'top') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Top', 'digixon'); ?></option>
                                <option
                                  value="bottom" <?php if (digixon_get_option('headings_b_separator_position') == 'bottom') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Bottom', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="headings_b_separator_style"
                                     class="display_none"><?php echo esc_html__('Separator Style :', 'digixon'); ?></label>
                              <select name="headings_b_separator_style" class="display_none">
                                <option
                                  value="solid" <?php if (digixon_get_option('headings_b_separator_style') == 'solid') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Solid', 'digixon'); ?></option>
                                <option
                                  value="dashed" <?php if (digixon_get_option('headings_b_separator_style') == 'dashed') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Dashed', 'digixon'); ?></option>
                                <option
                                  value="dotted" <?php if (digixon_get_option('headings_b_separator_style') == 'dotted') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Dotted', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="heading_b_separator_color"
                                     class="display_none"><?php echo esc_html__('Separator Color :', 'digixon'); ?></label>
                              <span class="display_none">
                                <input name="heading_b_separator_color" type="text"
                                       value="<?php echo digixon_get_option('heading_a_separator_color') ?>"
                                       class="wd-color-picker" data-default-color="#fff"
                                       data-picker="heading_b_separator_color_show">
                              </span>
                            </li>
                            <li>
                              <label for="heading_b_separator_width"
                                     class="display_none"><?php echo esc_html__('Separator Width:', 'digixon'); ?></label>
                              <input name="heading_b_separator_width" class="display_none" type="text"
                                     value="<?php echo digixon_get_option('heading_b_separator_width') ?>">
                            </li>
                          </ul>
                          <ul id="heading_title_style_2" class="tab-panel">
                            <h2><?php echo esc_html__('Title Typography', 'digixon'); ?></h2>
                            <li>
                              <?php
                              $digixon_fontArray = digixon_google_fonts_array();
                              $haeding_selected_title_font = 'default';
                              $haeding_selected_title_font_variants = $digixon_fontArray[0]['variants'];
                              $haeding_selected_title_font_subsets = $digixon_fontArray[0]['subsets'];
                              $haeding_selected_title_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                              ?>
                              <label
                                for="heading_b_title_font_family"><?php echo esc_html__('Title Font Family :', 'digixon'); ?></label>
                              <select name="heading_b_title_font_family">
                                <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php foreach ($digixon_fontArray as $pititablo) {
                                  $font_name = $pititablo['name'];
                                  ?>
                                  <option
                                    value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('heading_b_title_font_family') == $font_name) {
                                    echo "selected='selected'";
                                    $haeding_selected_title_font = $font_name;
                                    $haeding_selected_title_font_variants = $pititablo['variants'];
                                    $haeding_selected_title_font_variants_weights = $pititablo['variants'][0]['weight'];
                                    $haeding_selected_title_font_subsets = $pititablo['subsets'];
                                  } ?> ><?php echo esc_attr($font_name); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_title_font_style"><?php echo esc_html__('Title Font style :', 'digixon'); ?></label>
                              <select name="heading_b_title_font_style">
                                <?php
                                if ($haeding_selected_title_font != 'default') {
                                  foreach ($haeding_selected_title_font_variants as $pititablo) {
                                    $font_style = $pititablo['style'];
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('heading_b_title_font_style') == $font_style) {
                                      echo "selected='selected'";
                                      $haeding_selected_title_font_variants_weights = $pititablo['weight'];
                                    } ?> ><?php echo esc_attr($font_style); ?></option>
                                  <?php }
                                } else { ?>
                                  <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_title_font_weight"><?php echo esc_html__('Title Font Weight :', 'digixon'); ?></label>
                              <select name="heading_b_title_font_weight">
                                <?php
                                if ($haeding_selected_title_font != 'default') {
                                  foreach ($haeding_selected_title_font_variants_weights as $pititablo) {
                                    $font_weight = $pititablo;
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('heading_b_title_font_weight') == $font_weight)
                                      echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                                  <?php }
                                } else {
                                  for ($i = 100; $i < 1000; $i += 100) { ?>
                                    <option
                                      value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('heading_b_title_font_weight') == $i)
                                      echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                                  <?php }
                                } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_title_font_size"><?php echo esc_html__('Title Font size :', 'digixon'); ?></label>
                              <input type="text" name="heading_b_title_font_size"
                                     value="<?php echo digixon_get_option('heading_b_title_font_size'); ?>">
                            </li>
                            <li>
                              <?php $heading_b_title_font_color = digixon_get_option('heading_b_title_font_color'); ?>
                              <label
                                for="heading_b_title_font_color"><?php echo esc_html__('Title Color :', 'digixon'); ?></label>
                              <input name="heading_b_title_font_color" type="text"
                                     value="<?php echo digixon_get_option('heading_b_title_font_color'); ?>"
                                     class="wd-color-picker" data-default-color="#333"
                                     data-picker="heading_b_title_font_color_show">
                            </li>
                            <li>
                              <label
                                for="heading_b_title_text_transform"><?php echo esc_html__('Title Text Transform :', 'digixon'); ?></label>
                              <select name="heading_b_title_text_transform">
                                <option
                                  value="" <?php if (digixon_get_option('heading_b_title_text_transform') == 'Default') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <option
                                  value="lowercase" <?php if (digixon_get_option('heading_b_title_text_transform') == 'lowercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Lowercase', 'digixon'); ?></option>
                                <option
                                  value="uppercase" <?php if (digixon_get_option('heading_b_title_text_transform') == 'uppercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Uppercase', 'digixon'); ?></option>
                                <option
                                  value="capitalize" <?php if (digixon_get_option('heading_b_title_text_transform') == 'capitalize') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Capitalize', 'digixon'); ?></option>
                                <option
                                  value="inherit" <?php if (digixon_get_option('heading_b_title_text_transform') == 'inherit') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Inherit', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_title_line_height"><?php echo esc_html__('Title Line Height :', 'digixon'); ?></label>
                              <input type="text" name="heading_b_title_line_height"
                                     value="<?php echo digixon_get_option('heading_b_title_line_height'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_b_title_letter_spacing"><?php echo esc_html__('Title Letter Spacing :', 'digixon'); ?></label>
                              <input type="text" name="heading_b_title_letter_spacing"
                                     value="<?php echo digixon_get_option('heading_b_title_letter_spacing'); ?>">
                            </li>
                          </ul>
                          <ul id="heading_subtitle_style_2" class="tab-panel">
                            <h2><?php echo esc_html__('SubTitle Typography', 'digixon'); ?></h2>
                            <li>
                              <?php
                              $digixon_fontArray = digixon_google_fonts_array();
                              $haeding_selected_subtitle_font = 'default';
                              $haeding_selected_subtitle_font_variants = $digixon_fontArray[0]['variants'];
                              $haeding_selected_subtitle_font_subsets = $digixon_fontArray[0]['subsets'];
                              $haeding_selected_subtitle_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                              ?>
                              <label
                                for="heading_b_subtitle_font_family"><?php echo esc_html__('Title Font Family :', 'digixon'); ?></label>
                              <select name="heading_b_subtitle_font_family">
                                <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php foreach ($digixon_fontArray as $pititablo) {
                                  $font_name = $pititablo['name'];
                                  ?>
                                  <option
                                    value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('heading_b_subtitle_font_family') == $font_name) {
                                    echo "selected='selected'";
                                    $haeding_selected_subtitle_font = $font_name;
                                    $haeding_selected_subtitle_font_variants = $pititablo['variants'];
                                    $haeding_selected_subtitle_font_variants_weights = $pititablo['variants'][0]['weight'];
                                    $haeding_selected_subtitle_font_subsets = $pititablo['subsets'];
                                  } ?> ><?php echo esc_attr($font_name); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_subtitle_font_style"><?php echo esc_html__('Title Font style :', 'digixon'); ?></label>
                              <select name="heading_b_subtitle_font_style">
                                <?php
                                if ($haeding_selected_subtitle_font != 'default') {
                                  foreach ($haeding_selected_subtitle_font_variants as $pititablo) {
                                    $font_style = $pititablo['style'];
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('heading_b_subtitle_font_style') == $font_style) {
                                      echo "selected='selected'";
                                      $haeding_selected_subtitle_font_variants_weights = $pititablo['weight'];
                                    } ?> ><?php echo esc_attr($font_style); ?></option>
                                  <?php }
                                } else { ?>
                                  <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_subtitle_font_weight"><?php echo esc_html__('Title Font Weight :', 'digixon'); ?></label>
                              <select name="heading_b_subtitle_font_weight">
                                <?php
                                if ($haeding_selected_subtitle_font != 'default') {
                                  foreach ($haeding_selected_subtitle_font_variants_weights as $pititablo) {
                                    $font_weight = $pititablo;
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('heading_b_subtitle_font_weight') == $font_weight)
                                      echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                                  <?php }
                                } else {
                                  for ($i = 100; $i < 1000; $i += 100) { ?>
                                    <option
                                      value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('heading_b_subtitle_font_weight') == $i)
                                      echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                                  <?php }
                                } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_subtitle_font_size"><?php echo esc_html__('Title Font size :', 'digixon'); ?></label>
                              <input type="text" name="heading_b_subtitle_font_size"
                                     value="<?php echo digixon_get_option('heading_b_subtitle_font_size'); ?>">
                            </li>
                            <li>
                              <?php $heading_b_subtitle_font_color = digixon_get_option('heading_b_subtitle_font_color'); ?>
                              <label
                                for="heading_b_subtitle_font_color"><?php echo esc_html__('Title Color :', 'digixon'); ?></label>
                              <input name="heading_b_subtitle_font_color" type="text"
                                     value="<?php echo digixon_get_option('heading_b_subtitle_font_color') ?>"
                                     class="wd-color-picker" data-default-color="#C0392B"
                                     data-picker="heading_b_subtitle_font_color_show">

                            </li>
                            <li>
                              <label
                                for="heading_b_subtitle_text_transform"><?php echo esc_html__('Title Text Transform :', 'digixon'); ?></label>
                              <select name="heading_b_subtitle_text_transform">
                                <option
                                  value="" <?php if (digixon_get_option('heading_b_subtitle_text_transform') == 'Default') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <option
                                  value="lowercase" <?php if (digixon_get_option('heading_b_subtitle_text_transform') == 'lowercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Lowercase', 'digixon'); ?></option>
                                <option
                                  value="uppercase" <?php if (digixon_get_option('heading_b_subtitle_text_transform') == 'uppercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Uppercase', 'digixon'); ?></option>
                                <option
                                  value="capitalize" <?php if (digixon_get_option('heading_b_subtitle_text_transform') == 'capitalize') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Capitalize', 'digixon'); ?></option>
                                <option
                                  value="inherit" <?php if (digixon_get_option('heading_b_subtitle_text_transform') == 'inherit') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Inherit', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_b_subtitle_line_height"><?php echo esc_html__('Title Line Height :', 'digixon'); ?></label>
                              <input type="text" name="heading_b_subtitle_line_height"
                                     value="<?php echo digixon_get_option('heading_b_subtitle_line_height'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_b_subtitle_letter_spacing"><?php echo esc_html__('Title Letter Spacing :', 'digixon'); ?></label>
                              <input type="text" name="heading_b_subtitle_letter_spacing"
                                     value="<?php echo digixon_get_option('heading_b_subtitle_letter_spacing'); ?>">
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="tabset-3" >
                      <div id="heading_style_3" class="tabset ">
                        <!-- Tab 1 -->
                        <input type="radio" name="tabset-3" id="tab7" aria-controls="heading_general_style_3" checked>
                        <label for="tab7"><?php echo esc_html__('General', 'digixon'); ?></label>
                        <!-- Tab 2 -->
                        <input type="radio" name="tabset-3" id="tab8" aria-controls="heading_title_style_3">
                        <label for="tab8"><?php echo esc_html__('Title Typography', 'digixon'); ?></label>
                        <!-- Tab 3 -->
                        <input type="radio" name="tabset-3" id="tab9" aria-controls="heading_subtitle_style_3">
                        <label for="tab9"><?php echo esc_html__('SubTitle Typography', 'digixon'); ?></label>

                        <div class="tab-panels">
                          <ul id="heading_general_style_3" class="tab-panel">
                            <h2><?php echo esc_html__('General', 'digixon'); ?></h2>
                            <li>
                              <label
                                for="heading_c_layout"><?php echo esc_html__('Heading Layout :', 'digixon'); ?></label>
                              <select name="heading_c_layout">
                                <option
                                  value="s-under-t" <?php if (digixon_get_option('heading_c_layout') == 's-under-t') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('SubTitle under the title', 'digixon'); ?></option>
                                <option
                                  value="t-under-s" <?php if (digixon_get_option('heading_c_layout') == 't-under-s') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Title under the SubTitle', 'digixon'); ?></option>
                                <option
                                  value="s-behind-t" <?php if (digixon_get_option('heading_c_layout') == 's-behind-t') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('SubTitle behind the title', 'digixon'); ?></option>
                                <option value="t-only" <?php if (digixon_get_option('heading_c_layout') == 't-only') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Title only', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_alignment"><?php echo esc_html__('Heading alignment :', 'digixon'); ?></label>
                              <select name="heading_c_alignment">
                                <option
                                  value="center" <?php if (digixon_get_option('heading_c_alignment') == 'center') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Center', 'digixon'); ?></option>
                                <option value="left" <?php if (digixon_get_option('heading_c_alignment') == 'left') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Left', 'digixon'); ?></option>
                                <option value="right" <?php if (digixon_get_option('heading_c_alignment') == 'right') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Right', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="headings_c_separator"><?php echo esc_html__('Separator Type :', 'digixon'); ?></label>
                              <select name="headings_c_separator" class="separator_type">
                                <option value="none" <?php if (digixon_get_option('headings_c_separator') == 'none') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('No Separator', 'digixon'); ?></option>
                                <option
                                  value="border" <?php if (digixon_get_option('headings_c_separator') == 'border') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Border', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="headings_c_separator_position"
                                     class="display_none"><?php echo esc_html__('Separator Position :', 'digixon'); ?></label>
                              <select name="headings_c_separator_position" class="display_none">
                                <option
                                  value="center" <?php if (digixon_get_option('headings_c_separator_position') == 'center') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Center', 'digixon'); ?></option>
                                <option
                                  value="top" <?php if (digixon_get_option('headings_c_separator_position') == 'top') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Top', 'digixon'); ?></option>
                                <option
                                  value="bottom" <?php if (digixon_get_option('headings_c_separator_position') == 'bottom') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Bottom', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="headings_c_separator_style"
                                     class="display_none"><?php echo esc_html__('Separator Style :', 'digixon'); ?></label>
                              <select name="headings_c_separator_style" class="display_none">
                                <option
                                  value="solid" <?php if (digixon_get_option('headings_c_separator_style') == 'solid') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Solid', 'digixon'); ?></option>
                                <option
                                  value="dashed" <?php if (digixon_get_option('headings_c_separator_style') == 'dashed') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Dashed', 'digixon'); ?></option>
                                <option
                                  value="dotted" <?php if (digixon_get_option('headings_c_separator_style') == 'dotted') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Dotted', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label for="heading_c_separator_color"
                                     class="display_none"><?php echo esc_html__('Separator Color :', 'digixon'); ?></label>
                              <span class="display_none">
                              <input name="heading_c_separator_color" type="text"
                                     value="<?php echo digixon_get_option('heading_a_separator_color') ?>"
                                     class="wd-color-picker" data-default-color="#fff"
                                     data-picker="heading_c_separator_color_show">
                              </span>
                            </li>
                            <li>
                              <label for="heading_c_separator_width"
                                     class="display_none"><?php echo esc_html__('Separator Width:', 'digixon'); ?></label>
                              <input name="heading_c_separator_width" class="display_none" type="text"
                                     value="<?php echo digixon_get_option('heading_c_separator_width') ?>">
                            </li>
                          </ul>
                          <ul id="heading_title_style_3" class="tab-panel">
                            <h2><?php echo esc_html__('Title Typography', 'digixon'); ?></h2>
                            <li>
                              <?php
                              $digixon_fontArray = digixon_google_fonts_array();
                              $haeding_selected_title_font = 'default';
                              $haeding_selected_title_font_variants = $digixon_fontArray[0]['variants'];
                              $haeding_selected_title_font_subsets = $digixon_fontArray[0]['subsets'];
                              $haeding_selected_title_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                              ?>
                              <label
                                for="heading_c_title_font_family"><?php echo esc_html__('Title Font Family :', 'digixon'); ?></label>
                              <select name="heading_c_title_font_family">
                                <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php foreach ($digixon_fontArray as $pititablo) {
                                  $font_name = $pititablo['name'];
                                  ?>
                                  <option
                                    value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('heading_c_title_font_family') == $font_name) {
                                    echo "selected='selected'";
                                    $haeding_selected_title_font = $font_name;
                                    $haeding_selected_title_font_variants = $pititablo['variants'];
                                    $haeding_selected_title_font_variants_weights = $pititablo['variants'][0]['weight'];
                                    $haeding_selected_title_font_subsets = $pititablo['subsets'];
                                  } ?> ><?php echo esc_attr($font_name); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_title_font_style"><?php echo esc_html__('Title Font style :', 'digixon'); ?></label>
                              <select name="heading_c_title_font_style">
                                <?php
                                if ($haeding_selected_title_font != 'default') {
                                  foreach ($haeding_selected_title_font_variants as $pititablo) {
                                    $font_style = $pititablo['style'];
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('heading_c_title_font_style') == $font_style) {
                                      echo "selected='selected'";
                                      $haeding_selected_title_font_variants_weights = $pititablo['weight'];
                                    } ?> ><?php echo esc_attr($font_style); ?></option>
                                  <?php }
                                } else { ?>
                                  <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_title_font_weight"><?php echo esc_html__('Title Font Weight :', 'digixon'); ?></label>
                              <select name="heading_c_title_font_weight">
                                <?php
                                if ($haeding_selected_title_font != 'default') {
                                  foreach ($haeding_selected_title_font_variants_weights as $pititablo) {
                                    $font_weight = $pititablo;
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('heading_c_title_font_weight') == $font_weight)
                                      echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                                  <?php }
                                } else {
                                  for ($i = 100; $i < 1000; $i += 100) { ?>
                                    <option
                                      value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('heading_c_title_font_weight') == $i)
                                      echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                                  <?php }
                                } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_title_font_size"><?php echo esc_html__('Title Font size :', 'digixon'); ?></label>
                              <input type="text" name="heading_c_title_font_size"
                                     value="<?php echo digixon_get_option('heading_c_title_font_size'); ?>">
                            </li>
                            <li>
                              <?php $heading_c_title_font_color = digixon_get_option('heading_c_title_font_color'); ?>
                              <label
                                for="heading_c_title_font_color"><?php echo esc_html__('Title Color :', 'digixon'); ?></label>
                              <input name="heading_c_title_font_color" type="text"
                                     value="<?php echo digixon_get_option('heading_c_title_font_color'); ?>"
                                     class="wd-color-picker" data-default-color="#333"
                                     data-picker="heading_c_title_font_color_show">

                            </li>
                            <li>
                              <label
                                for="heading_c_title_text_transform"><?php echo esc_html__('Title Text Transform :', 'digixon'); ?></label>
                              <select name="heading_c_title_text_transform">
                                <option
                                  value="" <?php if (digixon_get_option('heading_c_title_text_transform') == 'Default') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <option
                                  value="lowercase" <?php if (digixon_get_option('heading_c_title_text_transform') == 'lowercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Lowercase', 'digixon'); ?></option>
                                <option
                                  value="uppercase" <?php if (digixon_get_option('heading_c_title_text_transform') == 'uppercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Uppercase', 'digixon'); ?></option>
                                <option
                                  value="capitalize" <?php if (digixon_get_option('heading_c_title_text_transform') == 'capitalize') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Capitalize', 'digixon'); ?></option>
                                <option
                                  value="inherit" <?php if (digixon_get_option('heading_c_title_text_transform') == 'inherit') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Inherit', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_title_line_height"><?php echo esc_html__('Title Line Height :', 'digixon'); ?></label>
                              <input type="text" name="heading_c_title_line_height"
                                     value="<?php echo digixon_get_option('heading_c_title_line_height'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_c_title_letter_spacing"><?php echo esc_html__('Title Letter Spacing :', 'digixon'); ?></label>
                              <input type="text" name="heading_c_title_letter_spacing"
                                     value="<?php echo digixon_get_option('heading_c_title_letter_spacing'); ?>">
                            </li>
                          </ul>
                          <ul id="heading_subtitle_style_3" class="tab-panel">
                            <h2><?php echo esc_html__('SubTitle Typography', 'digixon'); ?></h2>
                            <li>
                              <?php
                              $digixon_fontArray = digixon_google_fonts_array();
                              $haeding_selected_subtitle_font = 'default';
                              $haeding_selected_subtitle_font_variants = $digixon_fontArray[0]['variants'];
                              $haeding_selected_subtitle_font_subsets = $digixon_fontArray[0]['subsets'];
                              $haeding_selected_subtitle_font_variants_weights = $digixon_fontArray[0]['variants'][0]['weight'];
                              ?>
                              <label
                                for="heading_c_subtitle_font_family"><?php echo esc_html__('Title Font Family :', 'digixon'); ?></label>
                              <select name="heading_c_subtitle_font_family">
                                <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php foreach ($digixon_fontArray as $pititablo) {
                                  $font_name = $pititablo['name'];
                                  ?>
                                  <option
                                    value="<?php echo esc_attr($font_name); ?>" <?php if (digixon_get_option('heading_c_subtitle_font_family') == $font_name) {
                                    echo "selected='selected'";
                                    $haeding_selected_subtitle_font = $font_name;
                                    $haeding_selected_subtitle_font_variants = $pititablo['variants'];
                                    $haeding_selected_subtitle_font_variants_weights = $pititablo['variants'][0]['weight'];
                                    $haeding_selected_subtitle_font_subsets = $pititablo['subsets'];
                                  } ?> ><?php echo esc_attr($font_name); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_subtitle_font_style"><?php echo esc_html__('Title Font style :', 'digixon'); ?></label>
                              <select name="heading_c_subtitle_font_style">
                                <?php
                                if ($haeding_selected_subtitle_font != 'default') {
                                  foreach ($haeding_selected_subtitle_font_variants as $pititablo) {
                                    $font_style = $pititablo['style'];
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_style); ?>" <?php if (digixon_get_option('heading_c_subtitle_font_style') == $font_style) {
                                      echo "selected='selected'";
                                      $haeding_selected_subtitle_font_variants_weights = $pititablo['weight'];
                                    } ?> ><?php echo esc_attr($font_style); ?></option>
                                  <?php }
                                } else { ?>
                                  <option value=""><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <?php } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_subtitle_font_weight"><?php echo esc_html__('Title Font Weight :', 'digixon'); ?></label>
                              <select name="heading_c_subtitle_font_weight">
                                <?php
                                if ($haeding_selected_subtitle_font != 'default') {
                                  foreach ($haeding_selected_subtitle_font_variants_weights as $pititablo) {
                                    $font_weight = $pititablo;
                                    ?>
                                    <option
                                      value="<?php echo esc_attr($font_weight); ?>" <?php if (digixon_get_option('heading_c_subtitle_font_weight') == $font_weight)
                                      echo "selected='selected'"; ?> ><?php echo esc_attr(digixon_font_weight_name($font_weight)); ?></option>
                                  <?php }
                                } else {
                                  for ($i = 100; $i < 1000; $i += 100) { ?>
                                    <option
                                      value="<?php echo esc_attr($i); ?>" <?php if (digixon_get_option('heading_c_subtitle_font_weight') == $i)
                                      echo "selected='selected'"; ?>><?php echo digixon_font_weight_name($i); ?></option>
                                  <?php }
                                } ?>
                              </select>
                            </li>
                            <li>
                              <label
                                for="heading_c_subtitle_font_size"><?php echo esc_html__('Title Font size :', 'digixon'); ?></label>
                              <input type="text" name="heading_c_subtitle_font_size"
                                     value="<?php echo digixon_get_option('heading_c_subtitle_font_size'); ?>">
                            </li>
                            <li>
                              <?php $heading_c_subtitle_font_color = digixon_get_option('heading_c_subtitle_font_color'); ?>
                              <label
                                for="heading_c_subtitle_font_color"><?php echo esc_html__('Title Color :', 'digixon'); ?></label>
                              <input name="heading_c_subtitle_font_color" type="text"
                                     value="<?php echo digixon_get_option('heading_c_subtitle_font_color'); ?>"
                                     class="wd-color-picker" data-default-color="#C0392B"
                                     data-picker="heading_c_subtitle_font_color_show">

                            </li>
                            <li>
                              <label
                                for="heading_c_subtitle_text_transform"><?php echo esc_html__('Title Text Transform :', 'digixon'); ?></label>
                              <select name="heading_c_subtitle_text_transform">
                                <option
                                  value="" <?php if (digixon_get_option('heading_c_subtitle_text_transform') == 'Default') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Default', 'digixon'); ?></option>
                                <option
                                  value="lowercase" <?php if (digixon_get_option('heading_c_subtitle_text_transform') == 'lowercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Lowercase', 'digixon'); ?></option>
                                <option
                                  value="uppercase" <?php if (digixon_get_option('heading_c_subtitle_text_transform') == 'uppercase') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Uppercase', 'digixon'); ?></option>
                                <option
                                  value="capitalize" <?php if (digixon_get_option('heading_c_subtitle_text_transform') == 'capitalize') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Capitalize', 'digixon'); ?></option>
                                <option
                                  value="inherit" <?php if (digixon_get_option('heading_c_subtitle_text_transform') == 'inherit') {
                                  echo "selected='selected'";
                                } ?>><?php echo esc_html__('Inherit', 'digixon'); ?></option>
                              </select>
                            </li>
                            <li>

                              <label
                                for="heading_c_subtitle_line_height"><?php echo esc_html__('Title Line Height :', 'digixon'); ?></label>
                              <input type="text" name="heading_c_subtitle_line_height"
                                     value="<?php echo digixon_get_option('heading_c_subtitle_line_height'); ?>">
                            </li>
                            <li>
                              <label
                                for="heading_c_subtitle_letter_spacing"><?php echo esc_html__('Title Letter Spacing :', 'digixon'); ?></label>
                              <input type="text" name="heading_c_subtitle_letter_spacing"
                                     value="<?php echo digixon_get_option('heading_c_subtitle_letter_spacing'); ?>">
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="heading-space">
                    <div class="space">
                      <h2><?php echo esc_html__('Heading Bottom Space :', 'digixon'); ?></h2>
                      <div>
                        <span>
                          <label
                            for="heading_bottom_d_space"><?php echo esc_html__('Desktop Space :', 'digixon'); ?></label>
                          <input name="heading_bottom_d_space" type="text" placeholder="<?php echo esc_attr__('100','digixon') ?>"
                                 value="<?php echo digixon_get_option('heading_bottom_d_space') ?>">
                        </span>
                        <span>
                          <label
                            for="heading_bottom_t_space"><?php echo esc_html__('Tablet Space :', 'digixon'); ?></label>
                          <input name="heading_bottom_t_space" type="text" placeholder="<?php echo esc_attr__('70','digixon') ?>"
                                 value="<?php echo digixon_get_option('heading_bottom_t_space') ?>">
                        </span>
                        <span>
                          <label
                            for="heading_bottom_m_space"><?php echo esc_html__('Mobile Space :', 'digixon'); ?></label>
                          <input name="heading_bottom_m_space" type="text" placeholder="<?php echo esc_attr__('50','digixon') ?>"
                                 value="<?php echo digixon_get_option('heading_bottom_m_space') ?>">
                        </span>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="height columns wp-core-ui wd-validate">
          <p>
            <button class="button" value="Update Options" name="" type="submit">
              <span class="ti-save"></span><?php echo esc_html__('Update Options', 'digixon'); ?></button>
          </p>
        </div>
      </form>
    </div>
    <?php
  }
}

if (!function_exists('digixon_import_demo')) {
  function digixon_import_demo()
  {
    ?>
    <div id="tabs-6">
      <div id="wd-metaboxes-general" class="wrap wd-page wd-page-info" >
        <div class="notice-warning settings-error notice is-dismissible">
          <h4><strong><?php echo esc_html__('IMPORTANT INSTRUCTIONS','digixon') ?></strong></h4>
          <p><?php echo esc_html__('Depending of your server\'s settings, you may need to increase the limits. Please do the following steps
            before install the demo:','digixon') ?></p>
          <ol>
            <li><?php echo esc_html__('install','digixon') ?> <strong><?php echo esc_html__('PHP Settings','digixon') ?></strong> <?php echo esc_html__('plugin','digixon') ?></li>
            <li><?php echo esc_html__('Go to','digixon') ?> <strong><?php echo esc_html__('Tools -> PHP Settings','digixon') ?></strong></li>

            <li><?php echo esc_html__('Add this limits:','digixon') ?>
              <ul>
                <li><?php echo esc_html__('max_execution_time = 2000','digixon') ?></li>
                <li><?php echo esc_html__('memory_limit = 512M','digixon') ?></li>
                <li><?php echo esc_html__('post_max_siz = 256M','digixon') ?></li>
                <li><?php echo esc_html__('upload_max_filesize = 256M','digixon') ?></li>
              </ul>
            </li>
            <li><?php echo esc_html__('Hit Save Settings','digixon') ?></li>
          </ol>

        </div>
        <table class="form-table">
          <tbody>
          <tr>
            <td class="import-demo-screenshot">
              <em class="wd-field-description"><?php echo esc_html__('Select demo to import', 'digixon'); ?> : </em>
              <select name="Demo_selector" id="Demo_selector" class="form-control wd-form-element">
                <option value="demo-1"><?php echo esc_html__('Demo 1', 'digixon'); ?></option>
                <option value="demo-2"><?php echo esc_html__('Demo 2', 'digixon'); ?></option>
                <option value="demo-3"><?php echo esc_html__('Demo 3', 'digixon'); ?></option>
                <option value="demo-4"><?php echo esc_html__('Demo 4', 'digixon'); ?></option>
                <option value="demo-5"><?php echo esc_html__('Demo 5', 'digixon'); ?></option>
                <option value="demo-6"><?php echo esc_html__('Demo 6', 'digixon'); ?></option>
                <option value="demo-7"><?php echo esc_html__('Demo 7', 'digixon'); ?></option>
              </select><br>
              <label class="demo-1 demos_label" for="demo-1"></label>
              <label class="demo-2 demos_label hidden" for="demo-2" ></label>
              <label class="demo-3 demos_label hidden" for="demo-3" ></label>
              <label class="demo-4 demos_label hidden" for="demo-4" ></label>
              <label class="demo-5 demos_label hidden" for="demo-5" ></label>
              <label class="demo-6 demos_label hidden" for="demo-6" ></label>
              <label class="demo-7 demos_label hidden" for="demo-7" ></label>
            </td>
          </tr>
          <tr>

            <td>
              <em class="wd-field-description"><?php echo esc_html__('Import Type', 'digixon'); ?> : </em>
              <select name="import_option" id="import_option" class="form-control wd-form-element">
                <option value=""><?php echo esc_html__('Please Select', 'digixon'); ?></option>
                <option value="complete_content"><?php echo esc_html__('All', 'digixon'); ?></option>
                <option value="content"><?php echo esc_html__('Content', 'digixon'); ?></option>
                <option value="widgets"><?php echo esc_html__('Widgets', 'digixon'); ?></option>
                <option value="options"><?php echo esc_html__('Options', 'digixon'); ?></option>
                <option value="menus"><?php echo esc_html__('Menus', 'digixon'); ?></option>
              </select>
            </td>
          </tr>
          <tr id="tr_import_attachments" class="hidden">

            <td>
              <p><?php echo esc_html__('Do you want to import media files?', 'digixon'); ?></p>
              <input type="checkbox" value="1" class="wd-form-element" name="import_attachments"
                     id="import_attachments"/>
            </td>
          </tr>
          <tr id="tr_delete_menus" class="hidden">
            <td>
              <p><?php echo esc_html__('Do you want to delete all existing menus?', 'digixon'); ?></p>
              <input type="checkbox" value="1" class="wd-form-element" name="delete_menus" id="delete_menus"/>
            </td>
          </tr>
          <tr>
            <td>
              <input type="submit" class="button button-primary" value="<?php echo esc_html__('Import', 'digixon'); ?>"
                     name="import" id="import_demo_data"/>
              <img id="loading_gif" src="<?php echo get_template_directory_uri() . '/images/loading_import.gif'; ?>"
                   class="hidden" />
              <img id="OK_result" src="<?php echo get_template_directory_uri() . '/images/OK_result.png'; ?>"
                   class="hidden" />
              <img id="NOK_result" src="<?php echo get_template_directory_uri() . '/images/NOK_result.png'; ?>"
                   class="hidden" />
            </td>
          </tr>
          <tr>
            <td>
              <span><?php esc_html__('The import process may take some time. Please be patient.', 'digixon') ?> </span><br/>
              <div class="import_load">
                <div class="wd-progress-bar-wrapper html5-progress-bar">
                  <div class="progress-bar-wrapper">
                    <progress id="progressbar" value="0" max="100"></progress>
                  </div>
                  <div class="progress-value">0%</div>
                  <div class="progress-bar-message"></div>
                  <div class="error-message"></div>
                </div>
              </div>
            </td>
          </tr>
          <tr>

            <td>
              <div class="alert alert-warning">
                <strong><?php echo esc_html__('Important notes:', 'digixon') ?></strong>
                <ul>
                  <li><?php echo esc_html__('Please note that import process will take time needed to download all attachments from demo web site.', 'digixon'); ?></li>
                  <li> <?php echo esc_html__('If you plan to use shop, please install <b>WooCommerce</b> before you run import.', 'digixon') ?></li>
                </ul>
              </div>
            </td>
          </tr>
          </tbody>
        </table>
      </div>

    </div>
    <?php
  }
}

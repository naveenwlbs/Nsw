<?php
/**
 * Register theme support for languages, menus, post-thumbnails, post-formats etc.
 *
 */

if ( ! function_exists( 'digixon_theme_support' ) ) {
  function digixon_theme_support()
  {
    load_theme_textdomain('digixon', get_template_directory() . '/languages');

    if (function_exists('add_theme_support')) {
      add_theme_support('post-thumbnails');
      add_theme_support('post-formats', array('gallery', 'link', 'quote', 'video', 'audio'));
      add_theme_support('automatic-feed-links');
      add_theme_support('woocommerce');
      add_theme_support('custom-background');
      add_theme_support('title-tag');
	    $args = array(
		    'width'         => 1920,
		    'height'        => 470,
		    'default-image' => get_template_directory_uri() . '/images/title-bg.jpg',
	    );
	    add_theme_support( 'custom-header', $args );

    }

  }

  add_action('after_setup_theme', 'digixon_theme_support');
}
add_theme_support( 'editor-styles' );

// Enqueue editor styles.
add_editor_style( 'editor-style.css' );

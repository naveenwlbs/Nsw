<?php
if (!function_exists('digixon_dsm')) {
  function digixon_dsm($var)
  {
    print "<pre>" . print_r($var, true) . "</pre>";
  }
}
/*------------image size------------*/
function digixon_image_resize($url, $width, $height = null, $crop = null, $single = true)
{

//validate inputs
  if (!$url OR !$width)
    return false;

//define upload path & dir
  $upload_info = wp_upload_dir();
  $upload_dir = $upload_info['basedir'];
  $upload_url = $upload_info['baseurl'];

//check if $img_url is local
  if (strpos($url, $upload_url) === false)
    return false;

//define path of image
  $rel_path = str_replace($upload_url, '', $url);
  $img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
  if (!file_exists($img_path) OR !getimagesize($img_path))
    return false;

//get image info
  $info = pathinfo($img_path);
  $ext = $info['extension'];
  list($orig_w, $orig_h) = getimagesize($img_path);

//get image size after cropping
  $dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
  $dst_w = $dims[4];
  $dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
  $suffix = "{$dst_w}x{$dst_h}";
  $dst_rel_path = str_replace('.' . $ext, '', $rel_path);
  $destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

  if (!$dst_h) {
//can't resize, so return original url
    $img_url = $url;
    $dst_w = $orig_w;
    $dst_h = $orig_h;
  } //else check if cache exists
  elseif (file_exists($destfilename) && getimagesize($destfilename)) {
    $img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
  } //else, we resize the image and return the new resized image url
  else {

// Note: pre-3.5 fallback check 
    if (function_exists('wp_get_image_editor')) {

      $editor = wp_get_image_editor($img_path);

      if (is_wp_error($editor) || is_wp_error($editor->resize($width, $height, $crop)))
        return false;

      $resized_file = $editor->save();

      if (!is_wp_error($resized_file)) {
        $resized_rel_path = str_replace($upload_dir, '', $resized_file['path']);
        $img_url = $upload_url . $resized_rel_path;
      } else {
        return false;
      }
    } else {

      $resized_img_path = wp_get_image_editor($img_path, $width, $height, $crop);
      if (!is_wp_error($resized_img_path)) {
        $resized_rel_path = str_replace($upload_dir, '', $resized_img_path);
        $img_url = $upload_url . $resized_rel_path;
      } else {
        return false;
      }
    }
  }

//return the output
  if ($single) {
//str return
    $image = $img_url;
  } else {
//array return
    $image = array(
      0 => $img_url,
      1 => $dst_w,
      2 => $dst_h
    );
  }

  return $image;
}

/*---------------------- is blog ----------------------------*/
function digixon_is_blog()
{
  global $post;
  $posttype = get_post_type($post);
  return (((is_archive()) || (is_author()) || (is_category()) || (is_home()) || (is_tag())) && ($posttype == 'post')) ? true : false;
}

/*----------------------------breadcrumb------------------------------*/

if (!function_exists("digixon_breadcrumb")) {
  function digixon_breadcrumb()
  {
    global $post;
    echo '<ul class="breadcrumbs">';
    if (!is_home()) {
      echo '<li><a href="';
      echo esc_url(home_url('/'));
      echo '">';
      echo 'Home';
      echo '</a></li>';
      if (is_category() || is_single()) {
        echo '<li>';
        the_category(' </li><li> ');
        if (is_single()) {
          echo '</li><li>';
          the_title();
          echo '</li>';
        }
      } elseif (is_page()) {
        if ($post->post_parent) {
          $anc = get_post_ancestors($post->ID);
          $title = get_the_title();
          foreach ($anc as $ancestor) {
            $output = '<li><a href="' . esc_url(get_permalink($ancestor)) . '" title="' . get_the_title($ancestor) . '">' . get_the_title($ancestor) . '</a></li> ';
          }
          echo esc_html($output);
          echo '<li><strong title="' . esc_attr($title) . '"> ' . esc_html($title) . '</strong><li>';
        } else {
          echo '<li><strong> ' . get_the_title() . '</strong></li>';
        }
      }
    } elseif (is_tag()) {
      single_tag_title();
    } elseif (is_day()) {
      echo "<li>" . esc_html__('Archive', 'digixon');
      echo "</li>";
    } elseif (is_month()) {
      echo "<li>" . esc_html__('Archive for', 'digixon');
      echo '</li>';
    } elseif (is_year()) {
      echo "<li>" . esc_html__('Archive for', 'digixon');
      echo '</li>';
    } elseif (is_author()) {
      echo "<li>" . esc_html__('Author Archive', 'digixon');
      echo '</li>';
    } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {
      echo "<li>" . esc_html__('Blog Archives', 'digixon');
      echo '</li>';
    } elseif (is_search()) {
      echo "<li>" . esc_html__('Search Results', 'digixon');
      echo '</li>';
    }
    echo '</ul>';
  }
}

if (!function_exists('digixon_check_if_empty')) {
  function digixon_check_if_empty($propriete, $value)
  {
    $result = '';
    if ($value !== '' && !is_null($value)) {
      if ($propriete == 'background-image') {
        $result = $propriete . ': url(' . $value . ');';
      } else {
        $result = $propriete . ':' . $value . ';';
      }
    }
    return $result;
  }
}
if (!function_exists('wd_get_heading_separator')) {
  function wd_get_heading_separator($headings_separator, $custom_separatore_style, $hr_class)
  {
    if ($headings_separator == "border") {
      echo "<hr class='$hr_class' style='$custom_separatore_style'/>";
    }
  }
}


function digixon_get_post_category()
{
  $cat_name = get_the_terms(get_the_ID(), 'category');
  $ajzaa_class_name = '';
  if (isset($cat_name) && $cat_name != null) {
    foreach ($cat_name as $cat) {
      $ajzaa_class_name .= ' ' . $cat->slug;
    }
  }
  return $ajzaa_class_name;
}


function digixon_get_embedded_media($type = array())
{
  $content = do_shortcode(apply_filters('the_content', get_the_content()));
  $embed = get_media_embedded_in_content($content, $type);

  if (in_array('audio', $type)) {
    $output = str_replace('?visual=true', '?visual=false', $type[0]);
  } elseif (!empty($type)) {
    $output = $type[0];
  } else {
    $output = "";
  }

  return $output;
}

function digixon_get_attachment($num = 1)
{

  $output = '';
  if (has_post_thumbnail() && $num == 1):
    $output = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
  else:
    $attachments = get_posts(array(
      'post_type' => 'attachment',
      'posts_per_page' => $num,
      'post_parent' => get_the_ID()
    ));
    if ($attachments && $num == 1):
      foreach ($attachments as $attachment):
        $output = wp_get_attachment_url($attachment->ID);
      endforeach;
    elseif ($attachments && $num > 1):
      $output = $attachments;
    endif;

    wp_reset_postdata();

  endif;

  return $output;
}

 function digixon_related_posts ($digixon_postID) {
		$tags = wp_get_post_terms( $digixon_postID, 'category' );;
		if ($tags) {
            echo '<h4 class="comments_title">'.esc_html__("Related Posts","digixon").'</h4>';
            $first_tag = $tags[0]->term_id;
            $args=array(
                'category__in' => array($first_tag),
                'post__not_in' => array($digixon_postID),
                'posts_per_page'=>2,
                ' 
                '=>1
            );
            $my_query = new WP_Query($args);
            if( $my_query->have_posts() ) {
                while ($my_query->have_posts()) : $my_query->the_post(); ?>
                    <article class="large-6 columns">
                        <?php if(has_post_thumbnail()) { ?>
                            <div class="thumbnail-related-post">
                                <?php the_post_thumbnail('digixon_blog-related'); ?>
                            </div>
                        <?php } ?>
                        <div class="title-related-post">
                          <ul class="wd-post__meta clearfix">
                            <li><?php echo get_the_date(); ?></li>
                            <li class="wd-post__author"><?php echo esc_html__('By: ','digixon');  the_author() ?></li>
                            <li><?php echo esc_html__('in: ','digixon');   the_category(', '); ?></li>
                          </ul>
                          <h5>
                            <a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a>
                          </h5>
                        </div>
                    </article>
                    <?php
                endwhile;
            }
        }
 }

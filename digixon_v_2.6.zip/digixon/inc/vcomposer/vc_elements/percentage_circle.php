<?php
global $vc_add_css_animation;
global $digixon_fonts_array;

vc_map(array(
  "name" => esc_html__("Percentage Circle", 'digixon'),
  "base" => "digixon_percentage_circle",
  "icon" => get_template_directory_uri() . "/images/icon/meknes.png",
  "content_element" => true,
  "is_container" => true,
  "category" => 'Webdevia',
  "params" => array(
    array(
      "type" => "attach_images",
      "heading" => esc_html__("Circle Images", 'digixon'),
      "param_name" => "digixon_circle_img",
      "admin_label" => true,
    ),

    $vc_add_css_animation
  )
));
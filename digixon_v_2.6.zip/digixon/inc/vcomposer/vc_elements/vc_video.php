<?php

/*============================= Video =====================================*/
if(function_exists('vc_remove_param')) {
    vc_remove_param('vc_video','link');
    vc_remove_param('vc_tour','title');
    vc_remove_param('vc_single_image','onclick');
}

vc_add_param('vc_video',array(
        'type' => 'dropdown',
        'class' => '',
        'heading' => esc_html__('Video mode...', 'digixon'),
        'param_name' => 'video_module_mode',
        'value' => array(
            esc_html__('Simple video', 'digixon') => 'simple',
            esc_html__('Full screen video', 'digixon') => 'full_screen'
        ),
    )
);
vc_add_param('vc_video',array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Video link', 'digixon' ),
        'param_name' => 'link',
        'admin_label' => true,
        'description' => sprintf( esc_html__( 'Link to the video. More about supported formats at %s.', 'digixon' ), '<a href="http://codex.wordpress.org/Embeds#Okay.2C_So_What_Sites_Can_I_Embed_From.3F" target="_blank">WordPress codex page</a>' ),
        'dependency' => array('element' => 'video_module_mode','value' => array('simple')),
    )
);
vc_add_param('vc_video',array(
        'type' => 'attach_image',
        'class' => '',
        'heading' => esc_html__('Thumbnail Image', 'digixon'),
        'param_name' => 'video_thumb_image',
        'value' => '',
        'description' => esc_html__('Upload or select video thumbnail image from media gallery.', 'digixon'),
    )
);
vc_add_param('vc_video',array(
        'type' => 'textfield',
        'class' => '',
        'heading' => esc_html__('Thumbnail Image resize', 'digixon'),
        'param_name' => 'video_thumb_image_size',
        'value' => '800x530',
        'description' => esc_html__('select video thumbnail image size.', 'digixon'),
    )
);
vc_add_param('vc_video',array(
        'type' => 'dropdown',
        'class' => '',
        'heading' => esc_html__('Video source', 'digixon'),
        'param_name' => 'video_source',
        'value' => array(
            esc_html__('Youtube', 'digixon') => 'youtube',
            esc_html__('Vimeo', 'digixon') => 'vimeo'
        ),
        //'description' => esc_html__('Upload or select video thumbnail image from media gallery.', 'digixon'),
        'dependency' => array('element' => 'video_module_mode','value' => array('full_screen')),
    )
);
vc_add_param('vc_video',array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Video ID', 'digixon' ),
        'param_name' => 'video_id',
        'admin_label' => true,
        //'description' => esc_html__( '', 'digixon' ),
        'dependency' => array('element' => 'video_module_mode','value' => array('full_screen')),
    )
);
vc_add_param('vc_video',array(
        'type' => 'dropdown',
        'class' => '',
        'heading' => esc_html__('Label Alignment','digixon'),
        'param_name' => 'module_alignment',
        "value" => array(
            esc_html__('Left','digixon') => "text-left",
            esc_html__('Center','digixon') => "text-center",
            esc_html__('Right','digixon') => "text-right"
        ),
        'dependency' => array('element' => 'video_module_mode','value' => array('full_screen')),
    )
);
vc_add_param('vc_video',array(
        'type' => 'dropdown',
        'class' => '',
        'heading' => esc_html__('Modal Size (width)','digixon'),
        'param_name' => 'modal_size',
        "value" => array(
            esc_html__('Medium (60%)','digixon') => "medium",
            esc_html__('Small (40%)','digixon') => "small",
            esc_html__('Tiny (30%)','digixon') => "tiny",
            esc_html__('Large (70%)','digixon') => "large",
            esc_html__('XLarge (95%)','digixon') => "xlarge",
            esc_html__('Full (100%)','digixon') => "full"
        ),
        'dependency' => array('element' => 'video_module_mode','value' => array('full_screen')),
    )
);
vc_add_param('vc_video',array(
        'type' => 'colorpicker',
        'class' => '',
        'heading' => esc_html__('Icon color', 'digixon'),
        'param_name' => 'icon_color',
        'dependency' => array('element' => 'video_module_mode','value' => array('full_screen')),
    )
);
vc_add_param('vc_video',array(
        'type' => 'colorpicker',
        'heading' => esc_html__('Label background', 'digixon'),
        'param_name' => 'label_background',
        'dependency' => array('element' => 'video_module_mode','value' => array('full_screen')),
    )
);
<?php

global $vc_add_css_animation;
/* our client
---------------------------------------------------------- */


vc_map(array(
	"name" => esc_html__("Clients", 'digixon'),
	"base" => "wd_client",
	"category" => __("Webdevia", 'digixon'),
	"icon" => get_template_directory_uri() . "/images/icon/meknes.png",
	"content_element" => true,
	"is_container" => true,
	"category" => 'Webdevia',
	"params" => array(
		array(
			'type' => 'attach_images',
			'heading' => esc_html__('Images', 'digixon'),
			'param_name' => 'images',

		)
	, array(
			"type" => "dropdown", // it will bind a textfield in WP
			"heading" => esc_html__("Layout Style", 'digixon'),
			"param_name" => "layout_style",
			"value" => array('Carousel' => 'carousel',
				'Grid' => 'grid'),
		),
		array(
			"type" => "textfield",
			"heading" => esc_html__("Elements To Show", 'digixon'),
			"param_name" => "elements_to_show",
			"dependency" => Array("element" => "layout_style", "value" => array('carousel'))
		),
		array(
			"type" => "checkbox",
			"heading" => esc_html__("Display nav arrow", 'digixon'),
			"param_name" => "nav_arrow",
      "value" => array(esc_html__('Yes, please', 'digixon') => 'yes'),
			"dependency" => Array("element" => "layout_style", "value" => array('carousel'))
		),
		array(
			"type" => "textfield",
			"heading" => esc_html__("Columns", 'digixon'),
			"param_name" => "columns",
			"dependency" => Array("element" => "layout_style", "value" => array('grid'))
		),


		$vc_add_css_animation
	)
));
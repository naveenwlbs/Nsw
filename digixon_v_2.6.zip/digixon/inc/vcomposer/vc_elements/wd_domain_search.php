<?php

global $vc_add_css_animation;
vc_map(array(
  "name" => esc_html__("Domain Search", 'digixon'), // add a name
  "base" => "wd_domain_search", // bind with our shortcode
  "icon" => get_template_directory_uri() . "/images/icon/meknes.png",
  "content_element" => true, // set this parameter when element will has a content
  "category" => 'Webdevia',
  "is_container" => true, // set this param when you need to add a content element in this element
  // Here starts the definition of array with parameters of our compnent
  "category" => 'Webdevia',
  "params" => array(
    
    $vc_add_css_animation
  )
));
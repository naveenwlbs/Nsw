<?php 
if ( class_exists('digixon_meta_box') ) {
	$digixon_meta_box_var = new digixon_meta_box();
}
 ?>
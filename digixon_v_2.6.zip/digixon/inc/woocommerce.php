<?php
/**
 * Sets up the content width value based on the theme's design and stylesheet.
 */
if (!isset($content_width))
  $content_width = 625;

/*---------wooocomerce---------*/
//Reposition WooCommerce breadcrumb
function digixon_woocommerce_remove_breadcrumb()
{
  remove_action(
    'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
}

add_action(
  'woocommerce_before_main_content', 'digixon_woocommerce_remove_breadcrumb'
);

function digixon_woocommerce_custom_breadcrumb()
{
  woocommerce_breadcrumb();
}

add_action('woo_custom_breadcrumb', 'digixon_woocommerce_custom_breadcrumb');


// Ensure cart contents update when products are added to the cart via AJAX (place the following in functions.php)
add_filter('woocommerce_add_to_cart_fragments', 'digixon_woocommerce_header_add_to_cart_fragment');

function digixon_woocommerce_header_add_to_cart_fragment($fragments)
{
  ob_start();
  ?>
  <a class="cart-contents" href="<?php echo esc_url(wc_get_cart_url()); ?>"
     title="<?php echo esc_attr__('View your shopping cart', 'digixon'); ?>"><?php echo sprintf(esc_html__('%d item', 'digixon', WC()->cart->cart_contents_count), WC()->cart->cart_contents_count); ?>
    - <?php echo WC()->cart->get_cart_total(); ?></a>
  <?php

  $fragments['a.cart-contents'] = ob_get_clean();

  return $fragments;
}



/**
 * --------------- Number of Products to dispaly per page (9) -----------
 */
add_filter( 'loop_shop_per_page', 'digixon_loop_shop_per_page', 20 );

function digixon_loop_shop_per_page( $cols ) {
  // $cols contains the current number of product
  $cols = digixon_get_option('wd_shop_product_per_page', 9);
  return $cols;
}



// Enable Woocommerce LightBox

add_action( 'after_setup_theme', 'digixon_woocommcere_setup' );
function digixon_woocommcere_setup() {
  add_theme_support( 'wc-product-gallery-lightbox' );
  add_theme_support( 'wc-product-gallery-slider' );
}

/*
 * Remove 'Product Description' heading
 */
add_filter('woocommerce_product_description_heading', '__return_null');
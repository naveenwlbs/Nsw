  Theme Name: Digixon
  Theme URI: http://themes.webdevia.com/digixon-creative-digital-agency-wordpress-theme
  Description: Creative Digixon Agency WordPress Theme

  Author: Mymoun
  Author URI: http://www.webdevia.com/
  Version: 2.6
  Text Domain: digixon
  Domain Path: /languages

  Version: 2.6
  License: Envato
  License URI: https://themeforest.net/licenses
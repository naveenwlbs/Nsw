<?php
/**
 * The template for displaying search forms in Metroblocks
 *
 */
?>

<form action="<?php echo esc_url( home_url( '/' ) ) ?>" class="searchform" method="get" role="search">
	<div class="form-group">
		<input type="text" id="s" class="form-control" name="s" value="" placeholder="<?php echo esc_attr__('Search...','digixon') ?>">
		<button type="submit" value="<?php echo esc_attr__('Search...','digixon') ?>" id="searchsubmit">  </button>
	</div>
</form>



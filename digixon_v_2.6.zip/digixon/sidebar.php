<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<aside class="large-4 small-12 sidebar-second columns sidebar" >
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
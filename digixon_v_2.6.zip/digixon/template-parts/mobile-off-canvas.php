<nav class="mobile-off-canvas-menu off-canvas position-left show-for-small-only" id="<?php esc_attr(digixon_mobile_menu_id()); ?>" data-off-canvas data-auto-focus="false" role="navigation">
	<?php digixon_mobile_nav(); ?>
</nav>

<div class="off-canvas-content" data-off-canvas-content>

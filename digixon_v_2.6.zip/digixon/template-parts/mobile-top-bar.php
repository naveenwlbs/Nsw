<nav class="mobile-menu vertical menu" id="<?php esc_attr(digixon_mobile_menu_id()); ?>" role="navigation" data-animate="hinge-in-from-top hinge-out-from-top">
	<?php digixon_mobile_nav(); ?>
</nav>
